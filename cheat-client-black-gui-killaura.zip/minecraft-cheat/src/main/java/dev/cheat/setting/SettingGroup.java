package dev.cheat.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Контейнер настроек модуля. Хранит настройки по порядку регистрации,
 * предоставляет доступ по имени и поддерживает сериализацию всей группы
 * в {@code Map<String, Object>} и обратно.
 *
 * <p>Используется классом {@link dev.cheat.module.Module} — каждому модулю
 * автоматически выдаётся группа {@code settings}. Разработчику достаточно
 * в конструкторе модуля вызвать:</p>
 * <pre>
 *   settings.add(new IntSetting("Range", "Дальность", 4, 1, 6));
 *   settings.add(new BooleanSetting("ThroughWalls", "Сквозь стены", false));
 * </pre>
 */
public final class SettingGroup {

    private final List<Setting<?>> byOrder = new ArrayList<>();
    private final Map<String, Setting<?>> byName = new LinkedHashMap<>();

    public <S extends Setting<?>> S add(S setting) {
        if (setting == null) return null;
        String key = setting.name().toLowerCase();
        if (byName.containsKey(key)) {
            // дубликат — возвращаем существующий
            //noinspection unchecked
            return (S) byName.get(key);
        }
        byOrder.add(setting);
        byName.put(key, setting);
        return setting;
    }

    public Setting<?> get(String name) {
        return byName.get(name.toLowerCase());
    }

    @SuppressWarnings("unchecked")
    public <S extends Setting<?>> S get(String name, Class<S> type) {
        Setting<?> s = byName.get(name.toLowerCase());
        return s == null ? null : (S) s;
    }

    public List<Setting<?>> all() {
        return Collections.unmodifiableList(byOrder);
    }

    public List<Setting<?>> visible() {
        List<Setting<?>> r = new ArrayList<>();
        for (Setting<?> s : byOrder) if (s.isVisible()) r.add(s);
        return r;
    }

    public int size() { return byOrder.size(); }
    public boolean isEmpty() { return byOrder.isEmpty(); }

    // ─── Удобные типизированные геттеры ──────────────────────────

    public BooleanSetting bool(String name)   { return get(name, BooleanSetting.class); }
    public IntSetting     Int(String name)    { return get(name, IntSetting.class); }
    public DoubleSetting  Double(String name) { return get(name, DoubleSetting.class); }
    public FloatSetting   Float(String name)  { return get(name, FloatSetting.class); }
    public ModeSetting    mode(String name)   { return get(name, ModeSetting.class); }
    public ColorSetting   color(String name)  { return get(name, ColorSetting.class); }
    public StringSetting  string(String name) { return get(name, StringSetting.class); }
    public KeyBindSetting key(String name)    { return get(name, KeyBindSetting.class); }

    @SuppressWarnings({"unchecked","rawtypes"})
    public EnumSetting<? extends Enum> enumSetting(String name) {
        return (EnumSetting<? extends Enum>) get(name, (Class) EnumSetting.class);
    }

    // ─── Сериализация ──────────────────────────────────────────

    public Map<String, Object> serialize() {
        Map<String, Object> out = new LinkedHashMap<>();
        for (Setting<?> s : byOrder) {
            out.put(s.name(), s.serialize());
        }
        return out;
    }

    public void deserialize(Map<String, Object> data) {
        if (data == null) return;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            Setting<?> s = byName.get(e.getKey().toLowerCase());
            if (s != null) {
                try { s.deserialize(e.getValue()); }
                catch (Throwable ignored) {}
            }
        }
    }

    public void resetAll() {
        for (Setting<?> s : byOrder) s.resetDefault();
    }

    /** Пересчитать условия доступности всех настроек. */
    public void refreshAllEnabled() {
        for (Setting<?> s : byOrder) s.refreshEnabled();
    }
}
