package dev.cheat.setting;

/**
 * Вещественная настройка (float slider). То же, что {@link DoubleSetting},
 * но с float-хранилищем — удобно для графических/анимационных параметров.
 */
public final class FloatSetting extends Setting<Float> {

    private final float min;
    private final float max;
    private final float step;

    public FloatSetting(String name, String description, float defaultValue,
                        float min, float max) {
        this(name, description, defaultValue, min, max, 0.01f);
    }

    public FloatSetting(String name, String description, float defaultValue,
                        float min, float max, float step) {
        super(name, description, defaultValue);
        if (min > max) throw new IllegalArgumentException("min > max");
        this.min  = min;
        this.max  = max;
        this.step = step <= 0 ? 0.01f : step;
        set(defaultValue, false);
    }

    public float min()  { return min; }
    public float max()  { return max; }
    public float step() { return step; }

    public float value() { return get(); }

    public float progress() {
        if (max == min) return 0f;
        return (get() - min) / (max - min);
    }

    public void setByProgress(float p) {
        p = Math.max(0f, Math.min(1f, p));
        float raw = min + p * (max - min);
        float snapped = min + Math.round((raw - min) / step) * step;
        set(Math.max(min, Math.min(max, snapped)));
    }

    @Override protected Float normalize(Float v) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    @Override public Object serialize()          { return get(); }
    @Override public void   deserialize(Object d) {
        if (d instanceof Number n) set(n.floatValue());
        else if (d instanceof String s) {
            try { set(Float.parseFloat(s)); } catch (NumberFormatException ignored) {}
        }
    }
    @Override public Type   type()                { return Type.FLOAT; }
}
