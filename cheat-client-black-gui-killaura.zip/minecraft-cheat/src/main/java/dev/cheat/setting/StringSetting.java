package dev.cheat.setting;

import java.util.Objects;

/**
 * Строковая настройка (текстовое поле).
 *
 * <pre>
 *   private final StringSetting prefix =
 *       new StringSetting("Prefix", "Префикс чат-команд", ".");
 * </pre>
 */
public final class StringSetting extends Setting<String> {

    private final int maxLength;

    public StringSetting(String name, String description, String defaultValue) {
        this(name, description, defaultValue, 256);
    }

    public StringSetting(String name, String description, String defaultValue, int maxLength) {
        super(name, description, defaultValue);
        this.maxLength = Math.max(1, maxLength);
        set(defaultValue, false);
    }

    public int maxLength() { return maxLength; }

    public String value() { return get(); }

    public boolean isEmpty() { return get() == null || get().isEmpty(); }

    @Override protected String normalize(String v) {
        if (v == null) return "";
        return v.length() > maxLength ? v.substring(0, maxLength) : v;
    }

    @Override public Object serialize()            { return get(); }
    @Override public void   deserialize(Object d)   {
        if (d instanceof String s) set(s);
        else if (d != null) set(Objects.toString(d));
    }
    @Override public Type   type()                  { return Type.STRING; }
}
