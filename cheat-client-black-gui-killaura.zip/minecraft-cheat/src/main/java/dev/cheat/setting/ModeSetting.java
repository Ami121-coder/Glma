package dev.cheat.setting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Строковая настройка с предустановленным списком значений.
 * В отличие от {@link EnumSetting}, не требует объявления enum'а —
 * можно передать список строк напрямую.
 *
 * <pre>
 *   private final ModeSetting color =
 *       new ModeSetting("Color", "Цвет подсветки", "Red",
 *           "Red", "Green", "Blue", "Rainbow");
 * </pre>
 */
public final class ModeSetting extends Setting<String> {

    private final List<String> modes;

    public ModeSetting(String name, String description, String defaultMode, String... modes) {
        super(name, description, defaultMode);
        if (modes == null || modes.length == 0) {
            throw new IllegalArgumentException("ModeSetting requires at least one option");
        }
        this.modes = new ArrayList<>(Arrays.asList(modes));
        if (!this.modes.contains(defaultMode)) {
            this.modes.add(0, defaultMode);
        }
        set(defaultMode, false);
    }

    public List<String> modes() { return Collections.unmodifiableList(modes); }

    public String value() { return get(); }

    public int index() { return modes.indexOf(get()); }

    public boolean is(String v) { return Objects.equals(get(), v); }

    public ModeSetting setMode(String v) {
        if (modes.contains(v)) set(v);
        return this;
    }

    public String cycle() {
        int i = index();
        int next = (i + 1) % modes.size();
        set(modes.get(next));
        return get();
    }

    @Override protected String normalize(String v) {
        return modes.contains(v) ? v : get();
    }

    @Override public Object serialize()          { return get(); }
    @Override public void   deserialize(Object d) {
        if (d instanceof String s && modes.contains(s)) set(s);
    }
    @Override public Type   type()                { return Type.MODE; }
}
