package dev.cheat.setting;

/**
 * Целочисленная настройка (слайдер).
 *
 * <pre>
 *   private final IntSetting cps =
 *       new IntSetting("CPS", "Кликов в секунду", 8, 1, 20);
 * </pre>
 */
public final class IntSetting extends Setting<Integer> {

    private final int min;
    private final int max;
    private final int step;

    public IntSetting(String name, String description, int defaultValue, int min, int max) {
        this(name, description, defaultValue, min, max, 1);
    }

    public IntSetting(String name, String description, int defaultValue,
                      int min, int max, int step) {
        super(name, description, defaultValue);
        if (min > max) throw new IllegalArgumentException("min > max");
        this.min  = min;
        this.max  = max;
        this.step = step <= 0 ? 1 : step;
        set(defaultValue, false);
    }

    public int min()  { return min; }
    public int max()  { return max; }
    public int step() { return step; }

    public int value() { return get(); }

    public double progress() {
        if (max == min) return 0.0;
        return (get() - min) / (double) (max - min);
    }

    /** Устанавливает значение по прогрессу 0..1 (для слайдера). */
    public void setByProgress(double p) {
        p = Math.max(0.0, Math.min(1.0, p));
        int raw = (int) Math.round(min + p * (max - min));
        // округление до шага
        int snapped = min + (int) Math.round((raw - min) / (double) step) * step;
        set(Math.max(min, Math.min(max, snapped)));
    }

    @Override protected Integer normalize(Integer v) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    @Override public Object serialize()          { return get(); }
    @Override public void   deserialize(Object d) {
        if (d instanceof Number n) set(n.intValue());
        else if (d instanceof String s) {
            try { set(Integer.parseInt(s)); } catch (NumberFormatException ignored) {}
        }
    }
    @Override public Type   type()                { return Type.INT; }
}
