package dev.cheat.setting;

/**
 * Булева настройка (чекбокс).
 *
 * <pre>
 *   private final BooleanSetting showWatermark =
 *       new BooleanSetting("Watermark", "Показывать надпись в углу", true);
 * </pre>
 */
public final class BooleanSetting extends Setting<Boolean> {

    public BooleanSetting(String name, String description, boolean defaultValue) {
        super(name, description, defaultValue);
    }

    public boolean value() { return get(); }

    public void toggle() { set(!get()); }

    @Override public Object serialize()            { return get(); }
    @Override public void   deserialize(Object d)   {
        if (d instanceof Boolean b) set(b);
        else if (d instanceof String s) set(Boolean.parseBoolean(s));
    }
    @Override public Type   type()                  { return Type.BOOLEAN; }
}
