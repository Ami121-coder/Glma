package dev.cheat.setting;

/**
 * Настройка-бинд клавиши (GLFW key code).
 *
 * <pre>
 *   private final KeyBindSetting panicKey =
 *       new KeyBindSetting("PanicKey", "Клавиша паники", 0);
 * </pre>
 */
public final class KeyBindSetting extends Setting<Integer> {

    public KeyBindSetting(String name, String description, int defaultKey) {
        super(name, description, defaultKey);
        set(defaultKey, false);
    }

    public int value() { return get(); }

    public boolean hasKey() { return get() != null && get() > 0; }

    public void clear() { set(0); }

    @Override protected Integer normalize(Integer v) {
        if (v == null) return 0;
        if (v < 0) return 0;
        return v;
    }

    @Override public Object serialize()            { return get(); }
    @Override public void   deserialize(Object d)   {
        if (d instanceof Number n) set(n.intValue());
        else if (d instanceof String s) {
            try { set(Integer.parseInt(s)); } catch (NumberFormatException ignored) {}
        }
    }
    @Override public Type   type()                  { return Type.KEYBIND; }
}
