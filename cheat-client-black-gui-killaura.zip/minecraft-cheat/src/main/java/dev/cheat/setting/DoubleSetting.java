package dev.cheat.setting;

/**
 * Вещественная настройка (double slider).
 *
 * <pre>
 *   private final DoubleSetting range =
 *       new DoubleSetting("Range", "Дальность до цели", 4.5, 1.0, 6.0, 0.1);
 * </pre>
 */
public final class DoubleSetting extends Setting<Double> {

    private final double min;
    private final double max;
    private final double step;

    public DoubleSetting(String name, String description, double defaultValue,
                         double min, double max) {
        this(name, description, defaultValue, min, max, 0.01);
    }

    public DoubleSetting(String name, String description, double defaultValue,
                         double min, double max, double step) {
        super(name, description, defaultValue);
        if (min > max) throw new IllegalArgumentException("min > max");
        this.min  = min;
        this.max  = max;
        this.step = step <= 0 ? 0.01 : step;
        set(defaultValue, false);
    }

    public double min()  { return min; }
    public double max()  { return max; }
    public double step() { return step; }

    public double value() { return get(); }

    public double progress() {
        if (max == min) return 0.0;
        return (get() - min) / (max - min);
    }

    public void setByProgress(double p) {
        p = Math.max(0.0, Math.min(1.0, p));
        double raw = min + p * (max - min);
        double snapped = min + Math.round((raw - min) / step) * step;
        set(Math.max(min, Math.min(max, snapped)));
    }

    @Override protected Double normalize(Double v) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    @Override public Object serialize()          { return get(); }
    @Override public void   deserialize(Object d) {
        if (d instanceof Number n) set(n.doubleValue());
        else if (d instanceof String s) {
            try { set(Double.parseDouble(s)); } catch (NumberFormatException ignored) {}
        }
    }
    @Override public Type   type()                { return Type.DOUBLE; }
}
