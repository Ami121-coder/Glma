package dev.cheat.setting;

import dev.cheat.util.ColorUtil;

/**
 * Цветовая настройка (ARGB int). Хранится как int 0xAARRGGBB.
 *
 * <pre>
 *   private final ColorSetting friendColor =
 *       new ColorSetting("FriendColor", "Цвет друзей в ESP", 0xFF00FF00);
 * </pre>
 */
public final class ColorSetting extends Setting<Integer> {

    private boolean alphaEnabled;

    public ColorSetting(String name, String description, int defaultArgb) {
        this(name, description, defaultArgb, true);
    }

    public ColorSetting(String name, String description, int defaultArgb, boolean alphaEnabled) {
        super(name, description, defaultArgb);
        this.alphaEnabled = alphaEnabled;
        set(defaultArgb, false);
    }

    public int value()         { return get(); }
    public int rgb()           { return value() & 0x00FFFFFF; }
    public int alphaByte()     { return (value() >>> 24) & 0xFF; }
    public float alphaNorm()   { return alphaByte() / 255f; }

    public boolean isAlphaEnabled()         { return alphaEnabled; }
    public void    setAlphaEnabled(boolean v) { this.alphaEnabled = v; }

    public int    red()        { return ColorUtil.red(value()); }
    public int    green()      { return ColorUtil.green(value()); }
    public int    blue()       { return ColorUtil.blue(value()); }

    public void setRgb(int rgb) {
        int alpha = alphaEnabled ? (value() & 0xFF000000) : 0xFF000000;
        set(alpha | (rgb & 0x00FFFFFF));
    }

    public void setAlpha(int a255) {
        int a = Math.max(0, Math.min(255, a255));
        set((a << 24) | (value() & 0x00FFFFFF));
    }

    @Override protected Integer normalize(Integer v) {
        if (!alphaEnabled) {
            return 0xFF000000 | (v & 0x00FFFFFF);
        }
        return v;
    }

    @Override public Object serialize() {
        return String.format("#%08X", value());
    }

    @Override public void deserialize(Object d) {
        if (d instanceof String s) {
            set(ColorUtil.fromHex(s));
        } else if (d instanceof Number n) {
            set(n.intValue());
        }
    }

    @Override public Type type() { return Type.COLOR; }
}
