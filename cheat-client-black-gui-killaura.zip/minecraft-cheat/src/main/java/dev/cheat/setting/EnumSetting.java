package dev.cheat.setting;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Enum-настройка. Хранит один из элементов enum'а.
 *
 * <pre>
 *   private enum Mode { VANILLA, SILENT, INSTANT }
 *   private final EnumSetting&lt;Mode&gt; mode =
 *       new EnumSetting&lt;&gt;("Mode", "Режим анти-afk", Mode.VANILLA);
 * </pre>
 */
public final class EnumSetting<T extends Enum<T>> extends Setting<T> {

    private final Class<T> enumType;
    private final Map<String, T> lookup;

    public EnumSetting(String name, String description, T defaultValue) {
        super(name, description, defaultValue);
        //noinspection unchecked
        this.enumType = (Class<T>) defaultValue.getClass();
        this.lookup  = new LinkedHashMap<>();
        for (T v : enumType.getEnumConstants()) {
            lookup.put(v.name().toLowerCase(), v);
        }
    }

    public Class<T> enumType()            { return enumType; }
    public java.util.List<T> options()    { return Arrays.asList(enumType.getEnumConstants()); }

    public T value() { return get(); }

    /** Следующий элемент по кругу (для клика в UI). */
    public T cycle() {
        T[] all = enumType.getEnumConstants();
        int idx = get().ordinal();
        T next = all[(idx + 1) % all.length];
        set(next);
        return next;
    }

    public boolean is(T v) { return Objects.equals(get(), v); }

    @Override public Object serialize() {
        return get().name();
    }

    @Override public void deserialize(Object d) {
        if (d instanceof String s) {
            T v = lookup.get(s.toLowerCase());
            if (v != null) set(v);
        }
    }

    @Override public Type type() { return Type.ENUM; }

    @Override public String toString() {
        return "EnumSetting[" + name() + "=" + get() + ", options="
                + Arrays.stream(enumType.getEnumConstants())
                        .map(Enum::name)
                        .collect(Collectors.joining(",")) + "]";
    }
}
