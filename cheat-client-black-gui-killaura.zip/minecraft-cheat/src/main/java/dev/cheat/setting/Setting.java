package dev.cheat.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Базовый абстрактный класс настройки модуля.
 *
 * <p>Каждая настройка:</p>
 * <ul>
 *   <li>имеет уникальное в пределах модуля имя;</li>
 *   <li>хранит текущее значение {@code T};</li>
 *   <li>опционально уведомляет слушателей через {@link #onChange};</li>
 *   <li>умеет сериализоваться в примитив JSON и обратно через
 *       {@link #serialize()} / {@link #deserialize(Object)}.</li>
 * </ul>
 *
 * <p>Конкретные типы: {@link BooleanSetting}, {@link IntSetting},
 * {@link DoubleSetting}, {@link FloatSetting}, {@link EnumSetting},
 * {@link ModeSetting}, {@link ColorSetting}, {@link StringSetting},
 * {@link KeyBindSetting}.</p>
 *
 * @param <T> тип значения
 */
public abstract class Setting<T> {

    private final String   name;
    private final String   description;
    private final T        defaultValue;
    private       T        value;

    private boolean visible = true;
    private boolean enabled = true;

    private final List<Consumer<T>> listeners = new ArrayList<>();

    protected Setting(String name, String description, T defaultValue) {
        this.name         = name;
        this.description  = description == null ? "" : description;
        this.defaultValue = defaultValue;
        this.value        = defaultValue;
    }

    // ─── Доступ к значению ──────────────────────────────────────

    public T get()                  { return value; }
    public void set(T v)            { set(v, true); }
    public void setSilently(T v)    { set(v, false); }

    protected void set(T v, boolean notify) {
        if (v == null) v = defaultValue;
        T normalized = normalize(v);
        if (normalized.equals(value)) return;
        this.value = normalized;
        if (notify) {
            for (Consumer<T> c : listeners) {
                try { c.accept(value); } catch (Throwable ignored) {}
            }
        }
    }

    /** Хук для подклассов: валидация/клампинг значения. */
    protected T normalize(T v) { return v; }

    public T    getDefault()  { return defaultValue; }
    public void resetDefault(){ set(defaultValue); }

    // ─── Слушатели ──────────────────────────────────────────────

    public Setting<T> onChange(Consumer<T> listener) {
        if (listener != null && !listeners.contains(listener)) listeners.add(listener);
        return this;
    }

    // ─── Видимость/доступность ──────────────────────────────────

    public boolean isVisible()       { return visible; }
    public void    setVisible(boolean v) { this.visible = v; }

    public boolean isEnabled()       { return enabled; }
    public void    setEnabled(boolean v) { this.enabled = v; }

    /**
     * Реактивная видимость: настройка будет активна только когда predicate
     * возвращает true. UI проверяет флаг через {@link #isEnabled()} при отрисовке.
     *
     * <p>Сама проверка происходит лениво — модуль должен вызывать
     * {@link #refreshEnabled(Supplier)} по тику или при изменении условий.</p>
     */
    public Setting<T> condition(Supplier<Boolean> predicate) {
        this.enabledPredicate = predicate;
        return this;
    }

    private Supplier<Boolean> enabledPredicate = null;

    /** Пересчитать доступность настройки по условию (если задано). */
    public void refreshEnabled() {
        if (enabledPredicate != null) {
            try { this.enabled = Boolean.TRUE.equals(enabledPredicate.get()); }
            catch (Throwable ignored) {}
        }
    }

    // ─── Метаданные ─────────────────────────────────────────────

    public String name()        { return name; }
    public String description() { return description; }

    public List<Consumer<T>> listeners() { return Collections.unmodifiableList(listeners); }

    // ─── Сериализация ───────────────────────────────────────────

    /** Преобразует значение в JSON-совместимый объект (String/Number/Boolean/List/Map). */
    public abstract Object serialize();

    /** Восстанавливает значение из JSON-объекта. */
    public abstract void deserialize(Object data);

    /** Тип-маркер для UI-диспетчеризации (какой компонент рисовать). */
    public abstract Type type();

    /** Типы настроек для UI. */
    public enum Type {
        BOOLEAN, INT, DOUBLE, FLOAT, ENUM, MODE, COLOR, STRING, KEYBIND
    }
}
