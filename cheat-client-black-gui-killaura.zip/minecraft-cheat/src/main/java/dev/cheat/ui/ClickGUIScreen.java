package dev.cheat.ui;

import dev.cheat.Client;
import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.ui.component.Frame;
import dev.cheat.ui.component.ModuleButton;
import dev.cheat.ui.component.Component;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI экран. Наследует ванильный {@link Screen}, что позволяет
 * использовать его как {@code mc.setScreen(ClickGUIScreen.get())}.
 *
 * <p>Открывается по правому Shift (бинд в {@link dev.cheat.module.impl.ClickGUIModule}).</p>
 *
 * <p>Чёрная минималистичная тема с фиолетовыми акцентами.
 * Использует кастомный TTF-шрифт (DejaVu Sans) вместо ванильного
 * Minecraft-шрифта.</p>
 *
 * <p>Каждой {@link Category} соответствует один {@link Frame}. Фрейм
 * заполняется {@link ModuleButton} из {@link dev.cheat.manager.ModuleManager#byCategory(Category)}.
 * Drag-and-drop фреймов мышкой, сворачивание по клику на правую часть
 * заголовка.</p>
 */
public final class ClickGUIScreen extends Screen {

    private static ClickGUIScreen instance;

    private final List<Frame> frames = new ArrayList<>();

    private ClickGUIScreen() {
        super(Text.literal("ClickGUI"));
    }

    public static ClickGUIScreen get() {
        if (instance == null) instance = new ClickGUIScreen();
        return instance;
    }

    @Override
    protected void init() {
        rebuildFrames();
    }

    /** Перестраивает фреймы из текущих модулей ModuleManager. */
    public void rebuildFrames() {
        frames.clear();
        if (Client.get() == null) return;

        int frameW = 130;
        int gap = 14;
        int y = 50;

        // Считаем стартовую X так, чтобы все фреймы были видны
        int totalWidth = 0;
        int visibleCats = 0;
        for (Category cat : Category.values()) {
            List<Module> mods = Client.get().moduleManager().byCategory(cat);
            if (mods.isEmpty()) continue;
            visibleCats++;
        }
        totalWidth = visibleCats * frameW + (visibleCats - 1) * gap;

        // Центрируем по горизонтали
        int x = Math.max(20, (this.width - totalWidth) / 2);

        for (Category cat : Category.values()) {
            List<Module> mods = Client.get().moduleManager().byCategory(cat);
            if (mods.isEmpty()) continue;

            Frame frame = new Frame(cat, x, y, frameW);
            // Заполняем кнопками модулей данной категории
            List<Component> buttons = new ArrayList<>();
            for (Module m : mods) {
                if (!m.isVisible()) continue;
                buttons.add(new ModuleButton(m, x, y, frameW));
            }
            if (buttons.isEmpty()) continue;
            frame.populate(buttons);
            frames.add(frame);
            x += frameW + gap;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Полностью непрозрачный чёрный фон — мир за GUI не виден
        ctx.fill(0, 0, width, height, 0xFF000000);

        Theme t = Client.get().theme();

        // Заголовок GUI сверху-слева
        String title = "CHEAT CLIENT";
        RenderUtil.textGlow(ctx, title, 20, 18,
                ColorUtil.alpha(t.accent(), 0.95f));

        // Подзаголовок — версия
        String subtitle = "v" + dev.cheat.CheatClient.VERSION
                + "  ·  RIGHT SHIFT to toggle";
        RenderUtil.textSoftShadow(ctx, subtitle, 20, 30,
                ColorUtil.alpha(0xFFFFFFFF, 0.55f));

        // Подсказка внизу справа
        String hint = "LMB toggle  ·  RMB settings  ·  ESC close";
        int hintW = RenderUtil.textWidth(hint);
        RenderUtil.textSoftShadow(ctx, hint, width - hintW - 20, height - 16,
                ColorUtil.alpha(0xFFFFFFFF, 0.4f));

        for (Frame f : frames) {
            f.render(ctx, mouseX, mouseY, delta);
        }
        // НЕ вызываем super.render() — он вызывает renderBackground(),
        // который применяет ванильный blur на весь экран.
        // Рисуем виджеты (кнопки и т.д.) вручную через drawables, если нужны.
    }

    /**
     * Переопределяем renderBackground, чтобы НЕ вызывать ванильный
     * {@code applyBlur()} + {@code renderDarkening()}.
     *
     * <p>В 1.21.4 {@link Screen#renderBackground} вызывает
     * {@code this.client.gameRenderer.renderBlur()} — это размывает
     * весь framebuffer. Для ClickGUI это нежелательно: мы рисуем
     * свой непрозрачный чёрный фон в {@link #render}.</p>
     */
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // no-op — не применяем ванильный blur и darkening
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (Frame f : frames) {
            if (f.mouseClicked(mouseX, mouseY, button)) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        for (Frame f : frames) f.mouseDragged(mouseX, mouseY, button, dx, dy);
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (Frame f : frames) f.mouseReleased(mouseX, mouseY, button);
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (Frame f : frames) {
            if (f.keyPressed(keyCode, scanCode, modifiers)) return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        for (Frame f : frames) {
            if (f.charTyped(chr, modifiers)) return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
