package dev.cheat.ui.component;

import dev.cheat.module.Category;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.Animation;
import dev.cheat.render.anim.Easing;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Фрейм — вертикальный аккордеон для одной категории модулей.
 *
 * <p>Чёрная минималистичная тема с тонкими фиолетовыми акцентами.
 * Использует {@link Render2D#roundedRect} для скругления, плавную
 * анимацию collapse/expand и градиентный заголовок с мягкой подсветкой.</p>
 */
public class Frame extends Component {

    private static final int HEADER_H = 22;

    private final Category category;
    private final List<Component> children = new ArrayList<>();

    private final Animation collapseAnim = new Animation(0.32f, Easing.CUBIC_IN_OUT);
    private boolean collapsed = false;
    private boolean dragging   = false;
    private double dragOffsetX, dragOffsetY;

    private int expandedHeight = 0;

    public Frame(Category category, int x, int y, int width) {
        super(x, y, width, HEADER_H);
        this.category = category;
    }

    public void populate(List<Component> components) {
        children.clear();
        children.addAll(components);
        layoutChildren();
    }

    private void layoutChildren() {
        int cy = y + HEADER_H; // под заголовком
        for (Component c : children) {
            c.setX(x);
            c.setY(cy);
            c.setWidth(width);
            cy += c.getHeight();
        }
        expandedHeight = HEADER_H + children.stream().mapToInt(Component::getHeight).sum();
        // Текущая высота = лерп между collapsed (HEADER_H) и expanded
        float t = collapseAnim.value();
        this.height = (int) (HEADER_H + (expandedHeight - HEADER_H) * t);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        Theme t = dev.cheat.Client.get().theme();

        // Обновляем анимацию
        collapseAnim.update(0.016f);
        if (collapsed && collapseAnim.isForward()) collapseAnim.playBackward();
        else if (!collapsed && !collapseAnim.isForward() && !collapseAnim.isFinished()) {
            // Продолжаем expansion
        } else if (!collapsed && collapseAnim.isFinished() && collapseAnim.raw() < 0.5f) {
            collapseAnim.playForward();
        }
        layoutChildren();

        // ─── Контейнер фрейма ───────────────────────────────────
        float currH = this.height;

        // Основной фон фрейма — глубокий чёрный
        Render2D.roundedRect(ctx, x, y, width, currH, t.radius(), t.panel());

        // Тонкая акцентная полоса сверху (1.5px) — простая заливка, без градиента
        Render2D.roundedRect(ctx, x, y, width, 1.5f, 1f, t.accent());

        // ─── Заголовок ──────────────────────────────────────────
        // Декоративная акцентная точка слева
        Render2D.roundedRect(ctx, x + 6, y + (HEADER_H - 4) / 2f, 4, 4, 1.5f, t.accent());

        // Текст заголовка — uppercase, кастомный шрифт
        String title = category.displayName().toUpperCase();
        int titleY = y + (HEADER_H - RenderUtil.fontHeight()) / 2 + 1;
        RenderUtil.textSoftShadow(ctx, title, x + 14, titleY, 0xFFFFFFFF);

        // Индикатор свёрнутости (тонкая стрелка)
        String ind = collapsed ? "▶" : "▼";
        RenderUtil.textSoftShadow(ctx, ind, x + width - 14, titleY,
                ColorUtil.alpha(t.accent(), 0.85f));

        // ─── Контент ────────────────────────────────────────────
        if (collapseAnim.value() > 0.05f) {
            // Обрезка контента через scissors — чтобы не вылезал за пределы
            Render2D.scissors(x, y + HEADER_H, width, currH - HEADER_H);

            // Лёгкий внутренний отступ
            int padX = 3;
            for (Component c : children) {
                c.setX(x + padX);
                c.setWidth(width - padX * 2);
                c.render(ctx, mouseX, mouseY, delta);
            }
            Render2D.disableScissors();
        }

        // Тонкая нижняя граница заголовка (разделитель)
        if (collapseAnim.value() > 0.05f) {
            Render2D.hLine(ctx, x + 4, y + HEADER_H, width - 8,
                    ColorUtil.alpha(t.accent(), 0.18f));
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            // Клик по заголовку (верхние HEADER_H px)
            if (my < y + HEADER_H) {
                if (mx > x + width - 22) {
                    collapsed = !collapsed;
                    if (collapsed) collapseAnim.playBackward();
                    else           collapseAnim.playForward();
                } else {
                    dragging = true;
                    dragOffsetX = mx - x;
                    dragOffsetY = my - y;
                }
                return true;
            }
        }
        // Проброс детям только если раскрыт
        if (!collapsed) {
            for (Component c : children) {
                if (c.mouseClicked(mx, my, button)) return true;
            }
        }
        return false;
    }

    @Override
    public void mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            x = (int) (mx - dragOffsetX);
            y = (int) (my - dragOffsetY);
            layoutChildren();
        }
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) dragging = false;
        for (Component c : children) c.mouseReleased(mx, my, button);
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!collapsed) {
            for (Component c : children) {
                if (c.keyPressed(keyCode, scanCode, modifiers)) return true;
            }
        }
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!collapsed) {
            for (Component c : children) {
                if (c.charTyped(chr, modifiers)) return true;
            }
        }
        return false;
    }
}
