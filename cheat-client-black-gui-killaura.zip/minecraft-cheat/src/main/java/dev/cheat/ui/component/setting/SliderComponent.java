package dev.cheat.ui.component.setting;

import dev.cheat.Client;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.setting.IntSetting;
import dev.cheat.setting.DoubleSetting;
import dev.cheat.setting.FloatSetting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Слайдер для числовых настроек (int / double / float).
 *
 * <p>Чёрная минималистичная тема с фиолетовым акцентом на прогрессе.</p>
 *
 * <p>Класс предоставляет три static nested класса для конкретных типов.</p>
 */
public abstract class SliderComponent<S extends dev.cheat.setting.Setting<?>> extends SettingComponent<S> {

    protected boolean dragging = false;
    protected double dragStartX = 0;
    protected double dragStartProgress = 0;
    protected final FloatValue hoverAnim = new FloatValue(0f, 0.18f, Easing.SINE_OUT);

    public static final int HEIGHT = 18;

    protected SliderComponent(S setting) {
        super(setting);
        this.height = HEIGHT;
    }

    protected abstract double progress();
    protected abstract void   setByProgress(double p);
    protected abstract String valueText();

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        hoverAnim.setTarget(hovered || dragging ? 1f : 0f);
        hoverAnim.update(delta / 1000f);

        // Фон — мягкий чёрный
        int bg = ColorUtil.lerp(theme.component(), theme.componentHover(),
                hoverAnim.value() * 0.5f);
        Render2D.roundedRect(ctx, x, y, width, height, theme.radius(),
                ColorUtil.alpha(bg, 0.5f));

        // Лейбл + значение
        RenderUtil.textSoftShadow(ctx, setting.name(),
                x + 6, y + 3, theme.text());
        String val = valueText();
        RenderUtil.textSoftShadow(ctx, val,
                x + width - RenderUtil.textWidth(val) - 6, y + 3,
                theme.accent());

        // Track — тонкая линия внизу
        int tx = x + 6;
        int tw = width - 12;
        int ty = y + height - 5;
        Render2D.roundedRect(ctx, tx, ty, tw, 2, 1f,
                ColorUtil.alpha(0xFFFFFFFF, 0.12f));

        // Заполненная часть — фиолетовый акцент
        double p = progress();
        int fw = (int) (tw * p);
        if (fw > 0) {
            Render2D.roundedRect(ctx, tx, ty, fw, 2, 1f, theme.accent());
        }

        // Ползунок — маленький кружок
        float knobX = tx + fw - 3f;
        int knobSize = 6;
        // Сам кружок
        int knobColor = ColorUtil.lerp(theme.accent(), theme.accent2(), (float) p);
        Render2D.roundedRect(ctx, knobX, ty - 2, knobSize, knobSize,
                knobSize / 2f, knobColor);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            dragging = true;
            dragStartX = mx;
            dragStartProgress = progress();
            // Сразу перематываем к позиции клика
            handleDrag(mx);
            return true;
        }
        return false;
    }

    @Override
    public void mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            handleDrag(mx);
        }
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) dragging = false;
        return false;
    }

    private void handleDrag(double mx) {
        int tx = x + 6;
        int tw = width - 12;
        if (tw <= 0) return;
        double p = (mx - tx) / (double) tw;
        setByProgress(p);
    }

    // ─── Конкретные реализации для типов ────────────────────────

    public static final class ForInt extends SliderComponent<IntSetting> {
        public ForInt(IntSetting s) { super(s); }
        @Override protected double progress()      { return setting.progress(); }
        @Override protected void   setByProgress(double p) { setting.setByProgress(p); }
        @Override protected String valueText()     { return Integer.toString(setting.value()); }
    }

    public static final class Double extends SliderComponent<DoubleSetting> {
        public Double(DoubleSetting s) { super(s); }
        @Override protected double progress()      { return setting.progress(); }
        @Override protected void   setByProgress(double p) { setting.setByProgress(p); }
        @Override protected String valueText()     { return String.format("%.2f", setting.value()); }
    }

    public static final class Float extends SliderComponent<FloatSetting> {
        public Float(FloatSetting s) { super(s); }
        @Override protected double progress()      { return setting.progress(); }
        @Override protected void   setByProgress(double p) { setting.setByProgress((float) p); }
        @Override protected String valueText()     { return String.format("%.2f", setting.value()); }
    }
}
