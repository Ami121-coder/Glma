package dev.cheat.ui.theme;

import dev.cheat.util.ColorUtil;

/**
 * Расширенная тема оформления ClickGUI.
 *
 * <p>Содержит не только базовые цвета, но и градиентные пары, тени,
 * accent-вариации — для богатого визуального языка.</p>
 */
public final class Theme {

    // ─── Базовые пресеты ─────────────────────────────────────

    public static final Theme DEFAULT = new Theme(
            "default",
            0xF0000000, // background  (ARGB; alpha=0xF0 ≈ 94% — почти чёрный, лёгкая прозрачность)
            0xFF0A0A0A, // panel       (глубокий чёрный с лёгким оттенком)
            0xFF141414, // component   (чуть светлее чёрного)
            0xFF1F1F1F, // component-hover
            0xFF7C5CFF, // accent (фиолетовый неон)
            0xFF5B3FD9, // accent-2 (тёмный фиолетовый, для градиентов)
            0xFFFFFFFF, // text (чистый белый)
            0xFF8A8A8A, // text-secondary (приглушённый серый)
            0xFF000000, // shadow
            0x407C5CFF, // border-glow (мягкое фиолетовое свечение)
            6f,         // radius
            10f         // radius-large
    );

    public static final Theme DARK = new Theme(
            "dark",
            0xF00A0A0A,
            0xFF0F0F0F,
            0xFF181818,
            0xFF262626,
            0xFF5E5CE6,
            0xFF3D3BD1,
            0xFFFFFFFF,
            0xFF7A7A7A,
            0xFF000000,
            0x335E5CE6,
            6f,
            10f
    );

    public static final Theme LIGHT = new Theme(
            "light",
            0xE6F5F5F5,
            0xFFFFFFFF,
            0xFFEEEEEE,
            0xFFE0E0E0,
            0xFF9B59B6,
            0xFF7D3C98,
            0xFF212121,
            0xFF707070,
            0x33000000,
            0x33000000,
            6f,
            14f
    );

    public static final Theme MIDNIGHT = new Theme(
            "midnight",
            0xE60A0E27,
            0xFF11142E,
            0xFF1B1F3B,
            0xFF252A4A,
            0xFF00D4FF,
            0xFF0099CC,
            0xFFE0F7FF,
            0xFF7FA8AD,
            0xFF000000,
            0x5500D4FF,
            6f,
            16f
    );

    // ─── Поля ────────────────────────────────────────────────

    private final String name;
    private final int background;
    private final int panel;
    private final int component;
    private final int componentHover;
    private final int accent;
    private final int accent2;
    private final int text;
    private final int textSecondary;
    private final int shadow;
    private final int borderGlow;
    private final float radius;
    private final float radiusLarge;

    public Theme(String name,
                 int background, int panel, int component, int componentHover,
                 int accent, int accent2,
                 int text, int textSecondary,
                 int shadow, int borderGlow,
                 float radius, float radiusLarge) {
        this.name            = name;
        this.background      = background;
        this.panel           = panel;
        this.component       = component;
        this.componentHover  = componentHover;
        this.accent          = accent;
        this.accent2         = accent2;
        this.text            = text;
        this.textSecondary   = textSecondary;
        this.shadow          = shadow;
        this.borderGlow      = borderGlow;
        this.radius          = radius;
        this.radiusLarge     = radiusLarge;
    }

    // Геттеры
    public String name()              { return name;            }
    public int    background()        { return background;      }
    public int    panel()             { return panel;           }
    public int    component()         { return component;       }
    public int    componentHover()    { return componentHover;  }
    public int    accent()            { return accent;          }
    public int    accent2()           { return accent2;         }
    public int    text()              { return text;            }
    public int    textSecondary()     { return textSecondary;   }
    public int    shadow()            { return shadow;          }
    public int    borderGlow()        { return borderGlow;      }
    public float  radius()            { return radius;          }
    public float  radiusLarge()       { return radiusLarge;     }

    // ─── Производные палитры ─────────────────────────────────

    public int accentAt(float t) {
        return ColorUtil.lerp(accent, accent2, t);
    }

    public int lighten(int color, float amount) {
        return ColorUtil.lighten(color, amount);
    }

    public int darken(int color, float amount) {
        return ColorUtil.darken(color, amount);
    }

    public int withAlpha(int color, float alpha) {
        return ColorUtil.alpha(color, alpha);
    }

    // ─── Поиск по имени ──────────────────────────────────────

    public static Theme byName(String name) {
        if (name == null) return DEFAULT;
        return switch (name.toLowerCase()) {
            case "dark"      -> DARK;
            case "light"     -> LIGHT;
            case "midnight"  -> MIDNIGHT;
            default          -> DEFAULT;
        };
    }

    public static Theme[] all() {
        return new Theme[]{ DEFAULT, DARK, LIGHT, MIDNIGHT };
    }
}
