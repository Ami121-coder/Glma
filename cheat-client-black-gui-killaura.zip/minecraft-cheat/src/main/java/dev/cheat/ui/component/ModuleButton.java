package dev.cheat.ui.component;

import dev.cheat.Client;
import dev.cheat.module.Module;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.ui.component.setting.BooleanToggle;
import dev.cheat.ui.component.setting.ModeButton;
import dev.cheat.ui.component.setting.SettingComponent;
import dev.cheat.ui.component.setting.SliderComponent;
import dev.cheat.ui.component.setting.ColorButton;
import dev.cheat.ui.component.setting.KeyBindButton;
import dev.cheat.ui.component.setting.StringComponent;
import dev.cheat.setting.Setting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Кнопка модуля в ClickGUI.
 *
 * <p>Чёрная минималистичная эстетика с фиолетовым акцентом.</p>
 *
 * <p>Левый клик — toggle модуля.
 * Правый клик — раскрыть/свернуть список настроек.
 * Каждая настройка получает свой компонент через {@link #componentFor(Setting)}.</p>
 */
public class ModuleButton extends Component {

    private final Module module;
    private final List<Component> settingComponents = new ArrayList<>();

    private final FloatValue hoverAnim;
    private final FloatValue enabledAnim;
    private boolean expanded = false;
    private final FloatValue expandAnim = new FloatValue(0f, 0.30f, Easing.CUBIC_IN_OUT);

    private static final int BUTTON_H = 18;

    public ModuleButton(Module module, int x, int y, int width) {
        super(x, y, width, BUTTON_H);
        this.module = module;
        this.hoverAnim   = new FloatValue(0f, 0.18f, Easing.SINE_OUT);
        this.enabledAnim = new FloatValue(module.isEnabled() ? 1f : 0f, 0.25f, Easing.QUAD_IN_OUT);
        rebuildSettingComponents();
    }

    private void rebuildSettingComponents() {
        settingComponents.clear();
        if (module.settings().isEmpty()) return;
        for (Setting<?> s : module.settings().visible()) {
            SettingComponent<?> c = componentFor(s);
            if (c != null) settingComponents.add(c);
        }
    }

    private SettingComponent<?> componentFor(Setting<?> s) {
        return switch (s.type()) {
            case BOOLEAN -> new BooleanToggle((dev.cheat.setting.BooleanSetting) s);
            case INT     -> new SliderComponent.ForInt((dev.cheat.setting.IntSetting) s);
            case DOUBLE  -> new SliderComponent.Double((dev.cheat.setting.DoubleSetting) s);
            case FLOAT   -> new SliderComponent.Float((dev.cheat.setting.FloatSetting) s);
            case ENUM    -> new ModeButton.FromEnum((dev.cheat.setting.EnumSetting<?>) s);
            case MODE    -> new ModeButton.FromMode((dev.cheat.setting.ModeSetting) s);
            case COLOR   -> new ColorButton((dev.cheat.setting.ColorSetting) s);
            case KEYBIND -> new KeyBindButton((dev.cheat.setting.KeyBindSetting) s);
            case STRING  -> new StringComponent((dev.cheat.setting.StringSetting) s);
        };
    }

    public Module module() { return module; }

    @Override
    public int getHeight() {
        // Базовая высота кнопки + раскрытая часть (с анимацией)
        int extra = 0;
        if (!settingComponents.isEmpty()) {
            int full = settingComponents.stream().mapToInt(Component::getHeight).sum();
            extra = (int) (full * expandAnim.value());
        }
        return BUTTON_H + extra;
    }

    @Override
    public void setX(int x) {
        super.setX(x);
        layoutSettings();
    }

    @Override
    public void setY(int y) {
        super.setY(y);
        layoutSettings();
    }

    @Override
    public void setWidth(int w) {
        super.setWidth(w);
        layoutSettings();
    }

    private void layoutSettings() {
        int cy = y + BUTTON_H;
        for (Component c : settingComponents) {
            c.setX(x + 2);
            c.setY(cy);
            c.setWidth(width - 4);
            cy += c.getHeight();
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        hoverAnim.setTarget(hovered ? 1f : 0f);
        hoverAnim.update(delta / 1000f);
        enabledAnim.setTarget(module.isEnabled() ? 1f : 0f);
        enabledAnim.update(delta / 1000f);
        expandAnim.setTarget(expanded ? 1f : 0f);
        expandAnim.update(delta / 1000f);

        // Фон кнопки — глубокий чёрный с лёгким осветлением при hover
        int bg = ColorUtil.lerp(theme.component(), theme.componentHover(), hoverAnim.value());
        // Лёгкий фиолетовый оттенок при enabled
        bg = ColorUtil.blendOver(bg, ColorUtil.alpha(theme.accent(), 0.15f * enabledAnim.value()));
        Render2D.roundedRect(ctx, x, y, width, BUTTON_H, theme.radius(), bg);

        // Левая акцентная полоска (если включён) — мягкое фиолетовое свечение
        if (enabledAnim.value() > 0.01f) {
            int stripe = ColorUtil.alpha(theme.accent(), 0.95f * enabledAnim.value());
            Render2D.roundedRect(ctx, x, y + 2, 2, BUTTON_H - 4, 1f, stripe);
        }

        // Текст названия — белый, переходящий в акцентный цвет при enabled
        int textColor = ColorUtil.lerp(theme.text(), theme.accent(),
                enabledAnim.value() * 0.85f);
        int textY = y + (BUTTON_H - RenderUtil.fontHeight()) / 2 + 1;
        RenderUtil.textSoftShadow(ctx, module.getName(), x + 8, textY, textColor);

        // Индикатор раскрытия настроек — тонкая стрелка справа
        if (!settingComponents.isEmpty()) {
            String ind = expanded ? "▼" : "▶";
            int indColor = ColorUtil.alpha(theme.textSecondary(),
                    0.7f + 0.3f * hoverAnim.value());
            RenderUtil.textSoftShadow(ctx, ind, x + width - 12, textY, indColor);
        }

        // Анимированное раскрытие настроек
        if (expandAnim.value() > 0.01f && !settingComponents.isEmpty()) {
            // Прозрачность зависящая от прогресса анимации
            Render2D.scissors(x, y + BUTTON_H, width,
                    (int) (settingComponents.stream().mapToInt(Component::getHeight).sum()
                            * expandAnim.value()));
            for (Component c : settingComponents) {
                c.render(ctx, mouseX, mouseY, delta);
            }
            Render2D.disableScissors();
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!isHovered(mx, my) && !(expanded && my > y + BUTTON_H && my < y + getHeight()
                && mx >= x && mx <= x + width)) {
            return false;
        }
        // Клик по телу кнопки
        if (my >= y && my <= y + BUTTON_H) {
            if (button == 0) {
                module.toggle();
                return true;
            } else if (button == 1) {
                if (!settingComponents.isEmpty()) {
                    expanded = !expanded;
                }
                return true;
            } else if (button == 2) {
                // Middle = hide/show in ClickGUI later
                return true;
            }
            return false;
        }
        // Клик по настройкам
        if (expanded) {
            for (Component c : settingComponents) {
                if (c.mouseClicked(mx, my, button)) return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (expanded) {
            for (Component c : settingComponents) c.mouseReleased(mx, my, button);
        }
        return false;
    }

    @Override
    public void mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (expanded) {
            for (Component c : settingComponents) c.mouseDragged(mx, my, button, dx, dy);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (expanded) {
            for (Component c : settingComponents) {
                if (c.keyPressed(keyCode, scanCode, modifiers)) return true;
            }
        }
        return false;
    }
}
