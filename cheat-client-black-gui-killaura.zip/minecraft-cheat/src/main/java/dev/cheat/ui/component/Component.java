package dev.cheat.ui.component;

/**
 * Базовый компонент UI. Все виджеты ClickGUI наследуются от него.
 *
 * <p>Каркас оставляет базовый контракт: позиция, размер, рендер, обработчик
 * клика/наведения. Конкретные компоненты (Button, Slider, Toggle, Frame)
 * добавляются разработчиком.</p>
 */
public abstract class Component {

    protected int x, y, width, height;
    protected boolean hovered = false;
    protected boolean visible = true;

    public Component(int x, int y, int width, int height) {
        this.x = x; this.y = y;
        this.width = width; this.height = height;
    }

    public abstract void render(net.minecraft.client.gui.DrawContext ctx, int mouseX, int mouseY, float delta);

    /** Возвращает true если клик «съеден» этим компонентом. */
    public boolean mouseClicked(double mouseX, double mouseY, int button) { return false; }

    public boolean mouseReleased(double mouseX, double mouseY, int button) { return false; }

    public void mouseDragged(double mx, double my, int button, double dx, double dy) {}

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) { return false; }

    public boolean charTyped(char chr, int modifiers) { return false; }

    // ─── Геттеры/сеттеры ──────────────────────────────────────
    public int getX()      { return x; }
    public int getY()      { return y; }
    public int getWidth()  { return width; }
    public int getHeight() { return height; }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setWidth(int w)  { this.width = w; }
    public void setHeight(int h) { this.height = h; }

    public boolean isVisible() { return visible; }
    public void setVisible(boolean v) { this.visible = v; }

    public boolean isHovered(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }

    protected void updateHover(double mx, double my) {
        this.hovered = isHovered(mx, my);
    }
}
