package dev.cheat.ui.component.setting;

import dev.cheat.Client;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.setting.StringSetting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Текстовое поле для {@link StringSetting}.
 * ЛКМ — войти в режим ввода, следующая клавиша добавляется к строке.
 * ESC — выйти без сохранения, ENTER — выйти с сохранением.
 */
public final class StringComponent extends SettingComponent<StringSetting> {

    private boolean editing = false;
    private final StringBuilder buffer = new StringBuilder();
    private final FloatValue hoverAnim = new FloatValue(0f, 0.18f, Easing.SINE_OUT);

    public StringComponent(StringSetting setting) {
        super(setting);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        hoverAnim.setTarget(hovered || editing ? 1f : 0f);
        hoverAnim.update(delta / 1000f);

        int bg = ColorUtil.lerp(theme.component(), theme.accent(), editing ? 0.4f : hoverAnim.value() * 0.4f);
        Render2D.roundedRect(ctx, x, y, width, height, theme.radius(),
                ColorUtil.alpha(bg, 0.7f));

        RenderUtil.textSoftShadow(ctx, setting.name(),
                x + 4, y + (height - RenderUtil.fontHeight()) / 2 + 1, theme.text());

        String shown = editing ? buffer.toString() + "_" : setting.value();
        int color = editing ? theme.accent() : theme.textSecondary();
        int w = RenderUtil.textWidth(shown);
        RenderUtil.textSoftShadow(ctx, shown,
                x + width - w - 4,
                y + (height - RenderUtil.fontHeight()) / 2 + 1, color);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            editing = !editing;
            if (editing) {
                buffer.setLength(0);
                buffer.append(setting.value());
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!editing) return false;
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            editing = false;
            return true;
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER) {
            setting.set(buffer.toString());
            editing = false;
            return true;
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE) {
            if (buffer.length() > 0) buffer.deleteCharAt(buffer.length() - 1);
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!editing) return false;
        if (buffer.length() < setting.maxLength()) {
            buffer.append(chr);
        }
        return true;
    }
}
