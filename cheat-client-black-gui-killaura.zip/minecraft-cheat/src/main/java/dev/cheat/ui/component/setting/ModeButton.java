package dev.cheat.ui.component.setting;

import dev.cheat.Client;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.setting.EnumSetting;
import dev.cheat.setting.ModeSetting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Кнопка выбора режима (для {@link EnumSetting} и {@link ModeSetting}).
 * ЛКМ — следующий режим, ПКМ — предыдущий.
 */
public abstract class ModeButton<S extends dev.cheat.setting.Setting<?>> extends SettingComponent<S> {

    private final FloatValue hoverAnim = new FloatValue(0f, 0.18f, Easing.SINE_OUT);

    protected ModeButton(S setting) {
        super(setting);
    }

    protected abstract String currentText();
    protected abstract void   cycle(boolean forward);

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        hoverAnim.setTarget(hovered ? 1f : 0f);
        hoverAnim.update(delta / 1000f);

        // Фон
        int bg = ColorUtil.lerp(theme.component(), theme.componentHover(), hoverAnim.value() * 0.6f);
        Render2D.roundedRect(ctx, x, y, width, height, theme.radius(),
                ColorUtil.alpha(bg, 0.7f));

        // Лейбл
        RenderUtil.textSoftShadow(ctx, setting.name(),
                x + 4, y + (height - RenderUtil.fontHeight()) / 2 + 1, theme.text());

        // Текущее значение справа
        String val = currentText();
        int valColor = theme.accent();
        int valW = RenderUtil.textWidth(val);
        RenderUtil.textSoftShadow(ctx, val,
                x + width - valW - 4,
                y + (height - RenderUtil.fontHeight()) / 2 + 1, valColor);

        // Стрелки-индикаторы
        String arrows = "< >";
        int arColor = ColorUtil.alpha(theme.textSecondary(), 0.6f + 0.4f * hoverAnim.value());
        RenderUtil.textSoftShadow(ctx, arrows,
                x + width - valW - 18,
                y + (height - RenderUtil.fontHeight()) / 2 + 1, arColor);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (isHovered(mx, my)) {
            if (button == 0) { cycle(true);  return true; }
            if (button == 1) { cycle(false); return true; }
        }
        return false;
    }

    // ─── Конкретные реализации ──────────────────────────────────

    public static final class FromEnum<T extends Enum<T>> extends ModeButton<EnumSetting<T>> {
        public FromEnum(EnumSetting<T> s) { super(s); }
        @Override protected String currentText() { return setting.value().name(); }
        @Override protected void cycle(boolean forward) {
            T[] all = setting.enumType().getEnumConstants();
            int idx = setting.value().ordinal();
            int next = ((forward ? idx + 1 : idx - 1) % all.length + all.length) % all.length;
            setting.set(all[next]);
        }
    }

    public static final class FromMode extends ModeButton<ModeSetting> {
        public FromMode(ModeSetting s) { super(s); }
        @Override protected String currentText() { return setting.value(); }
        @Override protected void cycle(boolean forward) {
            var modes = setting.modes();
            int idx = setting.index();
            int next = ((forward ? idx + 1 : idx - 1) % modes.size() + modes.size()) % modes.size();
            setting.set(modes.get(next));
        }
    }
}
