package dev.cheat.ui.component.setting;

import dev.cheat.Client;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.setting.KeyBindSetting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Компонент выбора клавиши для {@link KeyBindSetting}.
 *
 * <p>ЛКМ — начать прослушивание клавиши (когда включено listening,
 * следующая нажатая клавиша становится новым биндом).
 * ПКМ — очистить бинд.</p>
 */
public final class KeyBindButton extends SettingComponent<KeyBindSetting> {

    private boolean listening = false;
    private final FloatValue hoverAnim = new FloatValue(0f, 0.18f, Easing.SINE_OUT);

    public KeyBindButton(KeyBindSetting setting) {
        super(setting);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        hoverAnim.setTarget(hovered || listening ? 1f : 0f);
        hoverAnim.update(delta / 1000f);

        int bg = ColorUtil.lerp(theme.component(), theme.accent(), listening ? 0.4f : hoverAnim.value() * 0.4f);
        Render2D.roundedRect(ctx, x, y, width, height, theme.radius(),
                ColorUtil.alpha(bg, 0.7f));

        RenderUtil.textSoftShadow(ctx, setting.name(),
                x + 4, y + (height - RenderUtil.fontHeight()) / 2 + 1, theme.text());

        String label = listening ? "..." : (setting.hasKey() ? keyCodeToName(setting.value()) : "NONE");
        int color = listening ? theme.accent() : theme.textSecondary();
        int w = RenderUtil.textWidth(label);
        RenderUtil.textSoftShadow(ctx, label,
                x + width - w - 4,
                y + (height - RenderUtil.fontHeight()) / 2 + 1, color);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            listening = !listening;
            return true;
        }
        if (button == 1 && isHovered(mx, my)) {
            setting.clear();
            listening = false;
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening) {
            if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
                listening = false;
                return true;
            }
            setting.set(keyCode);
            listening = false;
            return true;
        }
        return false;
    }

    private static String keyCodeToName(int code) {
        try {
            // GLFW_PRESS = 1, нажатая клавиша известна по коду
            String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(code, 0);
            if (name != null) return name.toUpperCase();
        } catch (Throwable ignored) {}
        // Имя константы GLFW_KEY_*
        for (var f : org.lwjgl.glfw.GLFW.class.getDeclaredFields()) {
            if (f.getName().startsWith("GLFW_KEY_") && f.getType() == int.class) {
                try {
                    if (f.getInt(null) == code) {
                        return f.getName().substring("GLFW_KEY_".length());
                    }
                } catch (Throwable ignored) {}
            }
        }
        return "KEY_" + code;
    }
}
