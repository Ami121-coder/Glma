package dev.cheat.ui.component.setting;

import dev.cheat.setting.Setting;
import dev.cheat.ui.component.Component;

/**
 * Базовый класс компонента настройки в ClickGUI.
 *
 * <p>Каждый подкласс привязывается к конкретному {@link Setting} и
 * отражает его значение. Ширина/позиция задаются родителем
 * {@link dev.cheat.ui.component.ModuleButton}.</p>
 *
 * @param <S> тип настройки
 */
public abstract class SettingComponent<S extends Setting<?>> extends Component {

    protected final S setting;
    protected boolean expanded = false;

    public static final int HEIGHT = 14;

    protected SettingComponent(S setting) {
        super(0, 0, 0, HEIGHT);
        this.setting = setting;
    }

    public S setting() { return setting; }
}
