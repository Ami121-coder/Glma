package dev.cheat.ui.component.setting;

import dev.cheat.Client;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.setting.BooleanSetting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Чекбокс для {@link BooleanSetting}.
 *
 * <p>Чёрная тема: тумблер с фиолетовой подсветкой при включении.</p>
 */
public final class BooleanToggle extends SettingComponent<BooleanSetting> {

    private final FloatValue toggleAnim;
    private final FloatValue hoverAnim;

    public BooleanToggle(BooleanSetting setting) {
        super(setting);
        this.toggleAnim = new FloatValue(
                setting.value() ? 1f : 0f, 0.20f, Easing.QUAD_IN_OUT);
        this.hoverAnim = new FloatValue(0f, 0.18f, Easing.SINE_OUT);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        toggleAnim.setTarget(setting.value() ? 1f : 0f);
        toggleAnim.update(delta / 1000f);
        hoverAnim.setTarget(hovered ? 1f : 0f);
        hoverAnim.update(delta / 1000f);

        // Фон-полоска — мягкий чёрный с лёгким осветлением при hover
        int bg = ColorUtil.lerp(theme.component(), theme.componentHover(),
                hoverAnim.value() * 0.6f);
        Render2D.roundedRect(ctx, x, y, width, height, theme.radius(),
                ColorUtil.alpha(bg, 0.5f));

        // Лейбл
        int labelColor = ColorUtil.lerp(theme.text(), theme.accent(),
                toggleAnim.value() * 0.6f);
        int labelY = y + (height - RenderUtil.fontHeight()) / 2 + 1;
        RenderUtil.textSoftShadow(ctx, setting.name(), x + 6, labelY, labelColor);

        // Современный тумблер (switch) справа
        int trackW = 18;
        int trackH = 9;
        int tx = x + width - trackW - 6;
        int ty = y + (height - trackH) / 2;

        // Track — фон тумблера
        int trackBg = ColorUtil.lerp(
                ColorUtil.alpha(0xFFFFFFFF, 0.12f),
                ColorUtil.alpha(theme.accent(), 0.6f),
                toggleAnim.value());
        Render2D.roundedRect(ctx, tx, ty, trackW, trackH, trackH / 2f, trackBg);

        // Knob — кружок-ползунок
        int knobSize = 7;
        float knobX = tx + 1f + (trackW - knobSize - 2f) * toggleAnim.value();
        float knobY = ty + (trackH - knobSize) / 2f;
        int knobColor = toggleAnim.value() > 0.5f
                ? 0xFFFFFFFF
                : ColorUtil.alpha(0xFFFFFFFF, 0.85f);
        Render2D.roundedRect(ctx, knobX, knobY, knobSize, knobSize,
                knobSize / 2f, knobColor);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            setting.toggle();
            return true;
        }
        return false;
    }
}
