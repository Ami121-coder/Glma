package dev.cheat.ui.component.setting;

import dev.cheat.Client;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.FloatValue;
import dev.cheat.render.anim.Easing;
import dev.cheat.setting.ColorSetting;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Компонент выбора цвета — пока только preview + hex-текст.
 * ЛКМ переключает между палитрой (циклический сдвиг Hue).
 */
public final class ColorButton extends SettingComponent<ColorSetting> {

    private final FloatValue hoverAnim = new FloatValue(0f, 0.18f, Easing.SINE_OUT);
    private int hueShift = 0;

    public ColorButton(ColorSetting setting) {
        super(setting);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        var theme = Client.get().theme();

        hoverAnim.setTarget(hovered ? 1f : 0f);
        hoverAnim.update(delta / 1000f);

        Render2D.roundedRect(ctx, x, y, width, height, theme.radius(),
                ColorUtil.alpha(theme.component(), 0.6f));

        RenderUtil.textSoftShadow(ctx, setting.name(),
                x + 4, y + (height - RenderUtil.fontHeight()) / 2 + 1, theme.text());

        // Превью цвета
        int box = 10;
        int bx = x + width - box - 4;
        int by = y + (height - box) / 2;
        Render2D.roundedRect(ctx, bx, by, box, box, 2f, setting.value());
        // Тонкая обводка
        Render2D.hLine(ctx, bx, by, box, ColorUtil.alpha(0xFF000000, 0.4f));
        Render2D.hLine(ctx, bx, by + box - 1, box, ColorUtil.alpha(0xFF000000, 0.4f));

        // Hex-текст
        String hex = String.format("#%06X", setting.rgb());
        int hx = bx - RenderUtil.textWidth(hex) - 4;
        RenderUtil.textSoftShadow(ctx, hex, hx,
                y + (height - RenderUtil.fontHeight()) / 2 + 1, theme.textSecondary());
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            hueShift = (hueShift + 30) % 360;
            // Используем ColorUtil для циклического сдвига hue на +30°
            int current = setting.rgb();
            int packed = dev.cheat.util.ColorUtil.rgbToHsb(current);
            float h = ((packed >> 16) & 0xFFFF) / 65535f;
            float s = ((packed >> 8) & 0xFF) / 255f;
            float v = (packed & 0xFF) / 255f;
            int newRgb = dev.cheat.util.ColorUtil.hsbToRgb(
                    (h + 30f / 360f) % 1f, s, v);
            setting.setRgb(newRgb);
            return true;
        }
        if (button == 1 && isHovered(mx, my)) {
            // ПКМ — обнулить alpha
            setting.setAlpha(255);
            return true;
        }
        return false;
    }
}
