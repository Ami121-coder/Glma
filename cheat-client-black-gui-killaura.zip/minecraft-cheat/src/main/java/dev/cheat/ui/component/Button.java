package dev.cheat.ui.component;

import dev.cheat.render.Render2D;
import dev.cheat.render.anim.Animation;
import dev.cheat.render.anim.Easing;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Простая кнопка-переключатель с анимацией hover и smooth-state.
 *
 * <p>Использует новый {@link Render2D#roundedRect} для сглаженных углов
 * и {@link Animation} для плавной смены цвета/размера при наведении.</p>
 */
public class Button extends Component {

    private final String label;
    private boolean active = false;
    private Runnable onClick = () -> {};

    public Button(int x, int y, int w, int h, String label) {
        super(x, y, w, h);
        this.label = label;
    }

    // Анимации
    private final Animation hoverAnim  = new Animation(0.18f, Easing.SINE_OUT);
    private final Animation activeAnim = new Animation(0.25f, Easing.QUAD_IN_OUT);

    public Button onClick(Runnable r) { this.onClick = r; return this; }
    public Button setActive(boolean a){ this.active = a; return this; }
    public boolean isActive()         { return active; }
    public String  getLabel()         { return label; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        boolean wasHovered = hovered;
        updateHover(mouseX, mouseY);
        if (wasHovered != hovered) {
            if (hovered) hoverAnim.playForward();
            else         hoverAnim.playBackward();
        }

        // Обновляем анимации с delta-временем (1/60 ≈ 0.0166)
        hoverAnim.update(0.016f);
        activeAnim.update(0.016f);

        // Целевое состояние active-анимации
        boolean targetActive = active;
        if (activeAnim.isForward() != targetActive) {
            if (targetActive) activeAnim.playForward();
            else              activeAnim.playBackward();
        }

        Theme t = Theme.DEFAULT;
        float hoverT = hoverAnim.value();
        float activeT = activeAnim.value();

        // Цвет фона: лерп panel → componentHover (hover), плюс accent-подмесь
        int bgColor = ColorUtil.lerp(t.panel(), t.componentHover(), hoverT);
        if (activeT > 0.001f) {
            bgColor = ColorUtil.lerp(bgColor, t.accent(), activeT * 0.85f);
        }

        // Закруглённый фон
        Render2D.roundedRect(ctx, x, y, width, height, t.radius(), bgColor);

        // Акцентная полоска слева когда активна
        if (activeT > 0.01f) {
            int accentBar = ColorUtil.alpha(t.accent(), activeT);
            Render2D.roundedRect(ctx, x, y + 2, 3 * activeT, height - 4, 1.5f, accentBar);
        }

        // Glow при hover
        if (hoverT > 0.1f) {
            int glow = ColorUtil.alpha(t.borderGlow(), hoverT * 0.5f);
            Render2D.glowRect(ctx, x - 1, y - 1, width + 2, height + 2,
                    t.radius(), 3f * hoverT, glow);
        }

        // Текст: с soft shadow когда активен
        int textColor = ColorUtil.lerp(t.text(), 0xFFFFFFFF, activeT * 0.5f);
        float textY = y + (height - RenderUtil.fontHeight()) / 2f + 1;
        if (activeT > 0.5f) {
            RenderUtil.textSoftShadow(ctx, label, x + 8, (int) textY, textColor);
        } else {
            RenderUtil.text(ctx, label, x + 8, (int) textY, textColor);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            active = !active;
            onClick.run();
            return true;
        }
        return false;
    }
}
