package dev.cheat.command.arg;

import dev.cheat.Client;
import dev.cheat.module.Module;

/** Парсер имени модуля — возвращает сам инстанс {@link Module}. */
public final class ModuleArgument implements Argument<Module> {
    public static final ModuleArgument INSTANCE = new ModuleArgument();
    private ModuleArgument() {}
    @Override public Module parse(String raw) {
        if (raw == null || raw.isEmpty())
            throw new IllegalArgumentException("Имя модуля пусто");
        Module m = Client.get().moduleManager().get(raw);
        if (m == null)
            throw new IllegalArgumentException("Модуль не найден: " + raw);
        return m;
    }
}
