package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.module.Module;
import dev.cheat.setting.Setting;
import dev.cheat.util.ChatUtil;

/**
 * {@code .set <module> <setting> <value>} — изменить настройку модуля.
 * {@code .set <module> list}                          — список настроек.
 * {@code .set reset <module>}                         — сброс всех настроек модуля.
 *
 * <p>Поддерживаемые значения по типу настройки:</p>
 * <ul>
 *   <li>{@code BooleanSetting} — {@code on|off|true|false}.</li>
 *   <li>{@code IntSetting}/{@code DoubleSetting}/{@code FloatSetting} — число.</li>
 *   <li>{@code EnumSetting}/{@code ModeSetting} — строка из доступных режимов.</li>
 *   <li>{@code StringSetting} — любой текст (можно в кавычках).</li>
 *   <li>{@code ColorSetting} — {@code #RRGGBB} или {@code #AARRGGBB}.</li>
 *   <li>{@code KeyBindSetting} — имя GLFW-клавиши или код.</li>
 * </ul>
 */
public final class SettingCommand extends Command {

    public SettingCommand() {
        super("set", "Изменить настройку модуля", "setting","s");
    }

    @Override public int getMinArgs() { return 2; }

    @Override protected String usageArgs() {
        return "<module> <setting> [value] | <module> list | reset <module>";
    }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        // .set reset <module>
        if (ctx.string(0).equalsIgnoreCase("reset")) {
            Module m = Client.get().moduleManager().get(ctx.string(1));
            if (m == null) throw new CommandException("Модуль не найден: " + ctx.string(1));
            m.settings().resetAll();
            ChatUtil.success("Настройки " + m.getName() + " сброшены.");
            return;
        }

        Module m = Client.get().moduleManager().get(ctx.string(0));
        if (m == null) throw new CommandException("Модуль не найден: " + ctx.string(0));

        // .set <module> list
        if (ctx.string(1).equalsIgnoreCase("list")) {
            listSettings(m);
            return;
        }

        Setting<?> s = m.settings().get(ctx.string(1));
        if (s == null) throw new CommandException("Настройка не найдена: "
                + ctx.string(1) + " (в модуле " + m.getName() + ")");

        // .set <module> <setting> — показать значение
        if (ctx.argCount() < 3) {
            ChatUtil.info(m.getName() + "." + s.name() + " = " + s.serialize()
                    + "  [" + s.type() + "]");
            return;
        }

        // .set <module> <setting> <value>
        String raw = ctx.joinFrom(2);
        try {
            applyValue(s, raw);
            ChatUtil.success(m.getName() + "." + s.name() + " = " + s.serialize());
        } catch (IllegalArgumentException e) {
            throw new CommandException(e.getMessage());
        }
    }

    @SuppressWarnings({"rawtypes","unchecked"})
    private void applyValue(Setting s, String raw) {
        Object deserialized;
        switch (s.type()) {
            case BOOLEAN:
                deserialized = parseBool(raw);
                break;
            case INT:
                deserialized = Integer.parseInt(raw);
                break;
            case DOUBLE:
                deserialized = Double.parseDouble(raw);
                break;
            case FLOAT:
                deserialized = Float.parseFloat(raw);
                break;
            case ENUM:
            case MODE:
            case STRING:
                deserialized = raw;
                break;
            case COLOR:
                deserialized = raw; // ColorSetting.deserialize умеет "#AARRGGBB"
                break;
            case KEYBIND:
                // Сначала пробуем как число, потом как имя GLFW-константы
                try { deserialized = Integer.parseInt(raw); }
                catch (NumberFormatException e) {
                    deserialized = raw; // StringSetting тоже поймает
                }
                break;
            default:
                deserialized = raw;
        }
        s.deserialize(deserialized);
    }

    private Boolean parseBool(String s) {
        return switch (s.toLowerCase(java.util.Locale.ROOT)) {
            case "on","true","1","yes","enable","enabled" -> true;
            case "off","false","0","no","disable","disabled" -> false;
            default -> throw new IllegalArgumentException("Ожидается on/off: " + s);
        };
    }

    private void listSettings(Module m) {
        if (m.settings().isEmpty()) {
            ChatUtil.info("У модуля " + m.getName() + " нет настроек.");
            return;
        }
        ChatUtil.info("Настройки " + m.getName() + ":");
        for (Setting<?> s : m.settings().all()) {
            ChatUtil.sendRaw(" §7- §f" + s.name() + " §8[" + s.type() + "] §7= §a"
                    + s.serialize());
        }
    }
}
