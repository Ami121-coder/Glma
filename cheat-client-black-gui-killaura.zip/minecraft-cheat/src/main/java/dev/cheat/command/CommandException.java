package dev.cheat.command;

/**
 * Ошибка выполнения команды. Текст попадёт в чат как
 * {@code [Cheat] §c<message>}.
 */
public class CommandException extends Exception {

    public CommandException(String message)             { super(message); }
    public CommandException(String message, Throwable t){ super(message, t); }
}
