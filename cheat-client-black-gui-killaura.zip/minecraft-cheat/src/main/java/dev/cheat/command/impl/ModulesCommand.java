package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.util.ChatUtil;

import java.util.List;

/**
 * {@code .modules}                  — сводный список модулей по категориям.
 * {@code .modules <category>}       — модули указанной категории.
 */
public final class ModulesCommand extends Command {

    public ModulesCommand() {
        super("modules", "Список всех модулей", "mods","ml");
    }

    @Override protected String usageArgs() { return "[category]"; }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        if (ctx.argCount() >= 1) {
            Category cat = findCategory(ctx.string(0));
            if (cat == null)
                throw new CommandException("Неизвестная категория: " + ctx.string(0)
                        + ". Доступно: " + names());
            List<Module> list = Client.get().moduleManager().byCategory(cat);
            if (list.isEmpty()) {
                ChatUtil.info("Категория " + cat.displayName() + " пуста.");
                return;
            }
            ChatUtil.info("§" + cat + " (" + list.size() + "):");
            for (Module m : list) {
                ChatUtil.sendRaw(" §7- " + (m.isEnabled() ? "§a" : "§c") + m.getName()
                        + (m.hasBind() ? " §8[" + m.getBind() + "]" : "")
                        + (m.settings().isEmpty() ? "" : " §8(" + m.settings().size() + " настроек)"));
            }
            return;
        }

        // Сводный список
        int total = Client.get().moduleManager().size();
        int enabled = Client.get().moduleManager().enabled().size();
        ChatUtil.info("Модули: §a" + enabled + " §7/ §f" + total + " включено.");
        for (Category cat : Category.values()) {
            List<Module> list = Client.get().moduleManager().byCategory(cat);
            if (list.isEmpty()) continue;
            ChatUtil.sendRaw(" §9" + cat.displayName() + "§8: §7"
                    + list.size() + " шт.");
        }
        ChatUtil.sendRaw(" §7Используйте §f.modules <category> §7для подробностей.");
    }

    private Category findCategory(String s) {
        if (s == null) return null;
        for (Category c : Category.values()) {
            if (c.name().equalsIgnoreCase(s)
                    || c.displayName().equalsIgnoreCase(s)) return c;
        }
        return null;
    }

    private String names() {
        StringBuilder sb = new StringBuilder();
        for (Category c : Category.values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(c.name().toLowerCase());
        }
        return sb.toString();
    }
}
