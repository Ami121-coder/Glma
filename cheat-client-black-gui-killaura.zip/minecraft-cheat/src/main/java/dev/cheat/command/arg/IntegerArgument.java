package dev.cheat.command.arg;

/** Парсер целого числа. */
public final class IntegerArgument implements Argument<Integer> {
    public static final IntegerArgument INSTANCE = new IntegerArgument();
    private IntegerArgument() {}
    @Override public Integer parse(String raw) {
        try { return Integer.parseInt(raw); }
        catch (NumberFormatException e) {
            throw new IllegalArgumentException("Ожидается целое число: " + raw);
        }
    }
}
