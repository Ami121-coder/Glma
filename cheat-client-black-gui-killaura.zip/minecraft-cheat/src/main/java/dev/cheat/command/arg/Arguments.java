package dev.cheat.command.arg;

/** Фасад для всех встроенных парсеров аргументов. */
public final class Arguments {
    private Arguments() {}
    public static Argument<Integer>  integer() { return IntegerArgument.INSTANCE; }
    public static Argument<Double>   decimal() { return DoubleArgument.INSTANCE; }
    public static Argument<Boolean>  bool()    { return BooleanArgument.INSTANCE; }
    public static Argument<dev.cheat.module.Module> module() { return ModuleArgument.INSTANCE; }
    public static Argument<String>   player()  { return PlayerArgument.INSTANCE; }
}
