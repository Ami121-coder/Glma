package dev.cheat.command.arg;

/**
 * Парсер аргумента команды. Преобразует строку в тип {@code T}.
 *
 * <p>Конкретные парсеры реализуются как синглтоны или enum-константы:</p>
 * <ul>
 *   <li>{@link IntegerArgument}</li>
 *   <li>{@link BooleanArgument}</li>
 *   <li>{@link DoubleArgument}</li>
 *   <li>{@link ModuleArgument}</li>
 *   <li>{@link PlayerArgument}</li>
 * </ul>
 *
 * @param <T> тип результата
 */
@FunctionalInterface
public interface Argument<T> {
    /**
     * @throws IllegalArgumentException если строка невалидна.
     *                                 Команд-диспетчер превратит её в
     *                                 {@link dev.cheat.command.CommandException}.
     */
    T parse(String raw);
}
