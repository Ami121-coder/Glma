package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.util.ChatUtil;

/**
 * {@code .config save} — сохранить конфиг.
 * {@code .config load} — перечитать с диска.
 * {@code .config reload} — reload + apply.
 */
public final class ConfigCommand extends Command {

    public ConfigCommand() {
        super("config", "Управление конфигурацией", "cfg");
    }

    @Override
    public int getMinArgs() { return 1; }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        String action = ctx.string(0).toLowerCase();
        switch (action) {
            case "save" -> {
                Client.get().configManager().save();
                ChatUtil.success("Конфиг сохранён");
            }
            case "load", "reload" -> {
                Client.get().configManager().load();
                Client.get().configManager().applyTo(Client.get());
                ChatUtil.success("Конфиг загружен");
            }
            default -> throw new CommandException("Действие: save | load | reload");
        }
    }

    @Override
    protected String usageArgs() { return "<save|load|reload>"; }
}
