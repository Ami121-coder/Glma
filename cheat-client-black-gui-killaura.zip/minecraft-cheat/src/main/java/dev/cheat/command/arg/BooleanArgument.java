package dev.cheat.command.arg;

import java.util.Locale;

/** Парсер булева значения: yes/no, on/off, true/false, 1/0. */
public final class BooleanArgument implements Argument<Boolean> {
    public static final BooleanArgument INSTANCE = new BooleanArgument();
    private BooleanArgument() {}
    @Override public Boolean parse(String raw) {
        if (raw == null) throw new IllegalArgumentException("null");
        return switch (raw.toLowerCase(Locale.ROOT)) {
            case "yes","on","true","1","enable","enabled" -> true;
            case "no","off","false","0","disable","disabled" -> false;
            default -> throw new IllegalArgumentException("Ожидается on/off: " + raw);
        };
    }
}
