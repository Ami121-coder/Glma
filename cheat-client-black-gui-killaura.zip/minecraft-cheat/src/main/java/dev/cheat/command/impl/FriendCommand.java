package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.util.ChatUtil;

/**
 * {@code .friend add <name> [alias]}
 * {@code .friend remove <name>}
 * {@code .friend list}
 * {@code .friend clear}
 */
public final class FriendCommand extends Command {

    public FriendCommand() {
        super("friend", "Управление списком друзей", "f");
    }

    @Override
    public int getMinArgs() { return 1; }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        var mgr = Client.get().friendManager();
        String action = ctx.string(0).toLowerCase();

        switch (action) {
            case "add" -> {
                if (!ctx.has(1)) throw new CommandException("Укажите имя");
                String name  = ctx.string(1);
                String alias = ctx.has(2) ? ctx.string(2) : name;
                mgr.add(name, alias);
                ChatUtil.success("Друг добавлен: " + name + (alias.equals(name) ? "" : " (" + alias + ")"));
            }
            case "remove", "del", "delete" -> {
                if (!ctx.has(1)) throw new CommandException("Укажите имя");
                String name = ctx.string(1);
                if (mgr.remove(name)) ChatUtil.success("Друг удалён: " + name);
                else                  ChatUtil.error("Не найден: " + name);
            }
            case "list" -> {
                ChatUtil.info("Друзья (" + mgr.size() + "):");
                for (String n : mgr.names()) {
                    ChatUtil.sendRaw(" §7- §f" + n
                            + (mgr.aliasOf(n).equals(n) ? "" : " §8(" + mgr.aliasOf(n) + ")"));
                }
            }
            case "clear" -> {
                mgr.clear();
                ChatUtil.success("Список друзей очищен");
            }
            default -> throw new CommandException("Действие: add | remove | list | clear");
        }
    }

    @Override
    protected String usageArgs() { return "<add|remove|list|clear> [name] [alias]"; }
}
