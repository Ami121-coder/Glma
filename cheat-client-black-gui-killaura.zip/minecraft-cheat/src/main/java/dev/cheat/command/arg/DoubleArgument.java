package dev.cheat.command.arg;

/** Парсер числа с плавающей точкой. */
public final class DoubleArgument implements Argument<Double> {
    public static final DoubleArgument INSTANCE = new DoubleArgument();
    private DoubleArgument() {}
    @Override public Double parse(String raw) {
        try { return Double.parseDouble(raw); }
        catch (NumberFormatException e) {
            throw new IllegalArgumentException("Ожидается число: " + raw);
        }
    }
}
