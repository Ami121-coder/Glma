package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.module.Module;
import dev.cheat.util.ChatUtil;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/**
 * {@code .bind <module> <key>} — назначить клавишу.
 * {@code .bind <module> clear} — снять бинд.
 * {@code .bind list} — текущие бинды.
 */
public final class BindCommand extends Command {

    public BindCommand() {
        super("bind", "Назначить клавишу модулю", "b");
    }

    @Override
    public int getMinArgs() { return 1; }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        String name = ctx.string(0);

        if (name.equalsIgnoreCase("list")) {
            ChatUtil.info("Текущие бинды:");
            for (Module m : Client.get().moduleManager().all()) {
                if (!m.hasBind()) continue;
                String key = glfwName(m.getBind());
                ChatUtil.sendRaw(" §7- §f" + m.getName() + " §8→ §a" + key);
            }
            return;
        }

        Module m = Client.get().moduleManager().get(name);
        if (m == null) throw new CommandException("Модуль не найден: " + name);

        if (!ctx.has(1)) {
            ChatUtil.info(m.getName() + ": " + (m.hasBind() ? glfwName(m.getBind()) : "нет бинда"));
            return;
        }

        String keyStr = ctx.string(1).toLowerCase(Locale.ROOT);
        if (keyStr.equals("clear") || keyStr.equals("none") || keyStr.equals("0")) {
            m.setBind(0);
            ChatUtil.success("Бинд снят: " + m.getName());
            return;
        }

        // Имя клавиши GLFW: "GLFW_KEY_A" → "a"
        int code = keyCode(keyStr);
        if (code == 0) throw new CommandException("Неизвестная клавиша: " + keyStr);
        m.setBind(code);
        ChatUtil.success(m.getName() + " → " + glfwName(code));
    }

    private static int keyCode(String name) {
        try {
            String field = "GLFW_KEY_" + name.toUpperCase(Locale.ROOT);
            return GLFW.class.getField(field).getInt(null);
        } catch (Exception e) {
            return 0;
        }
    }

    private static String glfwName(int code) {
        for (var f : GLFW.class.getFields()) {
            if (f.getName().startsWith("GLFW_KEY_")) {
                try {
                    if (f.getInt(null) == code) {
                        return f.getName().substring("GLFW_KEY_".length()).toLowerCase(Locale.ROOT);
                    }
                } catch (Exception ignored) {}
            }
        }
        return "?";
    }

    @Override
    protected String usageArgs() { return "<module> <key|clear|list>"; }
}
