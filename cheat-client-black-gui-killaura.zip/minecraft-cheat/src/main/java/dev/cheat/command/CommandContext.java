package dev.cheat.command;

import java.util.List;

/**
 * Контекст выполнения команды.
 *
 * <p>Содержит исходную строку, сплитнутые аргументы и helpers для
 * их типизированного извлечения. Каждый {@code xxx(int i)} метод
 * бросает {@link CommandException}, если аргумента нет или он некорректен.</p>
 */
public final class CommandContext {

    private final String       raw;
    private final List<String> args;

    public CommandContext(String raw, List<String> args) {
        this.raw  = raw;
        this.args = args;
    }

    public String raw()         { return raw;  }
    public List<String> args()  { return args; }
    public int    argCount()    { return args.size(); }

    public boolean has(int i)   { return i >= 0 && i < args.size(); }

    public String string(int i) throws CommandException {
        require(i);
        return args.get(i);
    }

    public int integer(int i) throws CommandException {
        require(i);
        try { return Integer.parseInt(args.get(i)); }
        catch (NumberFormatException e) {
            throw new CommandException("Аргумент " + i + " должен быть числом: " + args.get(i));
        }
    }

    public double decimal(int i) throws CommandException {
        require(i);
        try { return Double.parseDouble(args.get(i)); }
        catch (NumberFormatException e) {
            throw new CommandException("Аргумент " + i + " должен быть числом: " + args.get(i));
        }
    }

    public boolean bool(int i) throws CommandException {
        require(i);
        String s = args.get(i).toLowerCase();
        if (s.equals("on")  || s.equals("true")  || s.equals("1") || s.equals("yes")) return true;
        if (s.equals("off") || s.equals("false") || s.equals("0") || s.equals("no"))  return false;
        throw new CommandException("Ожидалось on/off, получено: " + s);
    }

    /** Объединяет аргументы с {@code from} до конца одной строкой. */
    public String joinFrom(int from) {
        if (from >= args.size()) return "";
        return String.join(" ", args.subList(from, args.size()));
    }

    private void require(int i) throws CommandException {
        if (!has(i)) throw new CommandException("Недостаточно аргументов (позиция " + i + ")");
    }
}
