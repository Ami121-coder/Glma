package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.ChatUtil;

/**
 * {@code .theme}        — показать текущую тему и список доступных.
 * {@code .theme <name>} — переключить тему.
 */
public final class ThemeCommand extends Command {

    public ThemeCommand() {
        super("theme", "Сменить тему оформления", "th");
    }

    @Override protected String usageArgs() { return "[name]"; }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        if (ctx.argCount() == 0) {
            ChatUtil.info("Текущая тема: §a" + Client.get().theme().name());
            ChatUtil.sendRaw(" §7Доступные:");
            for (Theme t : Theme.all()) {
                ChatUtil.sendRaw("  §f- " + t.name());
            }
            return;
        }
        Theme target = Theme.byName(ctx.string(0));
        if (!target.name().equalsIgnoreCase(ctx.string(0))) {
            ChatUtil.warn("Тема '" + ctx.string(0) + "' не найдена, используется default.");
        }
        Client.get().setTheme(target);
        Client.get().configManager().data().currentTheme = target.name();
        ChatUtil.success("Тема: §a" + target.name());
    }
}
