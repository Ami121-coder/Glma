package dev.cheat.command.arg;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

import java.util.UUID;

/**
 * Парсер имени игрока (онлайн или из списка игроков).
 * Возвращает каноничное имя (с правильным регистром).
 */
public final class PlayerArgument implements Argument<String> {
    public static final PlayerArgument INSTANCE = new PlayerArgument();
    private PlayerArgument() {}
    @Override public String parse(String raw) {
        if (raw == null || raw.isEmpty())
            throw new IllegalArgumentException("Имя игрока пусто");
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null)
            return raw; // не в игре — принимаем как есть
        // ищем точное совпадение
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            if (e.getProfile() != null
                    && e.getProfile().getName() != null
                    && e.getProfile().getName().equalsIgnoreCase(raw)) {
                return e.getProfile().getName();
            }
        }
        // если не нашли онлайн — возвращаем как есть (для добавления в друзья оффлайн-игрока)
        return raw;
    }

    /** Возвращает UUID игрока по имени, если он онлайн. */
    public static UUID findUuid(String name) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return null;
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            if (e.getProfile() != null
                    && name.equalsIgnoreCase(e.getProfile().getName())) {
                return e.getProfile().getId();
            }
        }
        return null;
    }
}
