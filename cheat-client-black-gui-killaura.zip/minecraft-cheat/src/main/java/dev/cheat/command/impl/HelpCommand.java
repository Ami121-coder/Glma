package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.manager.CommandManager;
import dev.cheat.util.ChatUtil;

/**
 * {@code .help} — список всех команд или подсказка по конкретной.
 *
 * <p>Пример:</p>
 * <pre>
 *   .help
 *   .help toggle
 * </pre>
 */
public final class HelpCommand extends Command {

    public HelpCommand() {
        super("help", "Список команд", "?");
    }

    @Override
    public void execute(CommandContext ctx) throws CommandException {
        CommandManager mgr = Client.get().commandManager();

        if (!ctx.has(0)) {
            ChatUtil.info("Команды (" + mgr.size() + "):");
            for (Command c : mgr.all()) {
                ChatUtil.sendRaw(" §7- §f" + c.getName()
                        + (c.getAliases().isEmpty() ? "" : " §8(" + String.join(", ", c.getAliases()) + ")")
                        + " §7" + c.getDescription());
            }
            return;
        }

        String name = ctx.string(0);
        Command cmd = mgr.get(name);
        if (cmd == null) throw new CommandException("Команда не найдена: " + name);

        ChatUtil.info("Использование: " + cmd.getUsage());
        ChatUtil.sendRaw(" §7" + cmd.getDescription());
    }

    @Override
    protected String usageArgs() { return "[command]"; }
}
