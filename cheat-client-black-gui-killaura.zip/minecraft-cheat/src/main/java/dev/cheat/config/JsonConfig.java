package dev.cheat.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.cheat.util.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;

/**
 * Универсальный JSON-конфиг поверх GSON.
 *
 * <p>Особенности:</p>
 * <ul>
 *   <li>Атомарная запись: пишем в {@code .tmp}, потом move.</li>
 *   <li>Если файл отсутствует — {@link #load()} вернёт {@code null}.</li>
 *   <li>При ошибке парсинга — предупреждение в лог + null.</li>
 * </ul>
 */
public final class JsonConfig<T> {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .serializeNulls()
            .disableHtmlEscaping()
            .create();

    private final Path   file;
    private final Class<T> type;

    public JsonConfig(Path file, Class<T> type) {
        this.file = file;
        this.type = type;
    }

    public Path file() { return file; }

    public T load() {
        if (!Files.exists(file)) return null;
        try {
            String json = Files.readString(file);
            return GSON.fromJson(json, type);
        } catch (Throwable t) {
            Logger.error("Failed to read config " + file, t);
            return null;
        }
    }

    public void save(T data) {
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        try {
            if (file.getParent() != null) Files.createDirectories(file.getParent());
            String json = GSON.toJson(data);
            Files.writeString(tmp, json,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            Logger.error("Failed to save config " + file, e);
        }
    }

    public boolean exists() {
        return Files.exists(file);
    }

    public void delete() throws IOException {
        Files.deleteIfExists(file);
    }
}
