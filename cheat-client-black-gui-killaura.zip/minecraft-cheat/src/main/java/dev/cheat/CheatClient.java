package dev.cheat;

import dev.cheat.core.Core;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * Точка входа мода на стороне клиента.
 * Зарегистрирована в {@code fabric.mod.json} под entrypoints.client.
 *
 * <p>Класс намеренно минимальный: вся логика инициализации делегируется
 * в {@link Core}, чтобы точка входа оставалась стабильной при росте проекта.</p>
 */
@Environment(EnvType.CLIENT)
public final class CheatClient implements ClientModInitializer {

    public static final String MOD_ID   = "cheat";
    public static final String MOD_NAME = "Cheat Client";
    public static final String VERSION  = "0.1.0-beta";

    @Override
    public void onInitializeClient() {
        // Запускаем ядро только один раз (Fabric может вызвать дважды в редких случаях).
        if (Core.isInitialized()) return;
        Core.bootstrap();
    }
}
