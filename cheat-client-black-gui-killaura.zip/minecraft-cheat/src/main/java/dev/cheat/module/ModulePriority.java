package dev.cheat.module;

/**
 * Приоритет модуля. Используется при сортировке тиков/рендеров.
 * Меньше = выше приоритет = раньше вызывается.
 */
public enum ModulePriority {
    HIGHEST (0),
    HIGH    (100),
    NORMAL  (200),
    LOW     (300),
    LOWEST  (400);

    private final int weight;

    ModulePriority(int w) { this.weight = w; }

    public int weight() { return weight; }
}
