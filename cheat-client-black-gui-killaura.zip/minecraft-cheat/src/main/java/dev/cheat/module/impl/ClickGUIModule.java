package dev.cheat.module.impl;

import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.module.ModuleInfo;
import dev.cheat.ui.ClickGUIScreen;

/**
 * ClickGUI — открывает экран настроек модулей.
 *
 * <p>Демонстрирует:</p>
 * <ul>
 *   <li>Модуль, который «одноразовый» — {@code onEnable} сразу закрывает себя.</li>
 *   <li>Использование {@link dev.cheat.ui.ClickGUIScreen}.</li>
 * </ul>
 *
 * <p>Бинд по умолчанию: {@code GLFW_KEY_RIGHT_SHIFT (343)}.</p>
 */
@ModuleInfo(
        name        = "ClickGUI",
        description = "Открыть экран настроек",
        category    = Category.CLIENT,
        bind        = org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT,
        enabledByDefault = false,
        visible     = true
)
public final class ClickGUIModule extends Module {

    @Override
    protected void onEnable() {
        // Открываем экран и сразу выключаемся (модуль остаётся «toggle-on-demand»).
        if (mc.currentScreen == null) {
            mc.setScreen(ClickGUIScreen.get());
        }
        disable();
    }
}
