package dev.cheat.module;

import dev.cheat.Client;
import dev.cheat.event.listener.EventListener;
import dev.cheat.event.impl.ClientTickEvent;
import dev.cheat.event.impl.KeyEvent;
import dev.cheat.event.impl.MouseEvent;
import dev.cheat.event.impl.MotionEvent;
import dev.cheat.event.impl.MotionUpdateEvent;
import dev.cheat.event.impl.PacketReceiveEvent;
import dev.cheat.event.impl.PacketSendEvent;
import dev.cheat.event.impl.PlayerMoveEvent;
import dev.cheat.event.impl.PlayerTickEvent;
import dev.cheat.event.impl.Render2DEvent;
import dev.cheat.event.impl.Render3DEvent;
import dev.cheat.setting.SettingGroup;
import dev.cheat.util.Logger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.Consumer;

/**
 * Базовый класс любого модуля.
 *
 * <p>Каркас НЕ добавляет конкретных модулей — это контракт. Каждый будущий
 * модуль наследуется от {@code Module} и помечается аннотацией
 * {@link ModuleInfo}.</p>
 *
 * <p>Жизненный цикл и хуки:</p>
 * <ol>
 *   <li>Конструктор — инстанцируется менеджером (через рефлексию).
 *       Здесь надо регистрировать настройки через {@link #settings}.</li>
 *   <li>{@link #onEnable()} — вызывается при включении.</li>
 *   <li>{@link #onDisable()} — вызывается при выключении.</li>
 *   <li>{@link #onTick()} — каждый клиентский тик, если включён.</li>
 *   <li>{@link #onRender2D(Render2DEvent)} — каждый кадр HUD.</li>
 *   <li>{@link #onRender3D(Render3DEvent)} — каждый кадр мирового рендера.</li>
 *   <li>{@link #onMotion(MotionEvent)} — превент/пост motion (rotations, onGround).</li>
 *   <li>{@link #onMotionUpdate(MotionUpdateEvent)} — pre/post фаза обновления motion.</li>
 *   <li>{@link #onPacketSend(PacketSendEvent)} — перехват исходящих пакетов.</li>
 *   <li>{@link #onPacketReceive(PacketReceiveEvent)} — перехват входящих пакетов.</li>
 *   <li>{@link #onKey(KeyEvent)} — клавиша (если включён).</li>
 *   <li>{@link #onMouse(MouseEvent)} — мышь (если включён).</li>
 *   <li>{@link #onPlayerTick(PlayerTickEvent)} — превент/пост тик игрока.</li>
 *   <li>{@link #onPlayerMove(PlayerMoveEvent)} — превент движения игрока (Cancellable).</li>
 *   <li>{@link #onClientTick(ClientTickEvent)} — превент/пост клиентский тик.</li>
 * </ol>
 *
 * <p>Модуль автоматически регистрируется как {@link EventListener}
 * при включении через {@code enable()} (и снимается в {@code disable()}).
 * Дополнительно модуль сам публикует хуки {@code onRender2D/onRender3D/onTick}
 * через единый обработчик {@link #onEvent(Event)} чтобы разработчику не нужно
 * было писать {@code @EventHandler} на каждый тип события.</p>
 */
public abstract class Module implements EventListener {

    protected final MinecraftClient mc;

    /** Настройки модуля. Доступны в конструкторе: {@code settings.add(new IntSetting(...))}. */
    protected final SettingGroup settings = new SettingGroup();

    // ─── Метаданные (заполняются из @ModuleInfo) ─────────────
    private final String   name;
    private final String   description;
    private final Category category;
    private       int      bind;
    private final boolean  visibleDefault;

    // ─── Состояние ───────────────────────────────────────────
    private boolean enabled = false;
    private final long createdAt = System.currentTimeMillis();
    private long    enabledAt    = 0L;

    protected Module() {
        this.mc = MinecraftClient.getInstance();

        ModuleInfo info = getClass().getAnnotation(ModuleInfo.class);
        if (info == null) {
            throw new IllegalStateException("Module " + getClass().getName()
                    + " missing @ModuleInfo");
        }
        this.name          = info.name();
        this.description   = info.description();
        this.category      = info.category();
        this.bind          = info.bind();
        this.visibleDefault= info.visible();
        this.enabled       = info.enabledByDefault();
    }

    // ─── Управление состоянием ───────────────────────────────

    public final void enable() {
        if (enabled) return;
        enabled = true;
        enabledAt = System.currentTimeMillis();
        try {
            onEnable();
            Client.get().eventManager().subscribe(this);
        } catch (Throwable t) {
            Logger.error("onEnable failed in " + name, t);
        }
        Logger.info("Module + " + name);
        announce("+", Formatting.GREEN);
    }

    public final void disable() {
        if (!enabled) return;
        enabled = false;
        try {
            Client.get().eventManager().unsubscribe(this);
            onDisable();
        } catch (Throwable t) {
            Logger.error("onDisable failed in " + name, t);
        }
        Logger.info("Module - " + name);
        announce("-", Formatting.RED);
    }

    public final void toggle() {
        if (enabled) disable();
        else         enable();
    }

    public final boolean isEnabled()   { return enabled; }
    public final boolean isDisabled()  { return !enabled; }

    // ─── Хуки для наследников ────────────────────────────────

    /** Вызывается при включении модуля. По умолчанию пусто. */
    protected void onEnable()  {}

    /** Вызывается при выключении модуля. По умолчанию пусто. */
    protected void onDisable() {}

    /** Вызывается каждый клиентский тик ТОЛЬКО если модуль включён. */
    public void onTick() {}

    /** 2D-рендер HUD. Срабатывает только если модуль включён. */
    public void onRender2D(Render2DEvent event) {}

    /** 3D-рендер в мире (ESP, tracers). Срабатывает только если модуль включён. */
    public void onRender3D(Render3DEvent event) {}

    /** Motion pre/post (rotation spoofing, onGround). */
    public void onMotion(MotionEvent event) {}

    /** Событие обновления motion (pre/post). */
    public void onMotionUpdate(MotionUpdateEvent event) {}

    /** Перехват исходящего пакета. */
    public <T extends net.minecraft.network.packet.Packet<?>> void onPacketSend(PacketSendEvent<T> event) {}

    /** Перехват входящего пакета. */
    public <T extends net.minecraft.network.packet.Packet<?>> void onPacketReceive(PacketReceiveEvent<T> event) {}

    /** Событие клавиатуры. */
    public void onKey(KeyEvent event) {}

    /** Событие мыши. */
    public void onMouse(MouseEvent event) {}

    /** Тик игрока pre/post. */
    public void onPlayerTick(PlayerTickEvent event) {}

    /** Движение игрока (Cancellable). */
    public void onPlayerMove(PlayerMoveEvent event) {}

    /** Клиентский тик pre/post. */
    public void onClientTick(ClientTickEvent event) {}

    // ─── Унифицированный диспетчер (один @EventHandler на тип события) ───
    // EventManager использует ТОЧНОЕ сопоставление типов, поэтому диспетчер
    // разбит на отдельные методы под каждый тип. Разработчику не нужно
    // писать @EventHandler в подклассах — достаточно переопределить
    // нужный типизированный хук (onRender2D, onTick, onMotion, ...).

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchRender2D(Render2DEvent e) {
        if (enabled) tryHook(() -> onRender2D(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchRender3D(Render3DEvent e) {
        if (enabled) tryHook(() -> onRender3D(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchMotion(MotionEvent e) {
        if (enabled) tryHook(() -> onMotion(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchMotionUpdate(MotionUpdateEvent e) {
        if (enabled) tryHook(() -> onMotionUpdate(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final <T extends net.minecraft.network.packet.Packet<?>> void dispatchPacketSend(PacketSendEvent<T> e) {
        if (enabled) tryHook(() -> onPacketSend(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final <T extends net.minecraft.network.packet.Packet<?>> void dispatchPacketReceive(PacketReceiveEvent<T> e) {
        if (enabled) tryHook(() -> onPacketReceive(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchKey(KeyEvent e) {
        if (enabled) tryHook(() -> onKey(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchMouse(MouseEvent e) {
        if (enabled) tryHook(() -> onMouse(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchPlayerTick(PlayerTickEvent e) {
        if (enabled) tryHook(() -> onPlayerTick(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchPlayerMove(PlayerMoveEvent e) {
        if (enabled) tryHook(() -> onPlayerMove(e));
    }

    @dev.cheat.event.listener.EventHandler(priority = 200)
    public final void dispatchClientTick(ClientTickEvent e) {
        if (enabled) {
            // Обновляем условия доступности настроек (для condition()-условий)
            if (e.isPre()) settings.refreshAllEnabled();
            tryHook(() -> onClientTick(e));
        }
    }

    private void tryHook(Runnable r) {
        try { r.run(); }
        catch (Throwable t) { Logger.error("Event hook error in " + name, t); }
    }

    // ─── Биндинг клавиш ──────────────────────────────────────

    public int    getBind()        { return bind; }
    public void   setBind(int key) { this.bind = key; }
    public boolean hasBind()       { return bind != 0; }

    // ─── Геттеры метаданных ──────────────────────────────────

    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isVisible()      { return visibleDefault; }
    public long     getCreatedAt()   { return createdAt; }
    public long     getEnabledAt()   { return enabledAt; }

    public ModulePriority priority() { return ModulePriority.NORMAL; }

    /** Доступ к настройкам модуля. */
    public SettingGroup settings() { return settings; }

    // ─── Утилиты для настроек ─────────────────────────────────

    /**
     * Подписаться на изменение любой настройки модуля.
     * @param settingName имя настройки
     * @param listener    колбэк
     */
    protected <T> void onSettingChange(String settingName, Consumer<T> listener) {
        dev.cheat.setting.Setting<?> s = settings.get(settingName);
        if (s == null) {
            Logger.warn("Setting not found: " + settingName + " in " + name);
            return;
        }
        //noinspection unchecked
        s.onChange(v -> {
            //noinspection unchecked
            listener.accept((T) v);
        });
    }

    // ─── Вспомогательные методы ──────────────────────────────

    /** Выводит в чат строку-индикатор состояния модуля. */
    private void announce(String sign, Formatting color) {
        if (mc.player == null) return;
        String msg = String.format("%s%s §7%s", color, sign, name);
        try {
            mc.inGameHud.getChatHud().addMessage(Text.literal(msg));
        } catch (Throwable ignored) {
            // чат может быть недоступен в early-init
        }
    }
}
