package dev.cheat.module;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Декларативное описание модуля.
 *
 * <p>Вешается на класс-наследник {@link Module}. Каркас читает
 * эти данные через рефлексию в {@code ModuleManager}.</p>
 *
 * <p>Пример:</p>
 * <pre>
 *   &#64;ModuleInfo(name = "KillAura", category = Category.COMBAT, description = "...", bind = GLFW.GLFW_KEY_R)
 *   public final class KillAuraModule extends Module { ... }
 * </pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ModuleInfo {
    String  name();
    String  description()        default "";
    Category category();
    /** Код клавиши GLFW_KEY_*. 0 = без бинда. */
    int     bind()               default 0;
    /** По умолчанию включен? */
    boolean enabledByDefault()   default false;
    /** Виден в ClickGUI/ArrayList? */
    boolean visible()            default true;
}
