package dev.cheat.module.impl;

import dev.cheat.Client;
import dev.cheat.event.impl.MotionEvent;
import dev.cheat.event.impl.MotionUpdateEvent;
import dev.cheat.manager.RotationManager;
import dev.cheat.manager.RotationTarget;
import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.module.ModuleInfo;
import dev.cheat.module.ModulePriority;
import dev.cheat.setting.BooleanSetting;
import dev.cheat.setting.DoubleSetting;
import dev.cheat.setting.EnumSetting;
import dev.cheat.setting.FloatSetting;
import dev.cheat.setting.IntSetting;
import dev.cheat.util.AimSimulator;
import dev.cheat.util.CombatState;
import dev.cheat.util.GCDFix;
import dev.cheat.util.KillAuraDebug;
import dev.cheat.util.Logger;
import dev.cheat.util.TargetSelector;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * KillAura 1.9+ с обходом Polar Anticheat — v2 с защитой от кнокбэка.
 *
 * <p><b>Реализованные алгоритмы обхода Polar:</b></p>
 * <ol>
 *   <li><b>GCD-Фикс (Mouse Sensitivity Fix)</b> — все rotation-delta
 *       снапаются к сетке GCD. Реализация: {@link GCDFix}.</li>
 *
 *   <li><b>Aim Smoothing</b> — экспоненциальное сглаживание + Безье +
 *       перлин-jitter. Реализация: {@link AimSimulator#step}.</li>
 *
 *   <li><b>Строгий Raycast-фильтр</b> — атака только при line-of-sight.
 *       Реализация: {@link TargetSelector#canSee}.</li>
 *
 *   <li><b>1.9+ Combat (Cooled Attack)</b> — удар только при
 *       {@code getAttackCooldownProgress(0.5) >= threshold}.</li>
 *
 *   <li><b>Silent Rotations</b> — ротации только в motion-пакете.</li>
 * </ol>
 *
 * <p><b>Дополнительные обходы Polar:</b></p>
 * <ul>
 *   <li><b>Knockback Pause</b> — при получении кнокбэка/урона KillAura
 *       полностью останавливается на 15 тиков. Без этого сервер
 *       rubberband'ит игрока, потому что silent-ротации конфликтуют
 *       с knockback-driven movement. Реализация: {@link CombatState}.</li>
 *
 *   <li><b>Pre-Motion Sprint Reset</b> — sprint сбрасывается ДО motion-пакета
 *       (в PRE-motion), а не после. Polar флагает атаки, где motion-пакет
 *       ещё содержал sprint=true, а attack уже в этом тике — мы теперь
 *       сбрасываем sprint перед отправкой motion.</li>
 *
 *   <li><b>Vanilla Attack Path</b> — атака через {@code mc.interactionManager.
 *       attackEntity()}, который вызывает {@code syncSelectedSlot()} перед
 *       отправкой пакета. Polar флагает attack без slot-sync (BadPackets).</li>
 *
 *   <li><b>Reach Jitter</b>, <b>Hitbox Targeting</b>, <b>Switch Delay</b>,
 *       <b>CPS Jitter</b>, <b>Rotation Cooldown</b>, <b>Attack-Rotation Sync</b>.</li>
 * </ul>
 *
 * <p><b>Debug-логирование:</b> {@link KillAuraDebug} пишет в
 * {@code cheat/logs/killaura.log}. Уровни: OFF / BASIC / DETAIL / TRACE.
 * Логирует: включение/выключение, выбор цели, ротации, атаки, кнокбэки,
 * пропуски атаки с причинами.</p>
 *
 * <p><b>Bind:</b> {@code GLFW_KEY_R} — тоггл KillAura.</p>
 */
@ModuleInfo(
        name        = "KillAura",
        description = "Продвинутая аура 1.9+ с обходом Polar Anticheat",
        category    = Category.COMBAT,
        bind        = GLFW.GLFW_KEY_R,
        enabledByDefault = false,
        visible     = true
)
public final class KillAuraModule extends Module {

    // ─── Настройки ────────────────────────────────────────────

    // --- Основные (МИНИМАЛЬНЫЙ режим для Polar 1.21.4) ---
    // Range 3.0 — Polar проверяет reach <= 3.0. 3.2 иногда флагает.
    private final DoubleSetting range =
            new DoubleSetting("Range", "Дальность атаки (блоки)", 3.0, 2.0, 6.0, 0.1);
    private final DoubleSetting fov =
            new DoubleSetting("FOV", "Ограничение угла обзора (180 = без лимита)", 90.0, 30.0, 180.0, 5.0);
    private final EnumSetting<TargetSelector.SortMode> sortMode =
            new EnumSetting<>("Sort", "Сортировка целей", TargetSelector.SortMode.DISTANCE);
    // HitboxExpand 0.0 — не расширять, Polar проверяет "точка в хитбоксе"
    private final DoubleSetting hitboxExpand =
            new DoubleSetting("HitboxExpand", "Расширение хитбокса", 0.0, 0.0, 0.5, 0.05);

    // --- Aim Smoothing (МИНИМАЛЬНЫЙ режим) ---
    // Smoothing 0.5 — средний, не snap и не слишком медленный
    private final FloatSetting smoothing =
            new FloatSetting("Smoothing", "Сглаживание наводки (0=снап, 0.95=плавно)", 0.50f, 0.0f, 0.95f, 0.05f);
    // Jitter 0.5 — минимальное (1.0 может давать некратные GCD deltas)
    private final FloatSetting jitter =
            new FloatSetting("Jitter", "Микродрожание руки (градусы)", 0.5f, 0.0f, 5.0f, 0.1f);
    // BezierPath OFF — кривая Безье даёт некратные GCD deltas = флаг
    private final BooleanSetting bezierPath =
            new BooleanSetting("BezierPath", "Искривление траектории (OFF=надёжнее)", false);
    // Rotation threshold — НЕ атаковать, если rotation не доехала до цели.
    // Polar проверяет, что серверная rotation смотрит на цель. Если smoothing
    // не доехал (delta > threshold) — атака = "битьё мимо" = флаг.
    private final FloatSetting rotationThreshold =
            new FloatSetting("RotThreshold", "Макс. угол между rotation и целью для атаки (градусы)", 30.0f, 5.0f, 90.0f, 5.0f);

    // --- 1.9+ Combat ---
    // Cooldown 1.0 — ТОЛЬКО полный кулдаун. 0.95 может флагать "cheetah".
    private final FloatSetting cooldownThreshold =
            new FloatSetting("Cooldown", "Порог кулдауна для удара (1.0 = полный)", 1.0f, 0.5f, 1.0f, 0.05f);
    private final BooleanSetting onlyGround =
            new BooleanSetting("OnlyGround", "Атаковать только на земле", false);

    // --- Silent Rotations ---
    // ВАЖНО: SilentRotations теперь OFF по умолчанию! Silent rotations
    // вызывают movement desync (player.setYaw(spoofed) влияет на movement
    // vector) → сервер видит несоответствие → rubberband. Visible rotations
    // (камера двигается) выглядят как человек с мышью и НЕ вызывают desync.
    private final BooleanSetting silentRotations =
            new BooleanSetting("SilentRotations", "Silent ротации (OFF=visible, надёжнее)", false);
    // GCDFix OFF — GCD-снап может давать delta=0 (нет rotation) = флаг.
    // Без GCD-фикса rotation-delta естественный (smoothing + jitter).
    private final BooleanSetting gcdFix =
            new BooleanSetting("GCDFix", "GCD-фикс (OFF=естественная rotation)", false);
    // LegitMode OFF — он блокирует слишком много атак. Crosshair и так
    // проверяется через rotationThreshold.
    private final BooleanSetting legitMode =
            new BooleanSetting("LegitMode", "Атака только при crosshair на цели", false);
    private final FloatSetting crosshairTolerance =
            new FloatSetting("CrosshairTol", "Допуск crosshair для атаки (градусы)", 30.0f, 3.0f, 45.0f, 1.0f);

    // --- Polar bypass (МИНИМАЛЬНЫЙ режим — всё OFF кроме Raycast) ---
    private final BooleanSetting raycastCheck =
            new BooleanSetting("Raycast", "Проверка line-of-sight", true);
    // ReachJitter OFF — рандомизация может дать > 3.0 = флаг
    private final BooleanSetting reachJitter =
            new BooleanSetting("ReachJitter", "Рандомизация reach (OFF=надёжнее)", false);
    // HitboxTargeting OFF — случайная точка может быть за пределами хитбокса
    private final BooleanSetting hitboxTargeting =
            new BooleanSetting("HitboxTargeting", "Случайная точка в хитбоксе (OFF=eye pos)", false);
    private final FloatSetting centerBias =
            new FloatSetting("CenterBias", "Предпочтение центра хитбокса", 0.7f, 0.0f, 1.0f, 0.1f);
    private final BooleanSetting switchDelay =
            new BooleanSetting("SwitchDelay", "Задержка 1-3 тика при смене цели", true);
    // CPSJitter OFF — идеальная периодичность = ванильное поведение
    private final BooleanSetting cpsJitter =
            new BooleanSetting("CPSJitter", "Рандомизация CPS (OFF=ванильный CPS)", false);
    // SprintReset OFF — сброс спринта может вызывать sprint state desync
    private final BooleanSetting sprintReset =
            new BooleanSetting("SprintReset", "Сброс спринта (OFF=надёжнее)", false);
    private final BooleanSetting rotationCooldown =
            new BooleanSetting("RotationCooldown", "Ждать 2 тика после смены цели", true);

    // --- Knockback protection ---
    private final BooleanSetting knockbackPause =
            new BooleanSetting("KnockbackPause", "Пауза при кнокбэке (анти-rubberband)", true);
    private final IntSetting knockbackPauseTicks =
            new IntSetting("PauseTicks", "Длительность паузы после кнокбэка (тики)", 5, 3, 30);
    private final BooleanSetting hurtPause =
            new BooleanSetting("HurtPause", "Пауза при hurtTime (получил урон)", false);
    private final BooleanSetting velocityHeuristic =
            new BooleanSetting("VelocityHeuristic", "Эвристика velocity (OFF=только пакеты)", false);
    private final IntSetting rubberbandPauseTicks =
            new IntSetting("RubberPause", "Пауза после rubberband (тики)", 5, 3, 40);
    private final IntSetting postPauseGrace =
            new IntSetting("PostPauseGrace", "Grace period после паузы (тики)", 1, 0, 10);
    private final DoubleSetting maxAttackVelocity =
            new DoubleSetting("MaxAttackVel", "Макс. |velocity| для атаки (0=off)", 0.0, 0.0, 1.0, 0.05);

    // --- Debug ---
    private final BooleanSetting debugEnabled =
            new BooleanSetting("Debug", "Включить дебаг-лог в cheat/logs/killaura.log", true);
    private final IntSetting debugVerbosity =
            new IntSetting("Verbosity", "Уровень логирования (0=off,1=basic,2=detail,3=trace)", 2, 0, 3);

    // ─── Внутреннее состояние ─────────────────────────────────

    private LivingEntity currentTarget = null;
    private int nextAttackTick = 0;
    private int lastTargetSwitchTick = -100;
    /** Когда цель последний раз пропадала (для flicker-фильтра). */
    private int lastTargetLostTick = -100;
    private int currentTick = 0;

    private float serverYaw = 0.0f, serverPitch = 0.0f;
    private boolean serverRotInitialized = false;
    private boolean hadTargetLastTick = false;

    /** Был ли sprint сброшен в PRE-motion (для восстановления в POST). */
    private boolean sprintWasReset = false;

    /** Запланирована ли атака в POST-motion этом тике. */
    private boolean attackPlanned = false;

    /** Post-pause grace period: тики, оставшиеся до разрешения атаки после pause.
     *  После окончания knockback/rubberband pause ждём ещё N тиков, чтобы
     *  позиция клиента синхронизировалась с сервером. */
    private int postPauseGraceTicks = 0;

    /** Тик, когда последний раз была активна pause (для grace period). */
    private int lastPauseEndedTick = -100;

    /** Кэшированная точка прицеливания на текущий тик.
     *  ВАЖНО: computeAimPoint() рандомизирует точку (HitboxTargeting),
     *  поэтому вызывать его можно только ОДИН раз за тик — иначе rotation
     *  будет настроена на одну точку, а raycast/attack — на другую. */
    private Vec3d cachedAimPoint = null;

    /** Кэшированные desired rotation на текущий тик. */
    private float[] cachedDesiredRot = null;

    // ─── Конструктор ──────────────────────────────────────────

    public KillAuraModule() {
        settings.add(range);
        settings.add(fov);
        settings.add(sortMode);
        settings.add(hitboxExpand);

        settings.add(smoothing);
        settings.add(jitter);
        settings.add(bezierPath);
        settings.add(rotationThreshold);

        settings.add(cooldownThreshold);
        settings.add(onlyGround);

        settings.add(silentRotations);
        settings.add(gcdFix);
        settings.add(legitMode);
        settings.add(crosshairTolerance);

        settings.add(raycastCheck);
        settings.add(reachJitter);
        settings.add(hitboxTargeting);
        settings.add(centerBias);
        settings.add(switchDelay);
        settings.add(cpsJitter);
        settings.add(sprintReset);
        settings.add(rotationCooldown);

        settings.add(knockbackPause);
        settings.add(knockbackPauseTicks);
        settings.add(rubberbandPauseTicks);
        settings.add(hurtPause);
        settings.add(velocityHeuristic);
        settings.add(postPauseGrace);
        settings.add(maxAttackVelocity);

        settings.add(debugEnabled);
        settings.add(debugVerbosity);
    }

    @Override
    public ModulePriority priority() {
        return ModulePriority.HIGHEST;
    }

    // ─── Жизненный цикл ───────────────────────────────────────

    @Override
    protected void onEnable() {
        currentTarget = null;
        nextAttackTick = 0;
        lastTargetSwitchTick = -100;
        lastTargetLostTick = -100;
        serverRotInitialized = false;
        hadTargetLastTick = false;
        sprintWasReset = false;
        attackPlanned = false;
        postPauseGraceTicks = 0;
        lastPauseEndedTick = -100;

        syncDebugSettings();
        syncCombatSettings();
        KillAuraDebug.logStateChange(true);
    }

    @Override
    protected void onDisable() {
        currentTarget = null;
        hadTargetLastTick = false;
        if (Client.tryGet() != null && Client.get().rotationManager() != null) {
            Client.get().rotationManager().revoke("KillAura");
        }
        KillAuraDebug.logStateChange(false);
    }

    // ─── Синхронизация настроек дебага ────────────────────────

    private void syncDebugSettings() {
        boolean wantEnabled = debugEnabled.value();
        int wantVerbosity = debugVerbosity.value();
        if (KillAuraDebug.isEnabled() != wantEnabled
                || KillAuraDebug.getVerbosity() != wantVerbosity) {
            KillAuraDebug.setEnabled(wantEnabled);
            KillAuraDebug.setVerbosity(wantVerbosity);
        }
    }

    /** Синхронизация настроек CombatState с настройками модуля. */
    private void syncCombatSettings() {
        try {
            CombatState cs = CombatState.getInstance();
            cs.setKnockbackPauseEnabled(knockbackPause.value());
            cs.setHurtPauseEnabled(hurtPause.value());
            cs.setVelocityHeuristicEnabled(velocityHeuristic.value());
            cs.setKnockbackPauseTicks(knockbackPauseTicks.value());
            // Rubberband pause берём из отдельной настройки (должна быть
            // больше knockback-pause — серверу нужно время на стабилизацию).
            cs.setRubberbandPauseTicks(rubberbandPauseTicks.value());
        } catch (Throwable t) {
            KillAuraDebug.logError("syncCombatSettings failed", t);
        }
    }

    // ─── Основной цикл: onTick ────────────────────────────────
    //
    // onTick() вызывается в MinecraftClient.tick() HEAD — ДО player.tick()
    // → sendMovementPackets() → MotionUpdateEvent(PRE). Поэтому запрос
    // ротации через RotationManager.request() успеет быть обработан в
    // pickBestTarget() (priority 50) раньше, чем motion-пакет уйдёт.

    @Override
    public void onTick() {
        currentTick++;
        attackPlanned = false;
        sprintWasReset = false;
        cachedAimPoint = null;       // сброс кэша на новый тик
        cachedDesiredRot = null;

        syncDebugSettings();
        syncCombatSettings();

        if (mc.player == null || mc.world == null) return;

        // ПРОВЕРКА КНОКБЭКА — главная защита от rubberband
        boolean isPaused = knockbackPause.value() && CombatState.getInstance().isPaused();
        if (isPaused) {
            // Во время паузы: снимаем rotation request, не атакуем
            if (Client.tryGet() != null && Client.get().rotationManager() != null) {
                Client.get().rotationManager().revoke("KillAura");
            }
            if (currentTarget != null) {
                KillAuraDebug.logPause(CombatState.getInstance().pauseTicks(),
                        CombatState.getInstance().pauseReason());
            }
            // Сбрасываем grace period на максимум при активной паузе
            postPauseGraceTicks = postPauseGrace.value();
            hadTargetLastTick = false;
            return;
        }

        // POST-PAUSE GRACE PERIOD: декремент после окончания паузы.
        // Пока grace > 0, shouldAttackThisTick() вернёт false.
        // ВАЖНО: во время grace мы НЕ запрашиваем ротации — позиция ещё
        // нестабильна, и rotation request вызовет movement desync.
        if (postPauseGraceTicks > 0) {
            postPauseGraceTicks--;
            // Снимаем rotation request на время grace
            if (Client.tryGet() != null && Client.get().rotationManager() != null) {
                Client.get().rotationManager().revoke("KillAura");
            }
            hadTargetLastTick = false;
            if (postPauseGraceTicks == 0) {
                KillAuraDebug.log("Post-pause grace ended — attacks enabled");
            }
            return;  // НЕ запрашиваем ротации, НЕ ищем цель
        }

        // Синхронизация serverYaw/serverPitch
        if (!serverRotInitialized || !hadTargetLastTick) {
            serverYaw   = mc.player.getYaw();
            serverPitch = mc.player.getPitch();
            serverRotInitialized = true;
        }
        hadTargetLastTick = false;

        // 1. Поиск цели
        LivingEntity newTarget = findTarget();

        // Логика target switch:
        // - SwitchDelay блокирует атаку на 2 тика ПОСЛЕ смены цели
        // - НО: если старая цель стала null (target потерян), а новая цель
        //   найдена в течение 3 тиков — это НЕ реальный switch, это flicker.
        //   В этом случае НЕ обновляем lastTargetSwitchTick.
        // - Аналогично: выход из паузы НЕ считается switch.
        if (newTarget != currentTarget) {
            boolean wasRealSwitch = (currentTarget != null && newTarget != null
                    && currentTarget != newTarget);
            // Если цель пропала (стала null), но вернулась быстро — не считаем switch
            if (currentTarget != null && newTarget == null) {
                // Target lost — запоминаем, когда это случилось
                lastTargetLostTick = currentTick;
            }
            // Если цель вернулась после потери менее чем за 3 тика — НЕ switch
            boolean isFlickerReturn = (currentTarget == null && newTarget != null
                    && (currentTick - lastTargetLostTick) < 3);

            KillAuraDebug.logTargetSwitch(currentTarget, newTarget);

            if (switchDelay.value() && wasRealSwitch && !isFlickerReturn) {
                lastTargetSwitchTick = currentTick;
            }
            currentTarget = newTarget;
        }

        if (currentTarget == null) {
            if (Client.tryGet() != null && Client.get().rotationManager() != null) {
                Client.get().rotationManager().revoke("KillAura");
            }
            return;
        }

        KillAuraDebug.logTarget(currentTarget, "selected");

        // 2. Вычисляем целевую точку И кэшируем на этот тик.
        //    ВАЖНО: computeAimPoint() рандомизирует точку (HitboxTargeting),
        //    поэтому вызываем его ОДИН раз — иначе rotation будет настроена
        //    на одну точку, а raycast/attack в handleAttack() — на другую.
        cachedAimPoint = computeAimPoint(currentTarget);
        Vec3d eyePos = mc.player.getEyePos();

        // 3. Желаемые ротации (тоже кэшируем)
        cachedDesiredRot = RotationManager.lookAt(eyePos, cachedAimPoint);
        float[] desired = cachedDesiredRot;

        // 4. Aim Smoothing
        float[] smoothed = AimSimulator.step(
                serverYaw, serverPitch,
                desired[0], desired[1],
                smoothing.value(), jitter.value(), bezierPath.value()
        );

        // 5. GCD-Fix
        float[] finalRot;
        if (gcdFix.value()) {
            finalRot = GCDFix.applyGCD(serverYaw, serverPitch, smoothed[0], smoothed[1]);
            KillAuraDebug.logRotationApplied(finalRot[0], finalRot[1], GCDFix.gcd());
        } else {
            finalRot = smoothed;
        }

        // 6. Запоминаем отправляемые ротации
        serverYaw   = finalRot[0];
        serverPitch = finalRot[1];

        // 7. Запрашиваем ротацию
        RotationTarget rt = silentRotations.value()
                ? RotationTarget.silent(finalRot[0], finalRot[1], 100, "KillAura")
                : RotationTarget.full(finalRot[0], finalRot[1], 100, "KillAura");

        if (Client.tryGet() != null && Client.get().rotationManager() != null) {
            Client.get().rotationManager().request(rt);
            KillAuraDebug.logRotationRequest(finalRot[0], finalRot[1], silentRotations.value());
            hadTargetLastTick = true;
        }

        // 8. Проверяем: будем ли мы атаковать в этом тике?
        //    Если да — планируем pre-motion sprint reset
        attackPlanned = shouldAttackThisTick();
        if (attackPlanned && sprintReset.value() && mc.player.isSprinting()) {
            KillAuraDebug.trace("Attack planned — sprint reset queued");
        }

        // 9. TRACE-level: полное состояние тика
        double targetDist = -1;
        if (currentTarget != null && mc.player != null) {
            Vec3d eye = mc.player.getEyePos();
            Box tb = currentTarget.getBoundingBox().expand(hitboxExpand.value());
            targetDist = eye.distanceTo(TargetSelector.closestPointOnBox(eye, tb));
        }
        KillAuraDebug.logTickState(
                currentTick, mc.player,
                serverYaw, serverPitch,
                cachedDesiredRot != null ? cachedDesiredRot[0] : serverYaw,
                cachedDesiredRot != null ? cachedDesiredRot[1] : serverPitch,
                mc.player.isSprinting(), mc.player.isOnGround(),
                currentTarget, targetDist,
                attackPlanned, isPaused,
                isPaused ? CombatState.getInstance().pauseReason() : "none",
                isPaused ? CombatState.getInstance().pauseTicks() : 0);
    }

    // ─── Motion events: pre-sprint-reset + post-attack ───────

    @Override
    public void onMotion(MotionEvent e) {
        // Не используется — sprint-reset перенесён в onMotionUpdate(PRE)
        // (вызывается раньше, чем MotionEvent(PRE) и до применения ротаций)
    }

    @Override
    public void onMotionUpdate(MotionUpdateEvent e) {
        if (e.isPre() && attackPlanned && sprintReset.value()
                && mc.player != null && mc.player.isSprinting()) {
            // PRE-motion: сбрасываем sprint ДО отправки motion-пакета.
            // MotionUpdateEvent(PRE) вызывается ДО MotionEvent(PRE) и до
            // формирования PlayerMoveC2SPacket — это самая ранняя точка.
            // Polar видит: motion без sprint → attack в POST — валидно.
            mc.player.setSprinting(false);
            sprintWasReset = true;
            KillAuraDebug.trace("Sprint reset in PRE-motionUpdate");
        }

        if (e.isPost() && attackPlanned) {
            // POST-motion: motion-пакет уже ушёл с правильными ротациями
            // (и без sprint, если мы его сбросили в PRE)
            handleAttack();
        }
    }

    // ─── Логика атаки ─────────────────────────────────────────

    /**
     * Проверяет, должны ли мы атаковать в этом тике.
     * Вызывается в onTick() для планирования sprint reset.
     */
    private boolean shouldAttackThisTick() {
        if (currentTarget == null || mc.player == null) return false;

        // Пауза после кнокбэка
        if (knockbackPause.value() && CombatState.getInstance().isPaused()) {
            return false;
        }

        // POST-PAUSE GRACE PERIOD — КРИТИЧНО для обхода Polar!
        // После окончания knockback/rubberband pause ждём ещё N тиков,
        // чтобы позиция клиента синхронизировалась с сервером. Без этого
        // атака сразу после pause = rubberband (клиент думает dist=2.7,
        // сервер видит dist=3.5+).
        if (postPauseGraceTicks > 0) {
            KillAuraDebug.logGracePeriod(postPauseGraceTicks);
            return false;
        }

        // VELOCITY STABILITY CHECK — не атаковать если игрок ещё двигается
        // от knockback. |velocity| > threshold = knockback не settled.
        if (maxAttackVelocity.value() > 0.0) {
            double velMag = mc.player.getVelocity().length();
            boolean stable = velMag <= maxAttackVelocity.value();
            KillAuraDebug.logVelocityCheck(velMag, maxAttackVelocity.value(), stable);
            if (!stable) {
                return false;
            }
        }

        // Switch delay
        if (switchDelay.value() && currentTick - lastTargetSwitchTick < 2) {
            return false;
        }
        if (rotationCooldown.value() && currentTick - lastTargetSwitchTick < 2) {
            return false;
        }

        // ПРОВЕРКА ДИСТАНЦИИ в момент планирования
        Vec3d eyePos = mc.player.getEyePos();
        Box targetBox = currentTarget.getBoundingBox().expand(hitboxExpand.value());
        Vec3d closest = TargetSelector.closestPointOnBox(eyePos, targetBox);
        double dist = eyePos.distanceTo(closest);
        if (dist > range.value()) {
            return false;
        }

        // ПРОВЕРКА ROTATION THRESHOLD на этапе планирования.
        if (cachedDesiredRot != null) {
            float dyaw = Math.abs(net.minecraft.util.math.MathHelper.wrapDegrees(
                    serverYaw - cachedDesiredRot[0]));
            float dpit = Math.abs(serverPitch - cachedDesiredRot[1]);
            double angleDelta = Math.sqrt(dyaw * dyaw + dpit * dpit);
            boolean rotPassed = angleDelta <= rotationThreshold.value();
            KillAuraDebug.logRotationCheck(serverYaw, cachedDesiredRot[0],
                    serverPitch, cachedDesiredRot[1],
                    angleDelta, rotationThreshold.value(), rotPassed);
            if (!rotPassed) {
                return false;
            }
        }

        // LEGIT MODE — КРИТИЧНО для обхода Polar!
        // Атаковать только если crosshair УЖЕ на цели (видимая rotation
        // смотрит на хитбокс). В LegitMode KillAura только плавно наводит
        // камеру, а атака — как у обычного игрока (клик при наведении).
        if (legitMode.value() && cachedAimPoint != null) {
            Vec3d eye = mc.player.getEyePos();
            float[] currentLooking = RotationManager.lookAt(eye, cachedAimPoint);
            float dyaw = Math.abs(net.minecraft.util.math.MathHelper.wrapDegrees(
                    mc.player.getYaw() - currentLooking[0]));
            float dpit = Math.abs(mc.player.getPitch() - currentLooking[1]);
            double crosshairDelta = Math.sqrt(dyaw * dyaw + dpit * dpit);
            if (crosshairDelta > crosshairTolerance.value()) {
                return false;  // crosshair ещё не на цели
            }
        }

        // Кулдаун
        float cooldown = mc.player.getAttackCooldownProgress(0.5f);
        if (cooldown < cooldownThreshold.value()) {
            return false;
        }

        // CPS-jitter
        if (cpsJitter.value() && currentTick < nextAttackTick) {
            return false;
        }

        // OnGround
        if (onlyGround.value() && !mc.player.isOnGround()) {
            return false;
        }

        return true;
    }

    private void handleAttack() {
        if (currentTarget == null || mc.player == null) return;
        ClientPlayerEntity self = mc.player;

        // ПРОВЕРКА ПАУЗЫ (knockback/rubberband)
        if (knockbackPause.value() && CombatState.getInstance().isPaused()) {
            KillAuraDebug.logAttackSkip("knockback paused: "
                    + CombatState.getInstance().pauseReason());
            return;
        }

        // ПРОВЕРКА ДИСТАНЦИИ — главная защита от «битья воздухом».
        Vec3d eyePos = self.getEyePos();
        Box targetBox = currentTarget.getBoundingBox().expand(hitboxExpand.value());
        Vec3d closest = TargetSelector.closestPointOnBox(eyePos, targetBox);
        double realDist = eyePos.distanceTo(closest);

        if (realDist > range.value()) {
            KillAuraDebug.logAttackSkip(String.format(
                    "out of range: %.2f > %.2f", realDist, range.value()));
            return;
        }

        // ПРОВЕРКА ЖИВОСТИ ЦЕЛИ
        if (!currentTarget.isAttackable() || currentTarget.getHealth() <= 0
                || currentTarget.isRemoved()) {
            KillAuraDebug.logAttackSkip("target invalid (dead/removed)");
            currentTarget = null;
            return;
        }

        // ПРОВЕРКА ROTATION THRESHOLD — КРИТИЧЕСКАЯ для обхода Polar!
        // Polar проверяет, что серверная rotation игрока смотрит на цель.
        // Если smoothing/GCD-фикс "не доехали" — атака = "битьё мимо" = флаг.
        // Используем кэшированную точку (cachedAimPoint), на которую
        // настроена rotation, чтобы избежать рассинхрона.
        if (cachedDesiredRot != null) {
            float dyaw = Math.abs(net.minecraft.util.math.MathHelper.wrapDegrees(
                    serverYaw - cachedDesiredRot[0]));
            float dpit = Math.abs(serverPitch - cachedDesiredRot[1]);
            double angleDelta = Math.sqrt(dyaw * dyaw + dpit * dpit);
            if (angleDelta > rotationThreshold.value()) {
                KillAuraDebug.logAttackSkip(String.format(
                        "rotation delta %.1f° > threshold %.1f° (smoothing not arrived)",
                        angleDelta, rotationThreshold.value()));
                return;
            }
        }

        // Финальная проверка кулдауна
        float cooldown = self.getAttackCooldownProgress(0.5f);
        if (cooldown < cooldownThreshold.value()) {
            KillAuraDebug.logAttackSkip("cooldown: " + cooldown);
            return;
        }

        // LEGIT MODE — финальная проверка crosshair на момент атаки.
        // В LegitMode атака уходит ТОЛЬКО если visible rotation (камера)
        // реально смотрит на цель. Это как обычный клик игрока — Polar
        // не может отличить от человека.
        if (legitMode.value() && cachedAimPoint != null) {
            Vec3d eye = self.getEyePos();
            float[] currentLooking = RotationManager.lookAt(eye, cachedAimPoint);
            float dyaw = Math.abs(net.minecraft.util.math.MathHelper.wrapDegrees(
                    self.getYaw() - currentLooking[0]));
            float dpit = Math.abs(self.getPitch() - currentLooking[1]);
            double crosshairDelta = Math.sqrt(dyaw * dyaw + dpit * dpit);
            if (crosshairDelta > crosshairTolerance.value()) {
                KillAuraDebug.logAttackSkip(String.format(
                        "crosshair delta %.1f° > tolerance %.1f° (legit mode)",
                        crosshairDelta, crosshairTolerance.value()));
                return;
            }
        }

        // Финальная проверка raycast — используем КЭШИРОВАННУЮ точку,
        // на которую настроена rotation (не новую случайную точку!)
        if (raycastCheck.value() && cachedAimPoint != null) {
            if (!TargetSelector.canSee(self, eyePos, cachedAimPoint)) {
                KillAuraDebug.logAttackSkip("no line-of-sight");
                return;
            }
        }

        performAttack(currentTarget, cooldown, realDist);

        // Устанавливаем следующий тик атаки с CPS-jitter
        int baseCooldownTicks = (int) Math.ceil(self.getAttackCooldownProgressPerTick());
        if (cpsJitter.value()) {
            nextAttackTick = currentTick + AimSimulator.cpsJitter(baseCooldownTicks);
        } else {
            nextAttackTick = currentTick + baseCooldownTicks;
        }
    }

    // ─── Вспомогательные методы ───────────────────────────────

    private LivingEntity findTarget() {
        double effectiveRange = range.value();
        if (reachJitter.value()) {
            effectiveRange -= AimSimulator.randomRange(0.0, 0.2);
        }
        return TargetSelector.findTarget(
                effectiveRange,
                fov.value(),
                raycastCheck.value(),
                hitboxExpand.value(),
                sortMode.value()
        );
    }

    private Vec3d computeAimPoint(LivingEntity target) {
        if (!hitboxTargeting.value()) {
            return target.getEyePos();
        }
        Box box = target.getBoundingBox().expand(hitboxExpand.value());
        Vec3d min = new Vec3d(box.minX, box.minY, box.minZ);
        Vec3d max = new Vec3d(box.maxX, box.maxY, box.maxZ);
        return AimSimulator.randomHitboxPoint(min, max, centerBias.value());
    }

    /**
     * Отправляет атаку — ТОЧНО как ванильный {@code MinecraftClient.doAttack()}.
     *
     * <p><b>v3 — исправление двойных пакетов:</b></p>
     * <p>Раньше я отправлял HandSwingC2SPacket вручную И вызывал
     * {@code player.swingHand()}, который в {@code ClientPlayerEntity}
     * САМ отправляет HandSwingC2SPacket. Получалось 2 swing-пакета подряд
     * → Polar флагал BadPackets / InvalidHandSwing.</p>
     *
     * <p>Теперь делаем ровно как ванила:</p>
     * <ol>
     *   <li>{@code interactionManager.attackEntity(player, target)} — отправляет
     *       PlayerInteractEntityC2SPacket + syncSelectedSlot + player.attack(target)
     *       + player.resetLastAttackedTicks().</li>
     *   <li>{@code player.swingHand(Hand.MAIN_HAND)} — клиентский swing animation
     *       + ClientPlayerEntity.swingHand() САМ отправляет HandSwingC2SPacket.</li>
     * </ol>
     *
     * <p><b>НИКАКИХ отдельных HandSwingC2SPacket вручную!</b> Это была
     * главная причина флагов Polar — двойной swing-пакет после каждой атаки.</p>
     */
    private void performAttack(LivingEntity target, float cooldown, double dist) {
        try {
            ClientPlayerEntity self = mc.player;
            if (self == null) return;

            KillAuraDebug.logAttack(target, cooldown, (float) dist, false);

            // 1. interactionManager.attackEntity делает (см. ClientPlayerInteractionManager.attackEntity):
            //    - syncSelectedSlot() — отправляет HeldItemChangeC2SPacket если нужно
            //    - networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(...))
            //    - player.attack(target) — клиентский prediction (расчёт урона на клиенте)
            //    - player.resetLastAttackedTicks() — сброс кулдауна
            if (mc.interactionManager != null) {
                mc.interactionManager.attackEntity(self, target);
            } else if (mc.getNetworkHandler() != null) {
                // Fallback (крайне редкий случай): только отправка пакета,
                // без client-side prediction. НЕ вызываем player.attack()
                // повторно — это сделает interactionManager.
                PlayerInteractEntityC2SPacket pkt =
                        PlayerInteractEntityC2SPacket.attack(target, self.isSneaking());
                mc.getNetworkHandler().sendPacket(pkt);
                self.resetLastAttackedTicks();
            }

            // 2. swingHand — ClientPlayerEntity.swingHand() САМ отправляет
            //    HandSwingC2SPacket. НЕ отправляем его вручную отдельно!
            //    Раньше тут был mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(...))
            //    — это давало ДВОЙНОЙ swing-пакет = флаг Polar BadPackets.
            self.swingHand(Hand.MAIN_HAND);

        } catch (Throwable t) {
            KillAuraDebug.logError("performAttack failed", t);
            Logger.error("KillAura attack error", t);
        }
    }
}
