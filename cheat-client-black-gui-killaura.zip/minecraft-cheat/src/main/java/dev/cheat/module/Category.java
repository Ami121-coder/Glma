package dev.cheat.module;

/**
 * Категории модулей. Используются для группировки в ClickGUI
 * и списке команд.
 */
public enum Category {
    COMBAT    ("Combat",     0xFFE74C3C),
    MOVEMENT  ("Movement",   0xFF3498DB),
    PLAYER    ("Player",     0xFF2ECC71),
    RENDER    ("Render",     0xFF9B59B6),
    WORLD     ("World",      0xFFF39C12),
    MISC      ("Misc",       0xFF95A5A6),
    HUD       ("HUD",        0xFF1ABC9C),
    CLIENT    ("Client",     0xFFECF0F1);

    private final String displayName;
    private final int    color;

    Category(String name, int color) {
        this.displayName = name;
        this.color       = color;
    }

    public String displayName() { return displayName; }
    public int    color()       { return color;       }
}
