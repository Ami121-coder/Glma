package dev.cheat;

import dev.cheat.manager.CommandManager;
import dev.cheat.manager.ConfigManager;
import dev.cheat.manager.EventManager;
import dev.cheat.manager.FriendManager;
import dev.cheat.manager.ModuleManager;
import dev.cheat.manager.NetworkBuffer;
import dev.cheat.manager.PacketManager;
import dev.cheat.manager.RotationManager;
import dev.cheat.render.anim.AnimationManager;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.Logger;
import net.minecraft.client.MinecraftClient;

/**
 * Глобальный singleton клиента.
 *
 * <p>Хранит ссылки на все топ-менеджеры и предоставляет статический доступ
 * вида {@code Client.INSTANCE.moduleManager()}. Это намеренно «global state» —
 * такова природа читов: им нужен быстрый доступ к общим сервисам из любого места.</p>
 *
 * <p>Заполняется один раз в {@link dev.cheat.core.Core#bootstrap()}.</p>
 */
public final class Client {

    private static Client INSTANCE;

    private final MinecraftClient mc;

    // ─── Менеджеры ─────────────────────────────────────────────
    private final ModuleManager     moduleManager;
    private final CommandManager    commandManager;
    private final ConfigManager     configManager;
    private final FriendManager     friendManager;
    private final EventManager      eventManager;
    private final RotationManager   rotationManager;
    private final PacketManager     packetManager;
    private final NetworkBuffer     networkBuffer;
    private final AnimationManager  animationManager;

    // ─── Состояние ─────────────────────────────────────────────
    private volatile boolean running = false;
    private     boolean     firstFrame = true;
    private     Theme       theme      = Theme.DEFAULT;

    private Client(MinecraftClient mc) {
        this.mc = mc;

        // Порядок создания важен:
        //   1) eventManager — шина, через которую общаются все
        //   2) configManager — конфигурация
        //   3) animationManager — нужен UI и модулям
        //   4) packetManager + networkBuffer — перехват пакетов
        //   5) rotationManager — управляет ротациями через motion-события
        //   6) moduleManager — модули (могут зависеть от вышеперечисленного)
        //   7) commandManager — команды
        //   8) friendManager — друзья
        this.eventManager    = new EventManager();
        this.configManager   = new ConfigManager();
        this.animationManager= new AnimationManager();
        this.networkBuffer   = new NetworkBuffer();
        this.packetManager   = new PacketManager();
        this.rotationManager = new RotationManager();
        this.moduleManager   = new ModuleManager();
        this.commandManager  = new CommandManager();
        this.friendManager   = new FriendManager();
    }

    public static void create(MinecraftClient mc) {
        if (INSTANCE != null) {
            throw new IllegalStateException("Client already initialized");
        }
        INSTANCE = new Client(mc);
        Logger.info("Client singleton created");
    }

    /** Инициализация завершена — менеджеры зарегистрированы и готовы к работе. */
    public void markRunning() {
        this.running = true;
        Logger.info("Client is now running");
    }

    public static Client get() {
        if (INSTANCE == null) {
            throw new IllegalStateException("Client accessed before bootstrap");
        }
        return INSTANCE;
    }

    /**
     * Безопасный геттер: возвращает {@code null} вместо бросания исключения,
     * если {@link Client} ещё не создан. Используется в mixin'ах и других
     * местах, где клиент может быть ещё не инициализирован.
     */
    public static Client tryGet() {
        return INSTANCE;
    }

    // ─── Геттеры ───────────────────────────────────────────────
    public MinecraftClient  mc()                { return mc;                }
    public ModuleManager    moduleManager()     { return moduleManager;     }
    public CommandManager   commandManager()    { return commandManager;    }
    public ConfigManager    configManager()     { return configManager;     }
    public FriendManager    friendManager()     { return friendManager;     }
    public EventManager     eventManager()      { return eventManager;      }
    public RotationManager  rotationManager()   { return rotationManager;   }
    public PacketManager    packetManager()     { return packetManager;     }
    public NetworkBuffer    networkBuffer()     { return networkBuffer;     }
    public AnimationManager animationManager()  { return animationManager;  }

    public boolean isRunning()    { return running; }
    public boolean isFirstFrame() { return firstFrame; }
    public void    clearFirstFrame() { this.firstFrame = false; }

    /** Текущая тема оформления. Используется UI и модулями. */
    public Theme   theme()         { return theme; }
    public void    setTheme(Theme t) { this.theme = t; }
}
