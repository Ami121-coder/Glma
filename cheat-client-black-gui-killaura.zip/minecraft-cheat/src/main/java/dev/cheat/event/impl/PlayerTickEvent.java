package dev.cheat.event.impl;

import dev.cheat.event.Event;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Тик игрока. Каждый {@code ClientPlayerEntity.tick()} триггерит PRE/POST.
 */
public record PlayerTickEvent(Phase phase, ClientPlayerEntity player) implements Event {

    public enum Phase { PRE, POST }

    public boolean isPre()  { return phase == Phase.PRE;  }
    public boolean isPost() { return phase == Phase.POST; }
}
