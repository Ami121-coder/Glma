package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;

/**
 * Событие движения игрока (дискретный шаг).
 *
 * <p>Вызывается из {@code ClientPlayerEntityMixin.tick()} после применения
 * физики и до отправки позиционного пакета. Здесь можно подменить
 * позицию/скорость/yaw/pitch (для Movement-модулей).</p>
 */
public final class PlayerMoveEvent extends Cancellable {

    public double x, y, z;
    public float  yaw, pitch;
    public boolean onGround;

    public PlayerMoveEvent(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        this.x = x; this.y = y; this.z = z;
        this.yaw = yaw; this.pitch = pitch;
        this.onGround = onGround;
    }
}
