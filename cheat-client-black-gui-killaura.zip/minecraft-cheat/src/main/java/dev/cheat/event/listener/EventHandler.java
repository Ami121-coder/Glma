package dev.cheat.event.listener;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Помечает методы-обработчики событий в подписчиках.
 *
 * <p>Метод должен иметь сигнатуру {@code void on(EventType e)}.</p>
 *
 * <p>Параметр {@link #priority()} задаёт порядок вызова внутри одного типа.
 * Меньшее значение = выше приоритет (вызовется раньше).</p>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventHandler {
    int priority() default 100;
}
