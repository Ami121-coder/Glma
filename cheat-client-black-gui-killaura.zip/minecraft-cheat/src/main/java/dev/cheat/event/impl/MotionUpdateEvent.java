package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Событие вокруг {@code ClientPlayerEntity.sendMovementPackets()}.
 *
 * <p>В отличие от {@link MotionEvent}, это событие не подменяет значения —
 * оно лишь сигнализирует:</p>
 * <ul>
 *   <li>{@link Phase#PRE} — игрок готовится сформировать motion-пакет.</li>
 *   <li>{@link Phase#POST} — motion-пакеты уже отправлены, можно сбросить
 *       временное состояние (например, ротации модулей).</li>
 * </ul>
 *
 * <p><b>Используется в RotationManager:</b> при PRE — применения целевых
 * ротаций к player.yaw/pitch; при POST — восстановление визуальных ротаций.</p>
 */
public final class MotionUpdateEvent extends Cancellable {

    private final ClientPlayerEntity player;
    private final Phase phase;

    public MotionUpdateEvent(Phase phase, ClientPlayerEntity player) {
        this.phase  = phase;
        this.player = player;
    }

    public Phase              phase()  { return phase;  }
    public ClientPlayerEntity player() { return player; }
    public boolean isPre()             { return phase == Phase.PRE;  }
    public boolean isPost()            { return phase == Phase.POST; }

    public enum Phase { PRE, POST }
}
