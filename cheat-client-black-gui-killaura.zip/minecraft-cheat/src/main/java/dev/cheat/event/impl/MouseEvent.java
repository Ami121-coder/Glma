package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;

/**
 * Событие мыши. Триггерится из {@link dev.cheat.mixin.MouseMixin}.
 *
 * <p>{@link #button}: 0 = LEFT, 1 = RIGHT, 2 = MIDDLE, 3+ = extra.
 * {@link #action}: 0 = RELEASE, 1 = PRESS, 2 = REPEAT.</p>
 *
 * <p>Если событие отменено — родной обработчик Minecraft не получит клик.</p>
 */
public final class MouseEvent extends Cancellable {

    private final int  button;
    private final int  action;
    private final int  modifiers;
    private final double x;
    private final double y;

    public MouseEvent(int button, int action, int modifiers, double x, double y) {
        this.button    = button;
        this.action    = action;
        this.modifiers = modifiers;
        this.x         = x;
        this.y         = y;
    }

    public int    button()    { return button; }
    public int    action()    { return action; }
    public int    modifiers() { return modifiers; }
    public double x()         { return x; }
    public double y()         { return y; }

    public boolean isPressed()  { return action == 1; }
    public boolean isReleased() { return action == 0; }
    public boolean isRepeat()   { return action == 2; }

    public boolean isLeft()   { return button == 0; }
    public boolean isRight()  { return button == 1; }
    public boolean isMiddle() { return button == 2; }
}
