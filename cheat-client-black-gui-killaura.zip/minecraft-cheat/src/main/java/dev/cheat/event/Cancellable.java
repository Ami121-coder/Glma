package dev.cheat.event;

/**
 * Базовый класс для отменяемых событий.
 *
 * <p>Если {@link #cancel()} вызван, действие в mixin-хуке должно быть
 * прервано (через {@code ci.cancel()} или {@code cir.setReturnValue(...)})</p>
 */
public abstract class Cancellable implements Event {

    private boolean cancelled = false;

    public boolean isCancelled() {
        return cancelled;
    }

    public void cancel() {
        this.cancelled = true;
    }

    public void setCancelled(boolean v) {
        this.cancelled = v;
    }
}
