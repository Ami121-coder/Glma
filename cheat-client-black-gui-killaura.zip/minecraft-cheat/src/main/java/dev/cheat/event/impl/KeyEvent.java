package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;

/**
 * Событие нажатия/удержания клавиши. Триггерится из KeyboardMixin.
 *
 * <p>Если событие отменено, родной обработчик Minecraft не получит клавишу.</p>
 */
public final class KeyEvent extends Cancellable {

    private final int  key;
    private final int  scancode;
    private final int  action;     // GLFW_PRESS=1, GLFW_RELEASE=0, GLFW_REPEAT=2
    private final int  modifiers;

    public KeyEvent(int key, int scancode, int action, int modifiers) {
        this.key       = key;
        this.scancode  = scancode;
        this.action    = action;
        this.modifiers = modifiers;
    }

    public int key()        { return key; }
    public int scancode()   { return scancode; }
    public int action()     { return action; }
    public int modifiers()  { return modifiers; }

    public boolean isPressed()  { return action == 1; }
    public boolean isReleased() { return action == 0; }
    public boolean isRepeat()   { return action == 2; }
}
