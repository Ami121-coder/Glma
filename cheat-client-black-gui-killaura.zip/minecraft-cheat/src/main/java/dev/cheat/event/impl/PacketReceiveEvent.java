package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;
import net.minecraft.network.packet.Packet;

/**
 * Событие получения пакета от сервера.
 *
 * <p>Если событие отменено — Minecraft проигнорирует пакет. Используется
 * для анти- knockback, anti-velocity, фильтра пакетов сервера.</p>
 */
public final class PacketReceiveEvent<T extends Packet<?>> extends Cancellable {

    private final T packet;

    public PacketReceiveEvent(T packet) {
        this.packet = packet;
    }

    public T       packet()      { return packet; }
    public Class<?> packetType() { return packet.getClass(); }
}
