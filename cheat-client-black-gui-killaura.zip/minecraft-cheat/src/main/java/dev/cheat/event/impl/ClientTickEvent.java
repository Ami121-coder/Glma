package dev.cheat.event.impl;

import dev.cheat.event.Event;

/**
 * Главный клиентский тик. Вызывается из {@code MinecraftClientMixin.tick()}.
 * Происходит 20 раз/сек (в среднем) на стороне клиента.
 */
public record ClientTickEvent(Phase phase) implements Event {

    public enum Phase { PRE, POST }

    public boolean isPre()  { return phase == Phase.PRE;  }
    public boolean isPost() { return phase == Phase.POST; }
}
