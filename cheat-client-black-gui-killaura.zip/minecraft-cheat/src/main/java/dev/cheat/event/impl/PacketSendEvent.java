package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;
import net.minecraft.network.packet.Packet;

/**
 * Событие отправки пакета на сервер.
 *
 * <p>Если событие отменено — пакет не отправится. Используется для
 * патчей анимации, фейковых пакетов и т.п.</p>
 *
 * <p>{@link #setPacket(Object)} подменяет пакет: {@code ClientConnectionMixin}
 * через {@code ModifyVariable} подхватит replacement до отправки в сеть.</p>
 *
 * @param <T> тип пакета (обычно {@code Packet&lt;?&gt;})
 */
public final class PacketSendEvent<T extends Packet<?>> extends Cancellable {

    /** Thread-local для передачи replacement в mixin (после обработки событием). */
    private static final ThreadLocal<Packet<?>> REPLACEMENT = new ThreadLocal<>();

    private T packet;

    public PacketSendEvent(T packet) {
        this.packet = packet;
    }

    public T       packet()         { return packet; }

    /**
     * Подменить пакет, который будет отправлен. Вызывать только в handler'е.
     * Mixin заберёт replacement через {@link #consumeReplacement()}.
     */
    public void    setPacket(T p)   {
        this.packet = p;
        if (p != null) {
            REPLACEMENT.set(p);
        }
    }

    public Class<?> packetType()    { return packet.getClass(); }

    /** Забрать replacement (mixin) и очистить thread-local. */
    public static Packet<?> consumeReplacement() {
        Packet<?> p = REPLACEMENT.get();
        REPLACEMENT.remove();
        return p;
    }
}

