package dev.cheat.event.impl;

import dev.cheat.event.Event;
import net.minecraft.client.gui.DrawContext;

/**
 * 2D-рендер на HUD. Вызывается из {@code InGameHudMixin.render()}.
 * Используется для watermark, ArrayList, ClickGUI.
 *
 * <p>Несёт {@link DrawContext} — через него модули рисуют текст/фигуры.</p>
 */
public final class Render2DEvent implements Event {

    private final DrawContext context;
    private final float tickDelta;
    private final int screenWidth;
    private final int screenHeight;

    public Render2DEvent(DrawContext context, float tickDelta, int screenWidth, int screenHeight) {
        this.context     = context;
        this.tickDelta   = tickDelta;
        this.screenWidth = screenWidth;
        this.screenHeight= screenHeight;
    }

    public DrawContext context()     { return context;      }
    public float       tickDelta()   { return tickDelta;    }
    public int         screenWidth() { return screenWidth;  }
    public int         screenHeight(){ return screenHeight; }
}
