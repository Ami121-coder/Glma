package dev.cheat.event.impl;

import dev.cheat.event.Event;
import net.minecraft.client.util.math.MatrixStack;

/**
 * 3D-рендер в мире. Триггерится из WorldRendererMixin.
 * Используется для ESP, Tracers, BlockOutline и т.п.
 */
public record Render3DEvent(MatrixStack matrices, float tickDelta,
                            double cameraX, double cameraY, double cameraZ) implements Event {
}
