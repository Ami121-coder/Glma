package dev.cheat.event.impl;

import dev.cheat.event.Cancellable;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Pre-Motion событие.
 *
 * <p>Вызывается из {@code ClientPlayerEntityMixin.sendMovementPackets()} HEAD —
 * <b>до</b> того, как ванильный код отправит {@code PlayerMoveC2SPacket}.</p>
 *
 * <p>Это <b>главная точка</b> для подмены позиции/ротаций перед отправкой.
 * KillAura, Movement-модули, Rotation-менеджеры — все работают здесь.</p>
 *
 * <p>{@link #cancel()} отменит отправку ванильного motion-пакета полностью,
 * но модуль должен будет сам отправить нужный пакет через {@link dev.cheat.manager.PacketManager}.</p>
 *
 * <p><b>Контракт:</b> Изменения применяются к {@code player} (его yaw/pitch/pos).
 * Каркас скопирует изменённые значения обратно в снапшот в POST-фазе.</p>
 */
public final class MotionEvent extends Cancellable {

    private final ClientPlayerEntity player;
    private final Phase phase;

    // Подменяемые значения (PRE). В POST — это уже отправленные значения.
    public double x, y, z;
    public float  yaw, pitch;
    public boolean onGround;
    public boolean horizontalCollision;

    // Флаги: какие поля ванильный код должен использовать ИЗ события, а не из player.
    public boolean modifyPosition;
    public boolean modifyRotation;
    public boolean modifyOnGround;

    public MotionEvent(Phase phase, ClientPlayerEntity player,
                       double x, double y, double z,
                       float yaw, float pitch,
                       boolean onGround, boolean horizontalCollision) {
        this.phase    = phase;
        this.player   = player;
        this.x = x; this.y = y; this.z = z;
        this.yaw = yaw; this.pitch = pitch;
        this.onGround = onGround;
        this.horizontalCollision = horizontalCollision;
    }

    public Phase              phase()                { return phase;  }
    public ClientPlayerEntity player()               { return player; }
    public boolean            isPre()                { return phase == Phase.PRE;  }
    public boolean            isPost()               { return phase == Phase.POST; }

    // ─── Удобные setters для Rotation-менеджеров ─────────────

    /** Подменить только ротации (yaw, pitch). Position/ground остаются ванильными. */
    public void setRotation(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.modifyRotation = true;
    }

    /** Подменить только позицию. */
    public void setPosition(double x, double y, double z) {
        this.x = x; this.y = y; this.z = z;
        this.modifyPosition = true;
    }

    /** Подменить onGround. */
    public void setOnGround(boolean v) {
        this.onGround = v;
        this.modifyOnGround = true;
    }

    /** Полная подмена всех полей. */
    public void setAll(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        setPosition(x, y, z);
        setRotation(yaw, pitch);
        setOnGround(onGround);
    }

    public enum Phase { PRE, POST }
}
