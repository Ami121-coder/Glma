package dev.cheat.manager;

import dev.cheat.Client;
import dev.cheat.event.impl.PacketReceiveEvent;
import dev.cheat.event.impl.PacketSendEvent;
import dev.cheat.event.listener.EventHandler;
import dev.cheat.event.listener.EventListener;
import dev.cheat.util.Logger;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

/**
 * Менеджер пакетов.
 *
 * <p>Центральная точка для перехвата, фильтрации, замены и отмены пакетов
 * на лету. Использует {@link PacketRule} как декларативный контракт.</p>
 *
 * <p>Перехват реализован через существующие события
 * {@link PacketSendEvent} и {@link PacketReceiveEvent}, которые публикует
 * {@code ClientConnectionMixin}. Менеджер подписан первым (priority=10),
 * поэтому его решение (ALLOW/DENY) применяется до того, как модули увидят пакет.</p>
 *
 * <p><b>API:</b></p>
 * <ul>
 *   <li>{@link #register(PacketRule)} — добавить правило</li>
 *   <li>{@link #unregister(String)} — снять все правила модуля</li>
 *   <li>{@link #send(Packet)} — обёртка над {@code connection.send(packet)}
 *       с учётом текущих правил (например, если модуль сам отправляет пакет,
 *       он пройдёт через правила других модулей)</li>
 * </ul>
 *
 * <p><b>Важно:</b> Если правило возвращает {@link PacketRule.Action#BUFFER},
 * пакет попадает в {@link NetworkBuffer} и не отправится, пока не будет
 * явно flushed. Это полезно для batching'а, no-packet-glitches и т.п.</p>
 */
public final class PacketManager implements EventListener {

    private final List<PacketRule> rules = new CopyOnWriteArrayList<>();

    public PacketManager() {
        // Подписка отложена — выполняется из Core.bootstrap() через subscribeSelf().
    }

    /** Подписать менеджер на события. Вызывается из Core.bootstrap(). */
    public void subscribeSelf() {
        try {
            Client.get().eventManager().subscribe(this);
        } catch (Throwable t) {
            Logger.error("PacketManager.subscribeSelf failed", t);
        }
    }

    // ─── Регистрация правил ───────────────────────────────────

    public <T extends PacketRule> T register(T rule) {
        if (rule == null) return null;
        // Удаляем старые правила того же владельца
        rules.removeIf(r -> r.owner().equals(rule.owner()));
        rules.add(rule);
        rules.sort(Comparator.comparingInt(PacketRule::priority));
        Logger.info("PacketManager: registered rule '" + rule.owner() + "'");
        return rule;
    }

    public void unregister(String owner) {
        rules.removeIf(r -> r.owner().equals(owner));
    }

    public void unregister(PacketRule rule) {
        rules.remove(rule);
    }

    public int ruleCount() { return rules.size(); }

    // ─── Точка перехвата отправки ─────────────────────────────

    /**
     * Применяет все правила к пакету.
     *
     * @param packet исходный пакет
     * @param direction направление
     * @return финальное решение: что отправить (или null — отменить)
     */
    public Packet<?> process(Packet<?> packet, PacketRule.Direction direction) {
        if (packet == null) return null;

        Packet<?> current = packet;
        for (PacketRule rule : new ArrayList<>(rules)) {
            try {
                if (!rule.filter().test(current)) continue;
                PacketRule.Action action = rule.handle(current, direction);
                if (action == null) continue;

                switch (action.type) {
                    case PASS:
                        continue;
                    case ALLOW:
                        return current;
                    case DENY:
                        return null;
                    case REPLACE:
                        if (action.replacement != null) {
                            current = action.replacement;
                        }
                        continue;
                    case BUFFER:
                        if (direction == PacketRule.Direction.OUT
                                && Client.get() != null
                                && Client.get().networkBuffer() != null) {
                            Client.get().networkBuffer().enqueue(current);
                        }
                        return null;
                }
            } catch (Throwable t) {
                Logger.error("PacketRule '" + rule.owner() + "' error", t);
            }
        }
        return current;
    }

    // ─── Event handlers (вызываются из PacketSend/ReceiveEvent) ──

    @EventHandler(priority = 10)
    public void onPacketSend(PacketSendEvent<Packet<?>> e) {
        Packet<?> processed = process(e.packet(), PacketRule.Direction.OUT);
        if (processed == null) {
            e.cancel();
        } else if (processed != e.packet()) {
            e.setPacket(processed);
        }
    }

    @EventHandler(priority = 10)
    public void onPacketReceive(PacketReceiveEvent<Packet<?>> e) {
        Packet<?> processed = process(e.packet(), PacketRule.Direction.IN);
        if (processed == null) {
            e.cancel();
        }
        // Замена входящих пакетов — редкий случай, обычно не нужна
    }

    // ─── Helper: отправить пакет с учётом правил ──────────────

    /**
     * Отправить пакет через текущий connection, пропуская через правила.
     * Удобно для модулей, которые сами генерируют пакеты.
     */
    public void send(Packet<?> packet) {
        if (Client.get() == null) return;
        ClientConnection conn = connection();
        if (conn == null) return;
        Packet<?> processed = process(packet, PacketRule.Direction.OUT);
        if (processed != null) {
            conn.send(processed);
        }
    }

    /**
     * Отправить пакет, <b>минуя</b> правила. Используется для критических
     * системных пакетов (heartbeats, keepalive).
     */
    public void sendBypass(Packet<?> packet) {
        ClientConnection conn = connection();
        if (conn != null) conn.send(packet);
    }

    private ClientConnection connection() {
        var mc = Client.get().mc();
        if (mc == null || mc.getNetworkHandler() == null) return null;
        return mc.getNetworkHandler().getConnection();
    }
}
