package dev.cheat.manager;

import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.module.ModuleInfo;
import dev.cheat.module.ModulePriority;
import dev.cheat.util.Logger;

import java.io.IOException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Менеджер модулей.
 *
 * <p>Хранит все зарегистрированные модули, предоставляет доступ по имени
 * и по классу. Поддерживает два способа регистрации:</p>
 * <ul>
 *   <li>Вручную через {@link #register(Class)} или {@link #register(Module)};</li>
 *   <li>Автоматически через {@link #autoDiscover()} — сканирует пакет
 *       {@code dev.cheat.module.impl} и инстанцирует все классы, помеченные
 *       {@link ModuleInfo}. Вызывается по умолчанию из {@link #registerDefaults()}.</li>
 * </ul>
 *
 * <p>Итерация в {@link #all()} и {@link #tickAll()} идёт по приоритету
 * (см. {@link ModulePriority} — меньшее значение = раньше).</p>
 */
public final class ModuleManager {

    /** Базовый пакет, где лежат реализации модулей. */
    public static final String IMPL_PACKAGE = "dev.cheat.module.impl";

    private final Map<String,  Module> byName = new LinkedHashMap<>();
    private final Map<Class<?>, Module> byType = new LinkedHashMap<>();

    /** Регистрирует модуль по классу — инстанцирует через рефлексию. */
    public <T extends Module> T register(Class<T> type) {
        T module;
        try {
            module = type.getDeclaredConstructor().newInstance();
        } catch (Throwable t) {
            throw new RuntimeException("Cannot instantiate module " + type.getName(), t);
        }
        return register(module);
    }

    /** Регистрирует уже созданный экземпляр модуля. */
    public <T extends Module> T register(T module) {
        String name = module.getName().toLowerCase();
        if (byName.containsKey(name)) {
            Logger.warn("Duplicate module name: " + name);
            return module;
        }
        byName.put(name, module);
        byType.put(module.getClass(), module);

        // Если @ModuleInfo(enabledByDefault = true) — включаем.
        if (module.isEnabled()) {
            try { module.enable(); } catch (Throwable ignored) {}
        }
        Logger.info("Registered module: " + module.getName()
                + " [" + module.getCategory().displayName() + "]");
        return module;
    }

    /**
     * Регистрирует модули по умолчанию.
     *
     * <p>Использует ЯВНУЮ регистрацию вместо автообнаружения через рефлексию.
     * Автообнаружение через {@code ClassLoader.getResources(...)} нестабильно
     * в production JAR (особенно под Fabric Knot classloader) — на некоторых
     * сборках сканирование находит 0 классов, хотя они физически есть в JAR.
     * Явная регистрация лишена этой проблемы.</p>
     *
     * <p>Чтобы добавить новый модуль: допиши его сюда одной строкой.
     * {@code registerDefaults()} гарантированно вызывается из {@code Core.bootstrap()}
     * после создания {@link dev.cheat.Client}.</p>
     */
    public void registerDefaults() {
        // ── Явная регистрация всех модулей ─────────────────────────
        // Это надёжнее автообнаружения через рефлексию: работает и в dev,
        // и в production JAR (Fabric Knot classloader).
        try {
            register(dev.cheat.module.impl.ClickGUIModule.class);
        } catch (Throwable t) {
            Logger.error("Failed to register ClickGUIModule", t);
        }
        try {
            register(dev.cheat.module.impl.KillAuraModule.class);
        } catch (Throwable t) {
            Logger.error("Failed to register KillAuraModule", t);
        }
        // ── Конец явной регистрации ────────────────────────────────

        // NOTE: autoDiscover() убран намеренно — в production JAR под Fabric
        // Knot classloader он либо находит 0 (бесполезно), либо находит
        // уже явно зарегистрированные модули (warning "Duplicate module name").
        // Все модули должны быть прописаны явно выше.
        Logger.info("ModuleManager: explicit registration complete");
    }

    /**
     * Сканирует classpath в {@value #IMPL_PACKAGE} и регистрирует все
     * {@link Module}-наследники с аннотацией {@link ModuleInfo}.
     *
     * <p>Алгоритм:</p>
     * <ol>
     *   <li>Читает содержимое директории {@link ClassLoader#getResources}.</li>
     *   <li>Для каждого {@code .class} файла пытается загрузить класс.</li>
     *   <li>Фильтрует: concrete, имеет {@link ModuleInfo}, наследник {@link Module}.</li>
     *   <li>Инстанцирует и регистрирует.</li>
     * </ol>
     *
     * @return количество зарегистрированных модулей
     */
    public int autoDiscover() {
        return autoDiscover(IMPL_PACKAGE);
    }

    public int autoDiscover(String packageName) {
        List<Class<? extends Module>> classes = scanPackage(packageName);
        int count = 0;
        for (Class<? extends Module> c : classes) {
            try {
                register(c);
                count++;
            } catch (Throwable t) {
                Logger.error("Failed to register module " + c.getName(), t);
            }
        }
        return count;
    }

    /**
     * Сканирует пакет и возвращает все concrete классы-наследники Module
     * с аннотацией {@link ModuleInfo}.
     */
    @SuppressWarnings("unchecked")
    private List<Class<? extends Module>> scanPackage(String packageName) {
        List<Class<? extends Module>> result = new ArrayList<>();
        String path = packageName.replace('.', '/');

        try {
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            if (cl == null) cl = ModuleManager.class.getClassLoader();
            java.util.Enumeration<java.net.URL> resources = cl.getResources(path);

            List<java.nio.file.Path> roots = new ArrayList<>();
            while (resources.hasMoreElements()) {
                java.net.URL url = resources.nextElement();
                String proto = url.getProtocol();
                if ("file".equals(proto)) {
                    roots.add(java.nio.file.Paths.get(url.toURI()));
                } else if ("jar".equals(proto)) {
                    // в jar-режиме (production) сканируем внутри jar
                    collectFromJar(url, path, packageName, result);
                }
            }
            for (java.nio.file.Path root : roots) {
                collectFromFile(root, packageName, result);
            }
        } catch (IOException | java.net.URISyntaxException e) {
            Logger.error("scanPackage failed for " + packageName, e);
        }
        // Сортируем по имени класса для детерминированного порядка
        result.sort(Comparator.comparing(Class::getName));
        return result;
    }

    @SuppressWarnings("unchecked")
    private void collectFromFile(java.nio.file.Path root, String packageName,
                                 List<Class<? extends Module>> result) {
        if (!java.nio.file.Files.exists(root)) return;
        try (Stream<java.nio.file.Path> walk = java.nio.file.Files.walk(root)) {
            walk.filter(p -> p.toString().endsWith(".class"))
                .forEach(p -> {
                    String rel = root.relativize(p).toString()
                            .replace(java.io.File.separatorChar, '.')
                            .replace(".class", "");
                    String fqcn = packageName + "." + rel.split("\\$")[0];
                    tryAddClass(fqcn, result);
                });
        } catch (IOException ignored) {}
    }

    @SuppressWarnings("unchecked")
    private void collectFromJar(java.net.URL jarUrl, String entryPath,
                                String packageName,
                                List<Class<? extends Module>> result) {
        String spec = jarUrl.getFile();
        int bang = spec.indexOf('!');
        if (bang <= 0) return;
        String jarPath = spec.substring(0, bang).replace("file:", "");
        try (java.util.jar.JarFile jar = new java.util.jar.JarFile(jarPath)) {
            java.util.Enumeration<java.util.jar.JarEntry> en = jar.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName();
                if (!n.endsWith(".class")) continue;
                if (!n.startsWith(entryPath + "/")) continue;
                String fqcn = n.replace('/', '.').replace(".class", "");
                // не загружаем inner-классы, которые не должны быть модулями
                if (fqcn.indexOf('$') >= 0) continue;
                tryAddClass(fqcn, result);
            }
        } catch (IOException ignored) {}
    }

    @SuppressWarnings("unchecked")
    private void tryAddClass(String fqcn, List<Class<? extends Module>> result) {
        if (fqcn.contains(".")) {
            String simple = fqcn.substring(fqcn.lastIndexOf('.') + 1);
            if (simple.isEmpty() || simple.startsWith("package-info")) return;
        }
        try {
            Class<?> c = Class.forName(fqcn, false,
                    Thread.currentThread().getContextClassLoader());
            if (c.isInterface()) return;
            if (Modifier.isAbstract(c.getModifiers())) return;
            if (!Module.class.isAssignableFrom(c)) return;
            if (c.getAnnotation(ModuleInfo.class) == null) return;
            result.add((Class<? extends Module>) c);
        } catch (Throwable ignored) {
            // класс мог не загрузиться по причинам иерархии — пропускаем
        }
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        return (T) byType.get(type);
    }

    public Module get(String name) {
        return byName.get(name.toLowerCase());
    }

    public Optional<Module> tryGet(String name) {
        return Optional.ofNullable(byName.get(name.toLowerCase()));
    }

    /**
     * Все модули, отсортированные по приоритету (затем по имени).
     */
    public Collection<Module> all() {
        List<Module> r = new ArrayList<>(byName.values());
        r.sort(Comparator
                .comparingInt((Module m) -> m.priority().weight())
                .thenComparing(Module::getName));
        return Collections.unmodifiableCollection(r);
    }

    public List<Module> enabled() {
        List<Module> r = new ArrayList<>();
        for (Module m : all()) if (m.isEnabled()) r.add(m);
        return r;
    }

    public List<Module> byCategory(Category cat) {
        List<Module> r = new ArrayList<>();
        for (Module m : all()) if (m.getCategory() == cat) r.add(m);
        r.sort(Comparator.comparing(Module::getName));
        return r;
    }

    public int size() {
        return byName.size();
    }

    /** Тик всех включённых модулей. Идёт по приоритету. */
    public void tickAll() {
        for (Module m : all()) {
            if (m.isEnabled()) {
                try { m.onTick(); }
                catch (Throwable t) { Logger.error("onTick " + m.getName(), t); }
            }
        }
    }

    /** Отключает все включённые модули. */
    public void disableAll() {
        for (Module m : new ArrayList<>(byName.values())) {
            if (m.isEnabled()) m.disable();
        }
    }
}
