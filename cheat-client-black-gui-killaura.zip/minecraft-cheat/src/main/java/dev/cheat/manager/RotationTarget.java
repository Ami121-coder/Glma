package dev.cheat.manager;

import java.util.Objects;

/**
 * Цель ротации: куда модуль хочет смотреть и как.
 *
 * <p>Содержит целевые yaw/pitch, приоритет, и флаги поведения:</p>
 * <ul>
 *   <li>{@link #affectMovement} — должна ли эта ротация влиять на
 *       физику движения игрока (для стрейфа)</li>
 *   <li>{@link #affectLooking} — должна ли она влиять на визуальную
 *       камеру (для снапа к цели)</li>
 *   <li>{@link #silent} — silent-ротация: сервер видит, клиент не видит</li>
 * </ul>
 */
public final class RotationTarget {

    public final float    yaw;
    public final float    pitch;
    public final int      priority;          // меньше = выше приоритет
    public final boolean  affectMovement;    // влиять на движение
    public final boolean  affectLooking;     // влиять на камеру клиента
    public final boolean  silent;            // silent (не двигать камеру)
    public final String   owner;             // имя модуля-владельца (для отладки)

    public RotationTarget(float yaw, float pitch, int priority,
                          boolean affectMovement, boolean affectLooking,
                          boolean silent, String owner) {
        this.yaw            = yaw;
        this.pitch          = pitch;
        this.priority       = priority;
        this.affectMovement = affectMovement;
        this.affectLooking  = affectLooking;
        this.silent         = silent;
        this.owner          = owner == null ? "?" : owner;
    }

    /** Быстрый билдер для silent-ротации. */
    public static RotationTarget silent(float yaw, float pitch, int priority, String owner) {
        return new RotationTarget(yaw, pitch, priority, false, false, true, owner);
    }

    /** Быстрый билдер для ротации, влияющей и на движение, и на камеру. */
    public static RotationTarget full(float yaw, float pitch, int priority, String owner) {
        return new RotationTarget(yaw, pitch, priority, true, true, false, owner);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RotationTarget r)) return false;
        return Float.compare(r.yaw, yaw) == 0
                && Float.compare(r.pitch, pitch) == 0
                && priority == r.priority
                && affectMovement == r.affectMovement
                && affectLooking == r.affectLooking
                && silent == r.silent
                && Objects.equals(owner, r.owner);
    }

    @Override
    public int hashCode() {
        return Objects.hash(yaw, pitch, priority, affectMovement, affectLooking, silent, owner);
    }

    @Override
    public String toString() {
        return "RotationTarget{" + owner
                + " y=" + yaw + " p=" + pitch
                + " pri=" + priority
                + (silent ? " silent" : "")
                + (affectMovement ? " mv" : "")
                + (affectLooking ? " look" : "")
                + "}";
    }
}
