package dev.cheat.manager;

import dev.cheat.Client;
import dev.cheat.config.JsonConfig;
import dev.cheat.module.Module;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.Logger;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Менеджер конфигурации.
 *
 * <p>Хранит общую JSON-конфигурацию в {@code .minecraft/cheat/config.json}:</p>
 * <ul>
 *   <li>Состояние модулей (enabled/disabled) + бинды клавиш;</li>
 *   <li>Настройки каждого модуля (имя → значение, через {@link dev.cheat.setting.Setting#serialize()});</li>
 *   <li>Текущая тема оформления;</li>
 *   <li>Список друзей (ссылается на {@link FriendManager}).</li>
 * </ul>
 */
public final class ConfigManager {

    public static final Path CONFIG_DIR = Paths.get("cheat");
    public static final Path MAIN_FILE  = CONFIG_DIR.resolve("config.json");

    private final JsonConfig<ConfigPayload> store =
            new JsonConfig<>(MAIN_FILE, ConfigPayload.class);

    private ConfigPayload data = new ConfigPayload();

    public ConfigPayload data() { return data; }

    public void load() {
        Logger.info("Loading config from " + MAIN_FILE);
        ConfigPayload loaded = store.load();
        if (loaded != null) {
            this.data = loaded;
            Logger.info("Config loaded");
        } else {
            Logger.info("No config found — using defaults");
        }
    }

    public void save() {
        Logger.info("Saving config to " + MAIN_FILE);
        // обновляем снапшот модулей
        data.modules.clear();
        for (Module m : Client.get().moduleManager().all()) {
            ConfigPayload.ModuleEntry e = new ConfigPayload.ModuleEntry();
            e.name    = m.getName();
            e.enabled = m.isEnabled();
            e.bind    = m.getBind();
            // Сохраняем настройки
            if (!m.settings().isEmpty()) {
                e.settings = new HashMap<>(m.settings().serialize());
            }
            data.modules.put(m.getName().toLowerCase(), e);
        }
        // Сохраняем текущую тему
        data.currentTheme = Client.get().theme().name();
        store.save(data);
        Logger.info("Config saved");
    }

    public void applyTo(Client client) {
        // Применяем тему
        Theme t = Theme.byName(data.currentTheme);
        client.setTheme(t);

        for (ConfigPayload.ModuleEntry e : data.modules.values()) {
            Module m = client.moduleManager().get(e.name);
            if (m == null) continue;
            if (e.bind != 0) m.setBind(e.bind);

            // Восстанавливаем настройки
            if (e.settings != null && !e.settings.isEmpty()) {
                m.settings().deserialize(e.settings);
            }

            if (e.enabled && !m.isEnabled()) m.enable();
            else if (!e.enabled && m.isEnabled()) m.disable();
        }
    }
}
