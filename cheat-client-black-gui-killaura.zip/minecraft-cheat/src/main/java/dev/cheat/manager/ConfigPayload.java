package dev.cheat.manager;

import java.util.HashMap;
import java.util.Map;

/**
 * POJO-контейнер сериализуемой конфигурации.
 *
 * <p>Расширяется по мере роста проекта. Каркас хранит:</p>
 * <ul>
 *   <li>общие настройки (тема, версия схемы);</li>
 *   <li>состояние и бинды модулей;</li>
 *   <li>настройки каждого модуля (имя → значение).</li>
 * </ul>
 */
public final class ConfigPayload {

    /** Общая версия схемы конфига. */
    public int version = 1;

    public String currentTheme = "default";

    public Map<String, ModuleEntry> modules = new HashMap<>();

    public static final class ModuleEntry {
        public String  name;
        public boolean enabled;
        public int     bind;
        /** Настройки модуля: имя настройки → JSON-значение. */
        public Map<String, Object> settings = new HashMap<>();
    }
}
