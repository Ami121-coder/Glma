package dev.cheat.manager;

import dev.cheat.util.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Менеджер друзей.
 *
 * <p>Друзья хранятся в {@code cheat/friends.txt} построчно:
 * {@code name=alias}. Используется combat/ESP-модулями.</p>
 */
public final class FriendManager {

    public static final Path FILE = Paths.get("cheat", "friends.txt");

    private final Map<String, String> friends = new LinkedHashMap<>();

    public boolean add(String name)        { return add(name, name); }
    public boolean add(String name, String alias) {
        friends.put(name.toLowerCase(), alias);
        save();
        Logger.info("Friend added: " + name);
        return true;
    }

    public boolean remove(String name) {
        boolean r = friends.remove(name.toLowerCase()) != null;
        if (r) save();
        return r;
    }

    public boolean isFriend(String name) {
        return name != null && friends.containsKey(name.toLowerCase());
    }

    public String aliasOf(String name) {
        return friends.get(name.toLowerCase());
    }

    public Set<String> names() {
        return Collections.unmodifiableSet(friends.keySet());
    }

    public int size() { return friends.size(); }

    public void clear() {
        friends.clear();
        save();
    }

    public void load() {
        if (!Files.exists(FILE)) return;
        try {
            for (String line : Files.readAllLines(FILE)) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split("=", 2);
                if (parts.length == 2) friends.put(parts[0].toLowerCase(), parts[1]);
                else                   friends.put(parts[0].toLowerCase(), parts[0]);
            }
            Logger.info("Friends loaded: " + friends.size());
        } catch (IOException e) {
            Logger.error("Cannot load friends", e);
        }
    }

    public void save() {
        try {
            if (FILE.getParent() != null) Files.createDirectories(FILE.getParent());
            StringBuilder sb = new StringBuilder("# Cheat friends file\n");
            for (Map.Entry<String, String> e : friends.entrySet()) {
                sb.append(e.getKey()).append('=').append(e.getValue()).append('\n');
            }
            Files.writeString(FILE, sb.toString());
        } catch (IOException e) {
            Logger.error("Cannot save friends", e);
        }
    }
}
