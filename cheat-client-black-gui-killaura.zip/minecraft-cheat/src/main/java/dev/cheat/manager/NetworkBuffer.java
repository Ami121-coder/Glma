package dev.cheat.manager;

import dev.cheat.Client;
import dev.cheat.util.Logger;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.function.Predicate;

/**
 * Сетевой буфер — для отложенной отправки и batching'а пакетов.
 *
 * <p>Используется для:</p>
 * <ul>
 *   <li><b>Blink / Packet-Glitch</b>: накапливать пакеты, не отправляя их,
 *       потом резко «выплюнуть» всё разом (например, для позиционных пакетов
 *       при телепорте).</li>
 *   <li><b>Batching</b>: группировать пакеты одного типа и отправлять
 *       их в конце тика, чтобы сервер не увидел внутренних перестановок.</li>
 *   <li><b>Replay</b>: откатить отправку — например, при RubberBand.</li>
 * </ul>
 *
 * <p><b>API:</b></p>
 * <ul>
 *   <li>{@link #enqueue(Packet)} — добавить в очередь</li>
 *   <li>{@link #flush()} — отправить все накопленные пакеты</li>
 *   <li>{@link #clear()} — выбросить все пакеты из очереди</li>
 *   <li>{@link #setPaused(boolean)} — пауза: новые enqueue НЕ идут в сеть</li>
 *   <li>{@link #isPaused()} — статус паузы</li>
 * </ul>
 *
 * <p><b>Важно:</b> По умолчанию буфер НЕ влияет на обычный send. Только когда
 * модуль явно ставит паузу или {@link PacketManager} возвращает
 * {@link PacketRule.Action#BUFFER}, пакеты попадают сюда.</p>
 */
public final class NetworkBuffer {

    /** Элемент очереди с временем постановки (для отладки/таймаутов). */
    private record QueuedPacket(Packet<?> packet, long enqueuedAt) {}

    private final Deque<QueuedPacket> queue = new ConcurrentLinkedDeque<>();

    /** Пауза — если true, enqueue копит пакеты и не flush'ит их автоматически. */
    private volatile boolean paused = false;

    /** Кол-во пакетов в очереди. */
    public int size() {
        return queue.size();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public boolean isPaused() {
        return paused;
    }

    /** Включить/выключить паузу. При выключении — авт flush. */
    public void setPaused(boolean paused) {
        boolean wasPaused = this.paused;
        this.paused = paused;
        if (wasPaused && !paused) {
            // Сняли паузу — отправляем накопленное
            flush();
        }
        Logger.info("NetworkBuffer: paused=" + paused + " (queue=" + queue.size() + ")");
    }

    // ─── Управление очередью ──────────────────────────────────

    /** Поставить пакет в очередь. Если пауза выключена — отправится сразу. */
    public void enqueue(Packet<?> packet) {
        if (packet == null) return;
        queue.addLast(new QueuedPacket(packet, System.currentTimeMillis()));

        if (!paused) {
            flush();
        }
    }

    /** Поставить пакет в начало очереди (следующим к отправке). */
    public void enqueueFirst(Packet<?> packet) {
        if (packet == null) return;
        queue.addFirst(new QueuedPacket(packet, System.currentTimeMillis()));

        if (!paused) {
            flush();
        }
    }

    /**
     * Отправить все накопленные пакеты через текущий connection.
     * Возвращает количество отправленных пакетов.
     */
    public int flush() {
        if (queue.isEmpty()) return 0;
        ClientConnection conn = connection();
        if (conn == null) {
            Logger.warn("NetworkBuffer.flush: no connection, queue=" + queue.size());
            return 0;
        }

        int sent = 0;
        QueuedPacket qp;
        while ((qp = queue.pollFirst()) != null) {
            try {
                // ВАЖНО: обходим PacketManager, иначе зациклимся.
                conn.send(qp.packet);
                sent++;
            } catch (Throwable t) {
                Logger.error("NetworkBuffer.flush: send failed", t);
                // Вернуть пакет в начало очереди при ошибке
                queue.addFirst(qp);
                break;
            }
        }
        return sent;
    }

    /** Выбросить все пакеты из очереди (без отправки). */
    public int clear() {
        int s = queue.size();
        queue.clear();
        Logger.info("NetworkBuffer: cleared " + s + " packets");
        return s;
    }

    /** Снять с очереди и выбросить все пакеты, удовлетворяющие фильтру. */
    public int removeIf(Predicate<Packet<?>> filter) {
        int before = queue.size();
        queue.removeIf(qp -> filter.test(qp.packet));
        return before - queue.size();
    }

    /** Возвращает (копию) всех пакетов в очереди — для инспекции. */
    public java.util.List<Packet<?>> snapshot() {
        java.util.List<Packet<?>> r = new java.util.ArrayList<>(queue.size());
        for (QueuedPacket qp : queue) r.add(qp.packet);
        return r;
    }

    // ─── Внутреннее ───────────────────────────────────────────

    private ClientConnection connection() {
        if (Client.get() == null) return null;
        var mc = Client.get().mc();
        if (mc == null || mc.getNetworkHandler() == null) return null;
        return mc.getNetworkHandler().getConnection();
    }
}
