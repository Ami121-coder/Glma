package dev.cheat.manager;

import dev.cheat.event.listener.EventListener;
import net.minecraft.network.packet.Packet;

import java.util.function.Predicate;

/**
 * Правило перехвата пакетов для {@link PacketManager}.
 *
 * <p>Каждое правило — это фильтр + действие. Применяется в порядке priority.</p>
 *
 * <p>Действия, которые может вернуть {@link Action}:</p>
 * <ul>
 *   <li>{@link Type#PASS} — пропустить, дать шанс другим правилам</li>
 *   <li>{@link Type#ALLOW} — пропустить и остановить дальнейшую проверку</li>
 *   <li>{@link Type#DENY} — отменить отправку/приём пакета</li>
 *   <li>{@link Type#REPLACE} — заменить пакет на {@code replacement}</li>
 *   <li>{@link Type#BUFFER} — отложить в {@link dev.cheat.manager.NetworkBuffer}</li>
 * </ul>
 */
@FunctionalInterface
public interface PacketRule extends EventListener {

    /**
     * Вызывается для каждого пакета, подходящего под {@link #filter()}.
     *
     * @param packet текущий пакет (можно прочитать, нельзя мутировать)
     * @param direction {@code OUT} для отправки, {@code IN} для приёма
     * @return действие менеджера
     */
    Action handle(Packet<?> packet, Direction direction);

    /** Фильтр: для каких пакетов вызывать {@link #handle}. */
    default Predicate<Packet<?>> filter() {
        return p -> true;
    }

    /** Приоритет (меньше = раньше). */
    default int priority() {
        return 100;
    }

    /** Имя-владелец правила (для отладки и снятия). */
    default String owner() {
        return getClass().getSimpleName();
    }

    /** Действие правила. */
    final class Action {
        public final Type type;
        public final Packet<?> replacement;

        private Action(Type type, Packet<?> replacement) {
            this.type        = type;
            this.replacement = replacement;
        }

        public static Action pass()              { return new Action(Type.PASS,    null); }
        public static Action allow()             { return new Action(Type.ALLOW,   null); }
        public static Action deny()              { return new Action(Type.DENY,    null); }
        public static Action replace(Packet<?> p){ return new Action(Type.REPLACE, p);    }
        public static Action buffer()            { return new Action(Type.BUFFER,  null); }
    }

    enum Type { PASS, ALLOW, DENY, REPLACE, BUFFER }

    enum Direction { IN, OUT }
}
