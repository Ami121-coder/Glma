package dev.cheat.core;

import dev.cheat.Client;
import dev.cheat.CheatClient;
import dev.cheat.util.CombatState;
import dev.cheat.util.KillAuraDebug;
import dev.cheat.util.Logger;
import net.minecraft.client.MinecraftClient;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Оркестратор инициализации.
 *
 * <p>Отвечает за строгий порядок старта подсистем клиента:
 * <pre>
 *   1) Logger
 *   2) Client singleton
 *   3) ConfigManager.load()
 *   4) ModuleManager.registerDefaults()  (пусто — модули добавляются в подклассах)
 *   5) CommandManager.registerDefaults()
 *   6) Client.markRunning()
 * </pre>
 *
 * <p>Точка входа {@link CheatClient#onInitializeClient()} вызывает {@link #bootstrap()}.</p>
 */
public final class Core {

    private static final AtomicBoolean INITIALIZED = new AtomicBoolean(false);

    private Core() {}

    public static boolean isInitialized() {
        return INITIALIZED.get();
    }

    public static void bootstrap() {
        if (!INITIALIZED.compareAndSet(false, true)) {
            Logger.warn("Core.bootstrap() called twice — skipping");
            return;
        }

        Logger.info("==============================================");
        Logger.info("  " + CheatClient.MOD_NAME + " v" + CheatClient.VERSION);
        Logger.info("  Minecraft 1.21.4 / Fabric Loader");
        Logger.info("==============================================");

        try {
            // 1. Singleton клиента (внутри создает все менеджеры)
            //    ВАЖНО: менеджеры НЕ подписываются на события в своих конструкторах,
            //    потому что Client.get() в этот момент ещё бросает исключение.
            //    Подписка выполняется явно ниже, после Client.create().
            Client.create(MinecraftClient.getInstance());

            Client client = Client.get();

            // 1b. Подписываем менеджеры на события — теперь, когда Client создан.
            client.animationManager().subscribeSelf();
            client.packetManager().subscribeSelf();
            client.rotationManager().subscribeSelf();

            // 1c. Инициализируем CombatState (детектор кнокбэка) и KillAuraDebug.
            //     CombatState подписывается на PacketReceiveEvent и ClientTickEvent.
            //     KillAuraDebug открывает файл cheat/logs/killaura.log.
            KillAuraDebug.init();
            CombatState.getInstance().subscribeSelf();

            // 2. Чтение конфигурации с диска
            client.configManager().load();

            // 3. Регистрация модулей — автообнаружение в dev.cheat.module.impl
            //    + любые вручную-зарегистрированные до этого.
            client.moduleManager().registerDefaults();
            Logger.info("Modules loaded: " + client.moduleManager().size());

            // 4. Регистрация встроенных команд
            //    (.help, .toggle, .bind, .config, .friend, .set, .modules, .theme)
            client.commandManager().registerDefaults();

            // 4b. Загрузка друзей
            client.friendManager().load();

            // 5. Применяем загруженную конфигурацию (бины, состояние)
            client.configManager().applyTo(client);

            // 6. Сигнализируем готовность
            client.markRunning();

            Logger.info("Bootstrap complete — client running");
        } catch (Throwable t) {
            Logger.error("FATAL: bootstrap failed", t);
            throw new RuntimeException(t);
        }
    }

    /** Завершение работы — сохранение конфигов. Вызывается из Shutdown hook / mixin. */
    public static void shutdown() {
        if (!INITIALIZED.get()) return;
        try {
            Client client = Client.get();
            client.configManager().save();
            // Закрываем дебаг-лог KillAura
            KillAuraDebug.close();
            Logger.info("Shutdown complete");
        } catch (Throwable t) {
            Logger.error("Shutdown error", t);
        }
    }
}
