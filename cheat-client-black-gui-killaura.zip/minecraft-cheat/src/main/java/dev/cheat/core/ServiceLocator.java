package dev.cheat.core;

import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Лёгкий локатор сервисов.
 *
 * <p>Используется для опциональных подсистем, которые не должны быть
 * жёстко завязаны на {@link dev.cheat.Client} — например, рендер-провайдеры,
 * маппинги, IC2-интеграции. Сейчас каркас использует его минимально,
 * но оставлен как точка расширения.</p>
 *
 * <p>Регистрация: {@code ServiceLocator.register(MyService.class, instance)}<br>
 * Запрос:       {@code ServiceLocator.get(MyService.class)}</p>
 */
public final class ServiceLocator {

    private static final ConcurrentMap<Class<?>, Object> SERVICES = new ConcurrentHashMap<>();

    private ServiceLocator() {}

    public static <T> void register(Class<T> type, T instance) {
        Objects.requireNonNull(type,    "type");
        Objects.requireNonNull(instance,"instance");
        SERVICES.put(type, instance);
    }

    @SuppressWarnings("unchecked")
    public static <T> T get(Class<T> type) {
        return (T) SERVICES.get(type);
    }

    public static <T> T getOrDefault(Class<T> type, T def) {
        T t = get(type);
        return t == null ? def : t;
    }

    public static void unregister(Class<?> type) {
        SERVICES.remove(type);
    }

    public static void clear() {
        SERVICES.clear();
    }
}
