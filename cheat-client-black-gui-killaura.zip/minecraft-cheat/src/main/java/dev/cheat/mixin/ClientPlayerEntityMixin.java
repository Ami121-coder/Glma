package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.MotionEvent;
import dev.cheat.event.impl.MotionUpdateEvent;
import dev.cheat.event.impl.PlayerTickEvent;
import dev.cheat.util.Logger;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link ClientPlayerEntity}.
 *
 * <p>Перехватывает:</p>
 * <ul>
 *   <li>{@code tick()} HEAD/RETURN → {@link PlayerTickEvent}</li>
 *   <li>{@code sendMovementPackets()} HEAD/RETURN → {@link MotionUpdateEvent}
 *       + {@link MotionEvent}(PRE) до формирования пакетов,
 *       {@link MotionEvent}(POST) после — для restore визуальных ротаций.</li>
 * </ul>
 *
 * <p><b>Motion-поток (детально):</b></p>
 * <ol>
 *   <li>Ванильный {@code sendMovementPackets()} готовит значения из
 *       {@code player.getX/Y/Z, getYaw, getPitch, isOnGround}.</li>
 *   <li>HEAD mixin публикует {@link MotionUpdateEvent}(PRE) →
 *       RotationManager фиксирует лучшую цель.</li>
 *   <li>HEAD mixin публикует {@link MotionEvent}(PRE) с текущими значениями →
 *       RotationManager подменяет yaw/pitch в событии.</li>
 *   <li>Применяем подменённые значения обратно на {@code player} (чтобы
 *       ванильный {@code sendMovementPackets()} отправил их в пакете).</li>
 *   <li>Ванильный код отправляет пакет с правильными ротациями.</li>
 *   <li>RETURN mixin публикует {@link MotionEvent}(POST) → RotationManager
 *       восстанавливает визуальные ротации (если silent).</li>
 *   <li>RETURN mixin публикует {@link MotionUpdateEvent}(POST) →
 *       сброс одноразовых целей.</li>
 * </ol>
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void cheat$onPlayerTickStart(CallbackInfo ci) {
        if (Client.tryGet() == null) return;
        try {
            ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
            Client.get().eventManager().post(new PlayerTickEvent(PlayerTickEvent.Phase.PRE, self));
        } catch (Throwable ignored) {}
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void cheat$onPlayerTickEnd(CallbackInfo ci) {
        if (Client.tryGet() == null) return;
        try {
            ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
            Client.get().eventManager().post(new PlayerTickEvent(PlayerTickEvent.Phase.POST, self));
        } catch (Throwable ignored) {}
    }

    /**
     * PRE-sendMovementPackets: MotionUpdateEvent(PRE) + MotionEvent(PRE).
     *
     * <p>Здесь мы:</p>
     * <ol>
     *   <li>Публикуем MotionUpdateEvent(PRE) — RotationManager выбирает цель.</li>
     *   <li>Создаём MotionEvent с текущими значениями player и публикуем PRE.</li>
     *   <li>Если событие отменено — отменяем весь sendMovementPackets
     *       (модуль сам отправит пакет через PacketManager).</li>
     *   <li>Если в PRE были изменены yaw/pitch — применяем их на player
     *       до того, как ванильный код сформирует пакет.</li>
     * </ol>
     */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void cheat$preMotion(CallbackInfo ci) {
        if (Client.tryGet() == null) return;
        try {
            ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;

            // 1. Уведомляем об обновлении motion (PRE)
            Client.get().eventManager().post(new MotionUpdateEvent(MotionUpdateEvent.Phase.PRE, self));

            // 2. Создаём MotionEvent PRE с текущими значениями
            MotionEvent ev = new MotionEvent(
                    MotionEvent.Phase.PRE, self,
                    self.getX(), self.getY(), self.getZ(),
                    self.getYaw(), self.getPitch(),
                    self.isOnGround(), self.horizontalCollision);

            Client.get().eventManager().post(ev);

            // 3. Отмена — модуль сам отправит пакет
            if (ev.isCancelled()) {
                ci.cancel();
                // Всё равно POST для cleanup
                Client.get().eventManager().post(new MotionUpdateEvent(MotionUpdateEvent.Phase.POST, self));
                return;
            }

            // 4. Применяем подмены на player, чтобы ванильный код отправил их
            if (ev.modifyRotation) {
                self.setYaw(ev.yaw);
                self.setPitch(ev.pitch);
            }
            if (ev.modifyPosition) {
                // Позицию подменять опасно — это смещает сам игрок.
                // Используем refreshPositionAfterTeleport, если нужно.
                // Каркас оставляет это как TODO для movement-модулей.
            }
            if (ev.modifyOnGround) {
                // onGround сеттер у Entity — публичный
                self.setOnGround(ev.onGround);
            }
        } catch (Throwable t) {
            Logger.error("preMotion error", t);
        }
    }

    /**
     * POST-sendMovementPackets: MotionEvent(POST) + MotionUpdateEvent(POST).
     *
     * <p>Здесь RotationManager восстанавливает визуальные ротации (silent),
     * а цели снимаются до следующего тика.</p>
     */
    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void cheat$postMotion(CallbackInfo ci) {
        if (Client.tryGet() == null) return;
        try {
            ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;

            // MotionEvent(POST): restore visual rotations
            MotionEvent post = new MotionEvent(
                    MotionEvent.Phase.POST, self,
                    self.getX(), self.getY(), self.getZ(),
                    self.getYaw(), self.getPitch(),
                    self.isOnGround(), self.horizontalCollision);
            Client.get().eventManager().post(post);

            // MotionUpdateEvent(POST): cleanup одноразовых целей
            Client.get().eventManager().post(new MotionUpdateEvent(MotionUpdateEvent.Phase.POST, self));
        } catch (Throwable t) {
            Logger.error("postMotion error", t);
        }
    }
}
