package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.Render3DEvent;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link WorldRenderer} — публикует {@link Render3DEvent} после
 * отрисовки мира. Даёт модулям доступ к {@link MatrixStack} и камере.
 *
 * <p>Подход: на RETURN из {@code render()} строим новую {@link MatrixStack},
 * транслируем её на {@code -camera.getPos()}, и публикуем событие. Этого
 * достаточно, чтобы модули могли рисовать боксы/линии в координатах мира.</p>
 *
 * <p>Внимание: в 1.21.4 ванильный {@code WorldRenderer.render()} уже
 * сфлушил все буферы к этому моменту — наш рендер пойдёт поверх
 * через {@code VertexConsumerProvider.Immediate} из
 * {@code mc.getBufferBuilders().getEntityVertexConsumers()}.</p>
 */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {

    @Inject(
        method = "render",
        at = @At("RETURN")
    )
    private void cheat$afterRender(ObjectAllocator allocator,
                                   RenderTickCounter tickCounter,
                                   boolean renderBlockOutline,
                                   Camera camera,
                                   GameRenderer gameRenderer,
                                   Matrix4f positionMatrix,
                                   Matrix4f projectionMatrix,
                                   CallbackInfo ci) {
        if (Client.tryGet() == null) return;
        try {
            // Пропускаем если клиент не в игре
            if (Client.get().mc().world == null || Client.get().mc().getCameraEntity() == null) return;

            MatrixStack matrices = new MatrixStack();
            Vec3d cam = camera.getPos();
            matrices.translate(-cam.x, -cam.y, -cam.z);

            float delta = tickCounter.getTickDelta(false);
            Client.get().eventManager().post(new Render3DEvent(
                    matrices, delta, cam.x, cam.y, cam.z));
        } catch (Throwable ignored) {
            // Никогда не роняем ванильный рендер
        }
    }
}
