package dev.cheat.mixin;

import dev.cheat.manager.CommandDispatcher;
import dev.cheat.util.Logger;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link ClientPlayNetworkHandler}.
 *
 * <p>Перехватывает {@code sendChatMessage(String)} для диспетчера команд
 * {@link CommandDispatcher}. Если строка начинается с '.', она не уходит
 * на сервер.</p>
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void cheat$onSendChatMessage(String content, CallbackInfo ci) {
        try {
            CommandDispatcher dispatcher = CommandDispatcher.current();
            if (dispatcher != null && dispatcher.tryHandle(content)) {
                ci.cancel();
            }
        } catch (Throwable t) {
            Logger.error("Chat intercept error", t);
        }
    }
}
