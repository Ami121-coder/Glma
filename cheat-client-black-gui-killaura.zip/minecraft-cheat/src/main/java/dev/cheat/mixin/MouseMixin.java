package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.MouseEvent;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link Mouse}.
 *
 * <p>Публикует {@link MouseEvent} при любом нажатии/отпускании кнопки мыши.
 * Если событие отменено — родной обработчик Minecraft не получит клик,
 * что позволяет реализовывать auto-clicker, anti-mis-click и т.п.</p>
 */
@Mixin(Mouse.class)
public abstract class MouseMixin {

    @Shadow public abstract double getX();
    @Shadow public abstract double getY();

    @Inject(method = "onMouseButton",
            at = @At("HEAD"),
            cancellable = true)
    private void cheat$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (Client.tryGet() == null) return;

        // Игнорируем клики не в окне игры
        long handle = Client.get().mc().getWindow().getHandle();
        if (window != handle) return;

        MouseEvent event = new MouseEvent(button, action, mods, getX(), getY());
        Client.get().eventManager().post(event);
        if (event.isCancelled()) ci.cancel();
    }
}
