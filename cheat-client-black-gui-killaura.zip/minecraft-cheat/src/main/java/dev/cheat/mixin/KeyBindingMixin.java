package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.util.Logger;
import net.minecraft.client.option.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin в {@link KeyBinding}.
 *
 * <p>Перехватывает {@code isPressed()} — позволяет модулям движения
 * (AutoWalk, Sneak) эмулировать нажатие клавиш.</p>
 *
 * <p>Каркас оставляет точку расширения; реальная логика появится вместе
 * с модулем-классом (например, через {@code KeyBindingManager}).</p>
 */
@Mixin(KeyBinding.class)
public abstract class KeyBindingMixin {

    @Inject(method = "isPressed", at = @At("RETURN"), cancellable = true)
    private void cheat$onIsPressed(CallbackInfoReturnable<Boolean> cir) {
        // Заглушка архитектуры: разработчик добавит перехват
        // (например, для искусственного нажатия Movement-модулями).
        // Client.get() не проверяем — метод вызывается очень часто.
        if (cir.getReturnValueZ() || Client.tryGet() == null) return;
        // Future: if (KeyBindingManager.isForced((KeyBinding)(Object)this)) cir.setReturnValue(true);
    }
}
