package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.KeyEvent;
import net.minecraft.client.Keyboard;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link Keyboard}.
 *
 * <p>Триггерит {@link KeyEvent} на каждое нажатие. Если событие отменено —
 * родной обработчик Minecraft не получит клавишу.</p>
 *
 * <p>Также здесь каркас проверяет «горячие клавиши» модулей
 * (bind через {@code Client.moduleManager()}).</p>
 */
@Mixin(Keyboard.class)
public abstract class KeyboardMixin {

    @Inject(method = "onKey",
            at = @At("HEAD"),
            cancellable = true)
    private void cheat$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (Client.tryGet() == null) return;
        try {
            KeyEvent event = new KeyEvent(key, scancode, action, modifiers);
            Client.get().eventManager().post(event);

            // Бинд модулей: только на PRESS (не REPEAT/RELEASE)
            if (event.isPressed() && key != GLFW.GLFW_KEY_UNKNOWN) {
                for (dev.cheat.module.Module m : Client.get().moduleManager().all()) {
                    if (m.getBind() == key) {
                        m.toggle();
                    }
                }
            }

            if (event.isCancelled()) ci.cancel();
        } catch (Throwable ignored) {}
    }
}
