package dev.cheat.util;

/**
 * Цветовые утилиты 2.0: ARGB, HSL, RGBA-компоненты, alpha-блендинг,
 * градиенты, радужные переливания.
 *
 * <p>Цвета в Minecraft — это packed ARGB int, где старший байт = alpha.
 * Все методы здесь возвращают именно такой int, если не оговорено иное.</p>
 */
public final class ColorUtil {

    private ColorUtil() {}

    // ─── Pack / unpack ─────────────────────────────────────────

    public static int rgb(int r, int g, int b) {
        return rgb(r, g, b, 255);
    }

    public static int rgb(int r, int g, int b, int a) {
        return (a & 0xFF) << 24
             | (r & 0xFF) << 16
             | (g & 0xFF) << 8
             | (b & 0xFF);
    }

    public static int rgb(float r, float g, float b, float a) {
        return rgb(
                Math.round(r * 255f),
                Math.round(g * 255f),
                Math.round(b * 255f),
                Math.round(a * 255f));
    }

    public static int alpha(int color, int newAlpha) {
        return (newAlpha & 0xFF) << 24 | (color & 0x00FFFFFF);
    }

    public static int alpha(int color, float newAlpha) {
        return alpha(color, Math.round(newAlpha * 255f));
    }

    public static int red  (int c) { return (c >> 16) & 0xFF; }
    public static int green(int c) { return (c >>  8) & 0xFF; }
    public static int blue (int c) { return  c        & 0xFF; }
    public static int alpha(int c) { return (c >> 24) & 0xFF; }

    public static float rf(int c) { return red  (c) / 255f; }
    public static float gf(int c) { return green(c) / 255f; }
    public static float bf(int c) { return blue (c) / 255f; }
    public static float af(int c) { return alpha(c) / 255f; }

    // ─── HSL / HSB ────────────────────────────────────────────

    /**
     * HSL → RGB.
     * @param h 0..360
     * @param s 0..1
     * @param l 0..1
     */
    public static int hslToRgb(float h, float s, float l) {
        float c = (1 - Math.abs(2 * l - 1)) * s;
        float x = c * (1 - Math.abs(((h / 60f) % 2) - 1));
        float m = l - c / 2;
        float r, g, b;
        if (h < 60)       { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else              { r = c; g = 0; b = x; }
        return rgb(
                Math.round((r + m) * 255),
                Math.round((g + m) * 255),
                Math.round((b + m) * 255));
    }

    /** HSB → RGB (HSB=HSV; обычно даёт более насыщенные цвета, чем HSL). */
    public static int hsbToRgb(float h, float s, float v) {
        int i = (int) (h * 6f);
        float f = h * 6f - i;
        float p = v * (1 - s);
        float q = v * (1 - f * s);
        float t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0: r=v; g=t; b=p; break;
            case 1: r=q; g=v; b=p; break;
            case 2: r=p; g=v; b=t; break;
            case 3: r=p; g=q; b=v; break;
            case 4: r=t; g=p; b=v; break;
            default:r=v; g=p; b=q; break;
        }
        return rgb(Math.round(r*255), Math.round(g*255), Math.round(b*255));
    }

    public static int rgbToHsb(int c) {
        // возвращает packed: h*65536 + s*256 + b
        int r = red(c), g = green(c), b = blue(c);
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h = 0;
        if (d != 0) {
            if (max == r)      h = ((g - b) / d) % 6;
            else if (max == g) h = (b - r) / d + 2;
            else               h = (r - g) / d + 4;
            h *= 60f;
            if (h < 0) h += 360f;
        }
        float s = max == 0 ? 0 : d / max;
        return Math.round(h) << 16 | Math.round(s * 255) << 8 | Math.round(max / 255f * 255);
    }

    // ─── Rainbow / dynamic colors ─────────────────────────────

    /** Радужный цвет по времени. */
    public static int rainbow(long offsetMs, float alpha) {
        float h = ((System.currentTimeMillis() + offsetMs) % 6000L) / 6000f * 360f;
        int rgb = hslToRgb(h, 1f, 0.5f);
        return alpha(rgb, Math.round(alpha * 255));
    }

    /** Радужный с настраиваемой насыщенностью/яркостью. */
    public static int rainbow(long offsetMs, float s, float l, float alpha) {
        float h = ((System.currentTimeMillis() + offsetMs) % 6000L) / 6000f * 360f;
        int rgb = hslToRgb(h, s, l);
        return alpha(rgb, Math.round(alpha * 255));
    }

    /** Цвет, плавно блуждающий между двумя оттенками по синусоиде. */
    public static int breathe(int a, int b, long periodMs, float alpha) {
        float t = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / (double) periodMs * Math.PI * 2));
        return lerp(a, b, t, alpha);
    }

    // ─── Interpolation ────────────────────────────────────────

    public static int lerp(int a, int b, float t) {
        return lerp(a, b, t, 1f);
    }

    public static int lerp(int a, int b, float t, float outAlpha) {
        int r = Math.round(MathUtil.lerp(red(a),   red(b),   t));
        int g = Math.round(MathUtil.lerp(green(a), green(b), t));
        int bl= Math.round(MathUtil.lerp(blue(a),  blue(b),  t));
        int al= Math.round(MathUtil.lerp(alpha(a), alpha(b), t) * MathUtil.clamp(outAlpha, 0, 1));
        return rgb(r, g, bl, al);
    }

    /** Линейный градиент: t∈[0,1] между colorA и colorB. */
    public static int gradient(int colorA, int colorB, float t) {
        return lerp(colorA, colorB, MathUtil.clamp(t, 0, 1));
    }

    /** Многоточечный градиент: stops — упорядоченный массив пар (t, color). */
    public static int multiGradient(float t, int... stops) {
        if (stops == null || stops.length == 0) return 0xFFFFFFFF;
        if (stops.length == 1) return stops[0];
        // Сегмент - это последовательность пар (t, color) → для простоты принимаем
        // равномерно распределённые точки цвета, t∈[0,1].
        t = MathUtil.clamp(t, 0, 1);
        float seg = 1f / (stops.length - 1);
        int i = Math.min(stops.length - 2, (int) (t / seg));
        float local = (t - i * seg) / seg;
        return lerp(stops[i], stops[i + 1], local);
    }

    // ─── Blend / modify ───────────────────────────────────────

    /** Затемнить цвет на factor (0=оригинал, 1=чёрный). */
    public static int darken(int c, float factor) {
        factor = MathUtil.clamp(factor, 0, 1);
        return rgb(
                Math.round(red  (c) * (1 - factor)),
                Math.round(green(c) * (1 - factor)),
                Math.round(blue (c) * (1 - factor)),
                alpha(c));
    }

    /** Осветлить цвет на factor (0=оригинал, 1=белый). */
    public static int lighten(int c, float factor) {
        factor = MathUtil.clamp(factor, 0, 1);
        return rgb(
                Math.round(red  (c) + (255 - red  (c)) * factor),
                Math.round(green(c) + (255 - green(c)) * factor),
                Math.round(blue (c) + (255 - blue (c)) * factor),
                alpha(c));
    }

    /** Инвертировать RGB-каналы, alpha оставить. */
    public static int invert(int c) {
        return rgb(255 - red(c), 255 - green(c), 255 - blue(c), alpha(c));
    }

    /** Alpha-blend front over back по формуле porter-duff source-over. */
    public static int blendOver(int back, int front) {
        float fa = af(front);
        float ba = af(back);
        float outA = fa + ba * (1 - fa);
        if (outA <= 0.0001f) return 0;
        int r = Math.round((rf(front) * fa + rf(back) * ba * (1 - fa)) / outA * 255f);
        int g = Math.round((gf(front) * fa + gf(back) * ba * (1 - fa)) / outA * 255f);
        int b = Math.round((bf(front) * fa + bf(back) * ba * (1 - fa)) / outA * 255f);
        return rgb(r, g, b, Math.round(outA * 255f));
    }

    /** Превратить int-color в массив float[4] = {r,g,b,a} (для шейдеров). */
    public static float[] toFloats(int c) {
        return new float[]{ rf(c), gf(c), bf(c), af(c) };
    }

    /** Hex-строка {@code #RRGGBB} или {@code #AARRGGBB} → int. */
    public static int fromHex(String hex) {
        if (hex == null) return 0xFFFFFFFF;
        hex = hex.trim();
        if (hex.startsWith("#")) hex = hex.substring(1);
        if (hex.length() == 6) hex = "FF" + hex;
        if (hex.length() != 8) return 0xFFFFFFFF;
        try {
            return (int) Long.parseLong(hex, 16);
        } catch (NumberFormatException e) {
            return 0xFFFFFFFF;
        }
    }

    public static String toHex(int c) {
        return String.format("#%08X", c);
    }
}
