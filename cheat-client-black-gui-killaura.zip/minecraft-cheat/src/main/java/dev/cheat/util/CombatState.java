package dev.cheat.util;

import dev.cheat.Client;
import dev.cheat.event.listener.EventHandler;
import dev.cheat.event.listener.EventListener;
import dev.cheat.event.impl.PacketReceiveEvent;
import dev.cheat.event.impl.ClientTickEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import net.minecraft.util.math.Vec3d;

import java.util.Set;

/**
 * Состояние боя: детектор кнокбэка, хёрта и движения игрока.
 *
 * <p><b>v3 — исправление ложных RUBBERBAND'ов:</b></p>
 *
 * <p>В предыдущей версии каждый {@code PlayerPositionLookS2CPacket} считался
 * rubberband'ом. Но этот пакет сервер шлёт в множестве ситуаций:</p>
 * <ul>
 *   <li>Реальный rubberband (когда сервер возвращает игрока на позицию)</li>
 *   <li>Teleport при респауне/смене мира</li>
 *   <li>Mount/dismount</li>
 *   <li>Серверные rotation-only sync'и (когда relatives содержит X/Y/Z)</li>
 *   <li>Нормальный teleport в lobby</li>
 * </ul>
 *
 * <p><b>Текущая стратегия:</b> различаем real rubberband от teleport/sync
 * по дистанции позиции и флагам relatives:</p>
 *
 * <ol>
 *   <li><b>Real rubberband:</b> позиция отличается от текущей на 0.5..10 блоков,
 *       relatives НЕ содержит X/Y/Z (абсолютные координаты).</li>
 *
 *   <li><b>Teleport (респаун):</b> позиция отличается &gt; 10 блоков — НЕ паузим,
 *       это нормальный teleport.</li>
 *
 *   <li><b>Rotation-only sync:</b> relatives содержит X/Y/Z — НЕ паузим,
 *       это синхронизация rotation, не позиции.</li>
 * </ol>
 *
 * <p><b>Дополнительно:</b></p>
 * <ul>
 *   <li><b>Exponential backoff:</b> если RUBBERBAND'ы приходят подряд, каждый
 *       следующий увеличивает паузу на 5 тиков (макс 40). Это позволяет
 *       серверу успокоиться, если он настойчиво пытается нас исправить.</li>
 *
 *   <li><b>Knockback pause:</b> 10 тиков по умолчанию. Если в течение паузы
 *       приходит новый кнокбэк — продлеваем.</li>
 *
 *   <li><b>Velocity-jump эвристика:</b> OFF по умолчанию (ловит прыжки).
 *       Только packet-based детекция надёжна.</li>
 *
 *   <li><b>hurtTime:</b> OFF по умолчанию (ванила сама блокирует первые 4 тика).</li>
 * </ul>
 */
public final class CombatState implements EventListener {

    /** Дефолтные значения паузы (можно переопределить из модуля). */
    public static int DEFAULT_KNOCKBACK_PAUSE_TICKS = 10;
    public static int DEFAULT_RUBBERBAND_PAUSE_TICKS = 15;

    /** Порог горизонтального velocity-delta для эвристики (0.5 = реальный кнокбэк). */
    public static double HORIZONTAL_VELOCITY_THRESHOLD = 0.5;

    /** Минимальный hurtTime для паузы (первые 4 тика ванила сама блокирует атаку). */
    public static int HURT_TIME_THRESHOLD = 4;

    /** Минимальная дистанция позиции для real rubberband (блоки).
     *  0.5 — выше микро-коррекций при knockback (0.3-0.5), но ниже
     *  реального rubberband'а (обычно > 1.0). */
    public static double RUBBERBAND_MIN_DISTANCE = 0.5;

    /** Максимальная дистанция позиции — выше это teleport (респаун), не rubberband. */
    public static double RUBBERBAND_MAX_DISTANCE = 10.0;

    /** Максимальная пауза (cap) для exponential backoff. */
    public static int MAX_PAUSE_TICKS = 40;

    // ─── Состояние ────────────────────────────────────────────

    private volatile int pauseTicks = 0;
    private volatile String pauseReason = "";
    private volatile int lastKnockbackTick = -1000;
    private volatile int currentTick = 0;
    private Vec3d lastVelocity = Vec3d.ZERO;
    private Vec3d lastKnockbackVelocity = Vec3d.ZERO;

    /** Сколько RUBBERBAND'ов пришло подряд (для exponential backoff). */
    private volatile int consecutiveRubberbands = 0;
    /** Тик последнего RUBBERBAND'а. */
    private volatile int lastRubberbandTick = -1000;

    /** Настраиваемые параметры (из KillAuraModule). */
    private volatile int knockbackPauseTicks = DEFAULT_KNOCKBACK_PAUSE_TICKS;
    private volatile int rubberbandPauseTicks = DEFAULT_RUBBERBAND_PAUSE_TICKS;
    private volatile boolean velocityHeuristicEnabled = false;
    private volatile boolean knockbackPauseEnabled = true;
    private volatile boolean hurtPauseEnabled = false; // OFF по умолчанию

    /** Singleton. */
    private static CombatState INSTANCE;

    public static synchronized CombatState getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new CombatState();
        }
        return INSTANCE;
    }

    private CombatState() {}

    /** Подписать CombatState на события. Вызывается из Core.bootstrap(). */
    public void subscribeSelf() {
        try {
            Client.get().eventManager().subscribe(this);
            KillAuraDebug.init();
            KillAuraDebug.log("CombatState v3 initialized (heuristic="
                    + velocityHeuristicEnabled + ", hurtPause=" + hurtPauseEnabled + ")");
        } catch (Throwable t) {
            Logger.error("CombatState.subscribeSelf failed", t);
        }
    }

    // ─── Настройка параметров ────────────────────────────────

    public void setKnockbackPauseTicks(int ticks) {
        this.knockbackPauseTicks = Math.max(0, ticks);
    }
    public void setRubberbandPauseTicks(int ticks) {
        this.rubberbandPauseTicks = Math.max(0, ticks);
    }
    public void setVelocityHeuristicEnabled(boolean enabled) {
        this.velocityHeuristicEnabled = enabled;
    }
    public void setKnockbackPauseEnabled(boolean enabled) {
        this.knockbackPauseEnabled = enabled;
    }
    public void setHurtPauseEnabled(boolean enabled) {
        this.hurtPauseEnabled = enabled;
    }

    // ─── Публичный API ────────────────────────────────────────

    public boolean isPaused() {
        if (!knockbackPauseEnabled) return false;
        return pauseTicks > 0 || isHurt();
    }

    public int pauseTicks() {
        return pauseTicks;
    }

    public String pauseReason() {
        if (isHurt() && hurtPauseEnabled) return "hurt";
        return pauseReason;
    }

    public int lastKnockbackAge() {
        return currentTick - lastKnockbackTick;
    }

    public Vec3d lastKnockbackVelocity() {
        return lastKnockbackVelocity;
    }

    public void pause(int ticks, String reason) {
        if (ticks > pauseTicks) {
            pauseTicks = ticks;
            pauseReason = reason;
            KillAuraDebug.logPause(pauseTicks, reason);
        }
    }

    // ─── Тик ──────────────────────────────────────────────────

    @EventHandler(priority = 50)
    public void onClientTick(ClientTickEvent e) {
        if (e.isPre()) {
            currentTick++;

            if (pauseTicks > 0) {
                pauseTicks--;
                if (pauseTicks == 0) {
                    KillAuraDebug.logResume();
                    pauseReason = "";
                    // Сбрасываем counter после успешного resume
                    consecutiveRubberbands = 0;
                }
            }

            // Сбрасываем counter если давно не было RUBBERBAND'ов
            if (currentTick - lastRubberbandTick > 40 && consecutiveRubberbands > 0) {
                consecutiveRubberbands = 0;
            }

            if (velocityHeuristicEnabled) {
                checkVelocityJump();
            }
        }
    }

    /** Эвристика: детекция кнокбэка по резкому скачку velocity (ТОЛЬКО горизонталь). */
    private void checkVelocityJump() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return;

        ClientPlayerEntity p = mc.player;
        Vec3d v = p.getVelocity();
        if (lastVelocity == Vec3d.ZERO) {
            lastVelocity = v;
            return;
        }

        Vec3d delta = v.subtract(lastVelocity);
        double horizontalDelta = Math.sqrt(delta.x * delta.x + delta.z * delta.z);

        if (horizontalDelta > HORIZONTAL_VELOCITY_THRESHOLD) {
            if (pauseTicks < knockbackPauseTicks) {
                pauseTicks = knockbackPauseTicks;
                pauseReason = "velocity-jump-h";
                lastKnockbackTick = currentTick;
                lastKnockbackVelocity = delta;
                KillAuraDebug.logKnockback(delta.x, delta.y, delta.z, knockbackPauseTicks);
            }
        }

        lastVelocity = v;
    }

    private boolean isHurt() {
        if (!hurtPauseEnabled) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return false;
        try {
            return mc.player.hurtTime > HURT_TIME_THRESHOLD;
        } catch (Throwable t) {
            return false;
        }
    }

    // ─── Перехват пакетов ────────────────────────────────────

    @EventHandler(priority = 20)
    public <T extends Packet<?>> void onPacketReceive(PacketReceiveEvent<T> e) {
        if (e == null || e.packet() == null) return;
        if (!knockbackPauseEnabled) return;

        Packet<?> p = e.packet();

        if (p instanceof EntityVelocityUpdateS2CPacket vel) {
            handleVelocityPacket(vel);
        } else if (p instanceof PlayerPositionLookS2CPacket ppl) {
            handlePlayerPositionLook(ppl);
        } else if (p instanceof ExplosionS2CPacket expl) {
            handleExplosion(expl);
        }
    }

    /**
     * Обработка пакета velocity — ТОЛЬКО реальный кнокбэк.
     *
     * <p><b>v3 — исправление ложных срабатываний:</b></p>
     * <p>Раньше я ловил ВСЕ velocity-пакеты с horizontal > 0.1. Но сервер
     * шлёт velocity для падения, движения, кастомных плагинов — не только
     * для кнокбэка. Это давало 40 ложных пауз за бой = "плохо бьёт".</p>
     *
     * <p><b>Теперь: только реальный combat knockback.</b> Реальный кнокбэк
     * от удара мечом ВСЕГДА имеет:</p>
     * <ul>
     *   <li>Y velocity = 0.3..0.5 (подбрасывает вверх)</li>
     *   <li>Horizontal > 0.1 (отталкивает от атакующего)</li>
     *   <li>player.hurtTime > 0 (подтверждённый урон)</li>
     * </ul>
     */
    private void handleVelocityPacket(EntityVelocityUpdateS2CPacket vel) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.player == null) return;

            if (vel.getEntityId() != mc.player.getId()) return;

            double vx = vel.getVelocityX();
            double vy = vel.getVelocityY();
            double vz = vel.getVelocityZ();
            double horizontal = Math.sqrt(vx * vx + vz * vz);

            // ФИЛЬТР: только реальный combat knockback!
            // 1. Y должен быть 0.3..0.6 (подбрасывает вверх — это кнокбэк).
            //    Y < 0 = падение, Y > 0.6 = прыжок/эффект — НЕ кнокбэк.
            // 2. Horizontal > 0.1 (отталкивает горизонтально)
            boolean isRealKnockback = (vy >= 0.3 && vy <= 0.6 && horizontal > 0.1);

            // 3. ИЛИ player.hurtTime > 0 (подтверждённый урон + любая velocity)
            boolean hasHurt = false;
            try {
                hasHurt = mc.player.hurtTime > 0;
            } catch (Throwable ignored) {}

            if (!isRealKnockback && !hasHurt) {
                // Не кнокбэк — логируем для отладки и пропускаем
                KillAuraDebug.trace(String.format(
                        "Velocity packet ignored: v=(%.3f,%.3f,%.3f) h=%.3f hurt=%b (not knockback)",
                        vx, vy, vz, horizontal, hasHurt));
                return;
            }

            // Реальный кнокбэк!
            if (pauseTicks < knockbackPauseTicks) {
                pauseTicks = knockbackPauseTicks;
                pauseReason = "velocity-packet";
                lastKnockbackTick = currentTick;
                lastKnockbackVelocity = new Vec3d(vx, vy, vz);
                KillAuraDebug.logKnockback(vx, vy, vz, knockbackPauseTicks);
            }
        } catch (Throwable t) {
            KillAuraDebug.logError("handleVelocityPacket failed", t);
        }
    }

    /**
     * Обработка {@code PlayerPositionLookS2CPacket} с правильным различением:
     * real rubberband vs teleport vs rotation-sync.
     */
    private void handlePlayerPositionLook(PlayerPositionLookS2CPacket ppl) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.player == null) return;

            // Получаем delta позиции (учитывая relatives)
            Vec3d playerPos = mc.player.getPos();
            Vec3d newPos = ppl.change().position();
            Set<PositionFlag> relatives = ppl.relatives();

            // Если relatives содержит X/Y/Z — это relative movement, не absolute teleport
            boolean isRelativeX = relatives.contains(PositionFlag.X);
            boolean isRelativeY = relatives.contains(PositionFlag.Y);
            boolean isRelativeZ = relatives.contains(PositionFlag.Z);

            // Вычисляем фактическую delta позиции
            double dx = isRelativeX ? newPos.x : (newPos.x - playerPos.x);
            double dy = isRelativeY ? newPos.y : (newPos.y - playerPos.y);
            double dz = isRelativeZ ? newPos.z : (newPos.z - playerPos.z);
            double delta = Math.sqrt(dx * dx + dy * dy + dz * dz);

            // Если ВСЕ координаты relative (т.е. это delta movement) — это не rubberband
            // Сервер так шлёт knockback velocity через position-packet на некоторых серверах
            boolean allRelative = isRelativeX && isRelativeY && isRelativeZ;
            // Если все X/Y/Z НЕ relative — это absolute position (классический rubberband/teleport)
            boolean allAbsolute = !isRelativeX && !isRelativeY && !isRelativeZ;

            // TELEPORT (респаун, смена мира): дистанция > 10 блоков
            if (allAbsolute && delta > RUBBERBAND_MAX_DISTANCE) {
                KillAuraDebug.detail(String.format(
                        "PlayerPositionLook: TELEPORT (delta=%.2f) — ignoring", delta));
                return;
            }

            // ROTATION-ONLY SYNC: только rotation, без position change
            // (delta < 0.3 — это шум округления)
            if (allAbsolute && delta < RUBBERBAND_MIN_DISTANCE) {
                KillAuraDebug.detail(String.format(
                        "PlayerPositionLook: rotation-only (delta=%.2f) — ignoring", delta));
                return;
            }

            // REAL RUBBERBAND: позиция сместилась на 0.3..10 блоков
            // (или все relative — на некоторых серверах это delta movement)

            // Exponential backoff: если RUBBERBAND'ы идут подряд, увеличиваем паузу
            int ticksSinceLast = currentTick - lastRubberbandTick;
            if (ticksSinceLast < 20) {
                consecutiveRubberbands++;
            } else {
                consecutiveRubberbands = 1;
            }
            lastRubberbandTick = currentTick;

            // Базовая пауза + 5 тиков за каждый consecutive rubberband (max 40)
            int pauseFor = rubberbandPauseTicks
                    + Math.min(20, (consecutiveRubberbands - 1) * 5);
            pauseFor = Math.min(MAX_PAUSE_TICKS, pauseFor);

            if (pauseTicks < pauseFor) {
                pauseTicks = pauseFor;
                pauseReason = "rubberband:" + (int) delta;
                KillAuraDebug.log(String.format(
                        "RUBBERBAND delta=%.2f consec=%d pausing %d ticks",
                        delta, consecutiveRubberbands, pauseFor));
            }
        } catch (Throwable t) {
            KillAuraDebug.logError("handlePlayerPositionLook failed", t);
        }
    }

    /** Обработка взрыва. */
    private void handleExplosion(ExplosionS2CPacket expl) {
        try {
            java.util.Optional<Vec3d> knockback = expl.playerKnockback();
            if (knockback.isPresent()) {
                Vec3d playerVelocity = knockback.get();
                if (playerVelocity.lengthSquared() > 0.01) {
                    if (pauseTicks < knockbackPauseTicks) {
                        pauseTicks = knockbackPauseTicks;
                        pauseReason = "explosion";
                        lastKnockbackTick = currentTick;
                        lastKnockbackVelocity = playerVelocity;
                        KillAuraDebug.logKnockback(
                                playerVelocity.x, playerVelocity.y, playerVelocity.z,
                                knockbackPauseTicks);
                    }
                }
            }
        } catch (Throwable t) {
            KillAuraDebug.logError("handleExplosion failed", t);
        }
    }
}
