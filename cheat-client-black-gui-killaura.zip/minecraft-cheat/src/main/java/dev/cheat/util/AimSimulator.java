package dev.cheat.util;

import net.minecraft.util.math.Vec3d;
import java.util.Random;

/**
 * Алгоритм сглаживания и рандомизации наводки (Aim Smoothing).
 *
 * <p><b>Назначение:</b> Превращает «робкий» снап целевого yaw/pitch в
 * плавную человеческую траекторию с микродрожанием. Без этой обработки
 * KillAura выглядит как идеальная прямая линия — мгновенный флаг для
 * Polar (AimPattern, AimAnalysis, RotationAnalyzer).</p>
 *
 * <p><b>Реализованные техники:</b></p>
 * <ul>
 *   <li><b>Exponential smoothing</b> — каждый тик приближаемся к цели на
 *       {@code (1 - smoothing)} долю расстояния. Параметр {@code smoothing}
 *       от 0 (мгновенно) до 1 (почти не двигаемся). Люди «догоняют» цель
 *       именно экспоненциально.</li>
 *
 *   <li><b>Bezier path interpolation</b> — между current и target
 *       интерполируем не по прямой, а по квадратичной кривой Безье со
 *       случайной контрольной точкой. Это ломает линейную регрессию
 *       Polar'а (которая ищет идеально прямые траектории aim).</li>
 *
 *   <li><b>Perlin-like jitter</b> — поверх целевого yaw/pitch добавляем
 *       псевдо-перлин-шум амплитудой {@code jitter} градусов. Это имитирует
 *       дрожание руки. Polar флагает стабильно нулевой jitter.</li>
 *
 *   <li><b>Speed cap</b> — ограничиваем максимальный rotation-delta за тик.
 *       Люди не могут повернуть на 180° за один тик. Polar флагает
 *       rotation &gt; 30°/tick как нечеловеческий.</li>
 *
 *   <li><b>Per-tick seed reseed</b> — {@link Random} пересоздаётся каждый
 *       тик с новым seed (через System.nanoTime()), чтобы последовательность
 *       jitter'а была непредсказуемой и не циклилась.</li>
 * </ul>
 */
public final class AimSimulator {

    private AimSimulator() {}

    /** Максимальный rotation-delta в градусах за тик (Polar флагает > 30). */
    public static final float MAX_DELTA_PER_TICK = 29.0f;

    /** Минимальный rotation-delta (ниже этого — не двигаемся, чтобы не флудить пакетами). */
    public static final float MIN_DELTA_THRESHOLD = 0.05f;

    /** Локальный генератор (пересоздаётся каждый тик для непредсказуемости). */
    private static Random rng = new Random();

    /**
     * Один шаг сглаживания от {@code current} к {@code target}.
     *
     * @param currentYaw    текущий серверный yaw
     * @param currentPitch  текущий серверный pitch
     * @param targetYaw     желаемый yaw (на цель)
     * @param targetPitch   желаемый pitch (на цель)
     * @param smoothing     0..1 — чем больше, тем медленнее наводка (0 = снап, 0.95 = очень плавно)
     * @param jitter        амплитуда микродрожания в градусах (0..5, обычно 0.5..2)
     * @param bezier        включить искривление траектории Безье (true = рекомендовано)
     * @return массив {@code [yaw, pitch]} — новая позиция для отправки на сервер
     */
    public static float[] step(float currentYaw, float currentPitch,
                               float targetYaw, float targetPitch,
                               float smoothing, float jitter, boolean bezier) {
        // Пересидим генератор
        rng = new Random(System.nanoTime());

        // 1. Exponential smoothing
        float dyaw   = MathUtil.angleDelta(currentYaw,   targetYaw);
        float dpitch = MathUtil.angleDelta(currentPitch, targetPitch);

        // smoothing=0 → factor=1 (мгновенно), smoothing=0.95 → factor=0.05 (плавно)
        float factor = MathUtil.clamp(1.0f - smoothing, 0.01f, 1.0f);

        float stepYaw   = dyaw   * factor;
        float stepPitch = dpitch * factor;

        // 2. Bezier control-point offset (квадратичная кривая)
        // Контрольная точка = середина + перпендикулярный смещение случайной величины
        if (bezier && (Math.abs(dyaw) > 1.0f || Math.abs(dpitch) > 1.0f)) {
            // Перпендикуляр к (dyaw, dpitch) в 2D = (-dpitch, dyaw)
            float len = (float) Math.sqrt(dyaw * dyaw + dpitch * dpitch);
            if (len > 0.001f) {
                float perpX = -dpitch / len;
                float perpY =  dyaw   / len;
                // Случайное смещение 5..15% от длины (в обе стороны)
                float offset = (rng.nextFloat() * 2.0f - 1.0f) * len * 0.10f;
                stepYaw   += perpX * offset * factor;
                stepPitch += perpY * offset * factor;
            }
        }

        // 3. Speed cap (Polar флагает rotation > 30°/tick)
        if (Math.abs(stepYaw) > MAX_DELTA_PER_TICK) {
            stepYaw = Math.signum(stepYaw) * MAX_DELTA_PER_TICK;
        }
        if (Math.abs(stepPitch) > MAX_DELTA_PER_TICK) {
            stepPitch = Math.signum(stepPitch) * MAX_DELTA_PER_TICK;
        }

        // 4. Perlin-like jitter (белый шум с малой амплитудой)
        if (jitter > 0.0f) {
            // jitter ~ N(0, jitter/3), чтобы 99.7% значений были в [-jitter, jitter]
            float jy = (float) rng.nextGaussian() * (jitter / 3.0f);
            float jp = (float) rng.nextGaussian() * (jitter / 3.0f);
            stepYaw   += jy;
            stepPitch += jp;
        }

        // 5. Минимальный порог: если дельта слишком мала — не двигаемся
        // (это позволяет избежать флуда rotation-пакетами с delta=0.0001)
        if (Math.abs(stepYaw) < MIN_DELTA_THRESHOLD)   stepYaw   = 0.0f;
        if (Math.abs(stepPitch) < MIN_DELTA_THRESHOLD) stepPitch = 0.0f;

        // 6. Финальные yaw/pitch
        float newYaw   = MathUtil.normalizeAngle(currentYaw   + stepYaw);
        float newPitch = MathUtil.clamp(currentPitch + stepPitch, -90.0f, 90.0f);

        return new float[] { newYaw, newPitch };
    }

    /**
     * Вычислить целевую точку на хитбоксе цели с рандомизацией точки прицеливания.
     *
     * <p><b>Зачем:</b> Polar флагает KillAura, который всегда бьёт в одну
     * точку (обычно — в голову/глаза). Реальный игрок наводится в разные
     * участки хитбокса. Эта функция возвращает случайную точку в пределах
     * хитбокса (с Bias в центр — реальный игрок чаще бьёт в центр масс).</p>
     *
     * @param boxMin    минимальный угол хитбокса (в мире)
     * @param boxMax    максимальный угол хитбокса
     * @param centerBias 0..1 — предпочтение центру (0 = полностью случайно, 1 = всегда центр)
     * @return случайная точка внутри хитбокса
     */
    public static Vec3d randomHitboxPoint(Vec3d boxMin, Vec3d boxMax, float centerBias) {
        rng = new Random(System.nanoTime() ^ Thread.currentThread().threadId());

        // Bias к центру: смешиваем равномерное распределение с центром
        // t=0 → центр, t=1 → равномерно
        float t = 1.0f - MathUtil.clamp(centerBias, 0.0f, 1.0f);

        double u = (rng.nextDouble() - 0.5) * t + 0.5;
        double v = (rng.nextDouble() - 0.5) * t + 0.5;
        double w = (rng.nextDouble() - 0.5) * t + 0.5;

        double x = boxMin.x + (boxMax.x - boxMin.x) * u;
        double y = boxMin.y + (boxMax.y - boxMin.y) * v;
        double z = boxMin.z + (boxMax.z - boxMin.z) * w;
        return new Vec3d(x, y, z);
    }

    /**
     * Случайный CPS-jitter: отклонение от идеального времени удара.
     *
     * <p><b>Зачем:</b> Идеальный KillAura бьёт ровно в момент завершения
     * кулдауна (например, каждые 12.5 тиков для меча). Polar флагает такую
     * идеальную периодичность. Добавляем ±2 тика случайности.</p>
     *
     * @param baseTicks идеальное число тиков между ударами
     * @return фактическое число тиков с jitter'ом
     */
    public static int cpsJitter(int baseTicks) {
        rng = new Random(System.nanoTime());
        int jitter = rng.nextInt(5) - 2; // -2..+2
        return Math.max(1, baseTicks + jitter);
    }

    /**
     * Нормальный случайный double в диапазоне [min, max).
     */
    public static double randomRange(double min, double max) {
        rng = new Random(System.nanoTime());
        return min + rng.nextDouble() * (max - min);
    }
}
