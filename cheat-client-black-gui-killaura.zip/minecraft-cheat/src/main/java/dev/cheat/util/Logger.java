package dev.cheat.util;

import dev.cheat.CheatClient;
import org.slf4j.LoggerFactory;

/**
 * Единый логгер мода на SLF4J (в Fabric логи идут в log4j2/logback).
 *
 * <p>API:</p>
 * <ul>
 *   <li>{@link #info(String)}     — информационные сообщения (загрузка)</li>
 *   <li>{@link #warn(String)}     — некритичные проблемы</li>
 *   <li>{@link #error(String, Throwable)} — ошибки с трейсом</li>
 *   <li>{@link #debug(String)}    — отладочные (только в dev-сборке)</li>
 * </ul>
 */
public final class Logger {

    private static final org.slf4j.Logger LOG =
            LoggerFactory.getLogger(CheatClient.MOD_NAME);

    private Logger() {}

    public static void info(String msg)  { LOG.info(msg); }
    public static void info(String fmt, Object... a) { LOG.info(fmt, a); }

    public static void warn(String msg)  { LOG.warn(msg); }
    public static void warn(String fmt, Object... a) { LOG.warn(fmt, a); }

    public static void error(String msg) { LOG.error(msg); }
    public static void error(String msg, Throwable t) { LOG.error(msg, t); }

    public static void debug(String msg) {
        // В релизе можно отключить через системное свойство
        if (Boolean.getBoolean("cheat.debug")) LOG.debug(msg);
    }
}
