package dev.cheat.util;

import dev.cheat.Client;
import dev.cheat.manager.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Выбор цели для KillAura с фильтрами и сортировкой.
 *
 * <p><b>Строгий Raycast-фильтр (Raytrace Verification):</b> проверяет,
 * что между игроком и целью нет непрозрачных блоков. Polar флагает атаки
 * «сквозь стены» — без этой проверки KillAura мгновенно ловится.</p>
 *
 * <p><b>Дополнительные фильтры:</b></p>
 * <ul>
 *   <li><b>Range</b> — евклидово расстояние от глаз игрока до ближайшей
 *       точки хитбокса цели. Используется именно «ближайшая точка», а не
 *       центр — это даёт честные 3.0..3.5 блока reach, как у ванилы.</li>
 *
 *   <li><b>FOV</b> — угол между направлением взгляда игрока и направлением
 *       на цель. Если 180° — цель позади, и игрок её физически не увидит.
 *       Polar флагает атаки в цель «за спиной» (FOV &gt; 180).</li>
 *
 *   <li><b>CanSee</b> — combo-проверка: raycast от глаз игрока до точки
 *       прицеливания на цели. Если raycast попадает в блок раньше цели —
 *       цели не видно, атаковать нельзя.</li>
 *
 *   <li><b>Living &amp; Attackable</b> — цель должна быть жива и быть
 *       {@link LivingEntity} (не item frame, не boat и т.д.).</li>
 *
 *   <li><b>Not Friend</b> — друзья из {@code FriendManager} исключаются.</li>
 *
 *   <li><b>Not Self</b> — сам игрок исключается (тривиально, но важно).</li>
 *
 *   <li><b>Not Invisible/Dead</b> — невидимые (без брони) и мёртвые
 *       сущности исключаются.</li>
 * </ul>
 *
 * <p><b>Сортировки:</b></p>
 * <ul>
 *   <li>{@link SortMode#DISTANCE} — ближайшая цель первой (по умолчанию).</li>
 *   <li>{@link SortMode#HEALTH} — цель с наименьшим HP (добивание).</li>
 *   <li>{@link SortMode#ANGLE} — цель ближе к взгляду (минимальный FOV).</li>
 *   <li>{@link SortMode#DAMAGE} — цель, по которой пройдёт максимум урона
 *       (учитывает cooldown и броню).</li>
 * </ul>
 */
public final class TargetSelector {

    private TargetSelector() {}

    /** Режим сортировки целей. */
    public enum SortMode { DISTANCE, HEALTH, ANGLE, DAMAGE }

    /**
     * Найти лучшую цель по заданным параметрам.
     *
     * @param maxRange    максимальная дальность в блоках
     * @param maxFovDeg   максимальный FOV в градусах (180 = без ограничения)
     * @param raycast     true — проверять line-of-sight через блоки
     * @param expandHitbox расширение хитбокса (для большей зоны попадания)
     * @param sortMode    режим сортировки
     * @return цель или null, если ничего не подошло
     */
    public static LivingEntity findTarget(double maxRange, double maxFovDeg,
                                          boolean raycast, double expandHitbox,
                                          SortMode sortMode) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null) return null;

        ClientPlayerEntity self = mc.player;
        List<LivingEntity> candidates = new ArrayList<>();

        Vec3d eyePos = self.getEyePos();

        // mc.world — это ClientWorld, у которого есть getEntities().
        // World (родитель) этого метода не имеет.
        for (Entity ent : mc.world.getEntities()) {
            if (!(ent instanceof LivingEntity living)) continue;
            if (ent == self)                           continue;
            if (!ent.isAttackable())                   continue;
            if (living.getHealth() <= 0.0f)            continue;
            if (living.isDead())                       continue;

            // Друзья — исключаем
            if (ent instanceof PlayerEntity p) {
                if (Client.tryGet() != null
                        && Client.get().friendManager() != null
                        && Client.get().friendManager().isFriend(p.getName().getString())) {
                    continue;
                }
                // Невидимки без брони — обычно не атакуем (их и так не видно)
                if (p.isInvisible() && p.getArmor() <= 0 && p.getMainHandStack().isEmpty()) {
                    continue;
                }
            }

            // Ближайшая точка расширенного хитбокса
            Box hitbox = ent.getBoundingBox().expand(expandHitbox);
            Vec3d closest = closestPointOnBox(eyePos, hitbox);
            double dist = eyePos.distanceTo(closest);

            if (dist > maxRange) continue;

            // FOV-фильтр
            if (maxFovDeg < 180.0) {
                float[] rot = RotationManager.lookAt(eyePos, closest);
                float dyaw = Math.abs(MathUtil.angleDelta(self.getYaw(), rot[0]));
                float dpit = Math.abs(self.getPitch() - rot[1]);
                double angle = Math.sqrt(dyaw * dyaw + dpit * dpit);
                if (angle > maxFovDeg) continue;
            }

            // Raycast-фильтр (line-of-sight)
            if (raycast && !canSee(self, eyePos, closest)) {
                continue;
            }

            candidates.add(living);
        }

        if (candidates.isEmpty()) return null;

        // Сортировка по выбранному режиму
        Comparator<LivingEntity> cmp = switch (sortMode) {
            case DISTANCE -> Comparator.comparingDouble(e ->
                    eyePos.distanceTo(closestPointOnBox(eyePos,
                            e.getBoundingBox().expand(expandHitbox))));
            case HEALTH   -> Comparator.comparingDouble(LivingEntity::getHealth);
            case ANGLE    -> Comparator.comparingDouble(e -> {
                Vec3d c = closestPointOnBox(eyePos, e.getBoundingBox().expand(expandHitbox));
                float[] rot = RotationManager.lookAt(eyePos, c);
                float dyaw = Math.abs(MathUtil.angleDelta(self.getYaw(), rot[0]));
                float dpit = Math.abs(self.getPitch() - rot[1]);
                return Math.sqrt(dyaw * dyaw + dpit * dpit);
            });
            case DAMAGE   -> Comparator.comparingDouble(e -> -estimateDamage(self, e));
        };

        candidates.sort(cmp);
        return candidates.get(0);
    }

    /**
     * Строгий raycast-фильтр (Raytrace Verification).
     *
     * <p>Проверяет, что между {@code from} и {@code to} нет непрозрачных
     * блоков. Если луч упирается в блок раньше, чем достигает цели —
     * цель не видна.</p>
     *
     * <p><b>Важно для Polar:</b> Polar проверяет не просто «видна ли цель»,
     * а «возможна ли атака» — то есть raycast от глаз игрока до точки
     * прицеливания на цели НЕ должен пересекать коллизию блоков. Мы
     * используем ванильный {@link RaycastContext} с
     * {@code ShapeType.OUTLINE} и {@code FluidHandling.NONE}.</p>
     *
     * @param from точка наблюдения (обычно — глаза игрока)
     * @param to   точка на цели
     * @return true — цель видна (нет блоков между), false — есть препятствие
     */
    public static boolean canSee(ClientPlayerEntity player, Vec3d from, Vec3d to) {
        if (player.getWorld() == null) return true;

        RaycastContext ctx = new RaycastContext(
                from, to,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                player
        );
        BlockHitResult hit = player.getWorld().raycast(ctx);
        return hit == null || hit.getType() == HitResult.Type.MISS;
    }

    /**
     * Ближайшая точка на Box к заданной точке (для честного reach).
     */
    public static Vec3d closestPointOnBox(Vec3d point, Box box) {
        double x = MathHelper.clamp(point.x, box.minX, box.maxX);
        double y = MathHelper.clamp(point.y, box.minY, box.maxY);
        double z = MathHelper.clamp(point.z, box.minZ, box.maxZ);
        return new Vec3d(x, y, z);
    }

    /**
     * Грубая оценка урона по цели (для сортировки DAMAGE).
     *
     * <p>Учитывает кулдаун игрока и базовый урон предмета. Не претендует
     * на точность — нужна только для сравнения целей между собой.</p>
     */
    private static double estimateDamage(ClientPlayerEntity player, LivingEntity target) {
        double base = player.getAttackCooldownProgress(0.5f); // 0..1
        double dmg  = player.getMainHandStack() != null
                ? 4.0  // грубая оценка: средний урон меча
                : 1.0;
        return dmg * base * (1.0 - target.getArmor() / 30.0);
    }
}
