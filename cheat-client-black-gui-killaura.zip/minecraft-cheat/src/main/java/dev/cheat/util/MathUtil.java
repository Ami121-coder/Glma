package dev.cheat.util;

import net.minecraft.util.math.Vec3d;

/**
 * Математические утилиты.
 *
 * <p>Каркас оставляет часто используемые функции: расстояния,
 * интерполяция, клампинг, конвертация углов.</p>
 */
public final class MathUtil {

    private MathUtil() {}

    public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static double distance(Vec3d a, Vec3d b) {
        return distance(a.x, a.y, a.z, b.x, b.y, b.z);
    }

    public static double distance2d(double x1, double z1, double x2, double z2) {
        double dx = x2 - x1, dz = z2 - z1;
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    public static float  lerp(float  a, float  b, float  t) { return a + (b - a) * t; }

    public static int    clamp(int v,    int min, int max)    { return Math.max(min, Math.min(max, v)); }
    public static double clamp(double v, double min, double max){ return Math.max(min, Math.min(max, v)); }
    public static float  clamp(float v,  float min, float max) { return Math.max(min, Math.min(max, v)); }

    /** Нормализует угол в диапазон [-180, 180). */
    public static float normalizeAngle(float angle) {
        angle = angle % 360f;
        if (angle >= 180f)  angle -= 360f;
        if (angle < -180f)  angle += 360f;
        return angle;
    }

    /** Разница между двумя углами в диапазоне [-180, 180]. */
    public static float angleDelta(float a, float b) {
        return normalizeAngle(b - a);
    }

    /** Приблизительное равенство float с допуском. */
    public static boolean equalsApprox(float a, float b, float eps) {
        return Math.abs(a - b) <= eps;
    }

    public static boolean equalsApprox(float a, float b) {
        return equalsApprox(a, b, 1e-4f);
    }

    /** Линейная интерполяция углов (с учётом кратчайшего пути). */
    public static float lerpAngle(float a, float b, float t) {
        return normalizeAngle(a + angleDelta(a, b) * t);
    }
}
