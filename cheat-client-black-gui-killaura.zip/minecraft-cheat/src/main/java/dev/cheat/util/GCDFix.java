package dev.cheat.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;

/**
 * Математический GCD-Фикс (Mouse Sensitivity Fix).
 *
 * <p><b>Проблема:</b> Любое движение мыши в Minecraft проходит через
 * формулу чувствительности, которая превращает целочисленный delta-пиксель
 * в дробный rotation-delta с фиксированным шагом (GCD). Если чит вращает
 * игрока «произвольным» дробным значением, анти-чит (Polar, Grim, Vulcan,
 * Matrix) видит, что rotation-delta не кратен GCD — это 100% флаг «aimbot /
 * invalid rotation».</p>
 *
 * <p><b>Формула Minecraft (1.21.x, {@code Mouse.updateMouse}):</b></p>
 * <pre>
 *   double sens  = options.mouseSensitivity;   // 0..1, по умолчанию 0.5
 *   double f     = sens * 0.6 + 0.2;
 *   double g     = f * f * f;                    // = f^3
 *   double step  = g * 1.2;                      // = f^3 * 8 * 0.15
 *   // yaw_delta   = mouseDeltaX * step;
 *   // pitch_delta = mouseDeltaY * step;
 * </pre>
 *
 * <p>Все реальные rotation-delta кратны {@code step}. Этот класс делает
 * снаппинг наших rotation-delta к сетке {@code step}.</p>
 *
 * <p><b>Дополнительно для Polar:</b> Polar использует «теорему о GCD» —
 * берёт N последних rotation-delta и считает их вещественный GCD. Если
 * полученный GCD меньше теоретического минимума (step для текущей
 * чувствительности), флаг. Поэтому мы <b>всегда</b> снапаем кратно шагу,
 * даже если delta = 0.0 (тогда ничего не делаем).</p>
 */
public final class GCDFix {

    private GCDFix() {}

    /** Кеш последнего GCD (чтобы не пересчитывать каждый тик). */
    private static volatile float cachedSensitivity = -1.0f;
    private static volatile float cachedGCD         = 0.0f;

    /**
     * Получить текущий GCD (минимальный шаг rotation-delta) для
     * чувствительности игрока.
     *
     * @return GCD в градусах, всегда &gt; 0
     */
    public static float gcd() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.options == null) return 0.0f;

        SimpleOption<Double> opt = mc.options.getMouseSensitivity();
        if (opt == null) return 0.0f;

        double sens = opt.getValue();
        float  sensF = (float) sens;

        // Проверяем кеш (чувствительность могла поменяться в настройках)
        if (Math.abs(sensF - cachedSensitivity) < 1e-6f && cachedGCD > 0.0f) {
            return cachedGCD;
        }

        // Формула Minecraft:
        //   f = sens * 0.6 + 0.2
        //   g = f^3
        //   step = g * 1.2  (= g * 8 * 0.15)
        double f = sens * 0.6 + 0.2;
        double g = f * f * f;
        double step = g * 1.2;

        // Защита от деления на 0 (sens = 0 → step всё равно > 0 из-за 0.2)
        if (step <= 0.0) step = 1e-4;

        cachedSensitivity = sensF;
        cachedGCD = (float) step;
        return cachedGCD;
    }

    /**
     * Снапнуть rotation-delta к сетке GCD.
     *
     * <p><b>Важно:</b> передаётся именно DELTA (разница между целевым yaw и
     * текущим серверным yaw), а не абсолютный yaw. После снаппинга нужно
     * прибавить delta обратно к серверному yaw.</p>
     *
     * @param delta разница углов в градусах
     * @return delta, округлённая до ближайшего кратного GCD
     */
    public static float snapDelta(float delta) {
        float gcd = gcd();
        if (gcd <= 0.0f || delta == 0.0f) return delta;

        // Округляем к ближайшему кратному (в обе стороны — для отрицательных тоже)
        int n = Math.round(delta / gcd);
        return n * gcd;
    }

    /**
     * Применить GCD-фикс к абсолютному yaw/pitch относительно известных
     * серверных ротаций.
     *
     * <p>Алгоритм:</p>
     * <ol>
     *   <li>delta = target − serverRot</li>
     *   <li>delta = snapDelta(delta)   // снап к GCD-сетке</li>
     *   <li>return serverRot + delta   // финальная ротация для отправки</li>
     * </ol>
     *
     * @param serverYaw   последний отправленный на сервер yaw
     * @param serverPitch последний отправленный на сервер pitch
     * @param targetYaw   желаемый yaw (куда хотим смотреть)
     * @param targetPitch желаемый pitch
     * @return массив {@code [yaw, pitch]} с применённым GCD-фиксом
     */
    public static float[] applyGCD(float serverYaw, float serverPitch,
                                   float targetYaw, float targetPitch) {
        float dyaw   = MathUtil.angleDelta(serverYaw, targetYaw);
        float dpitch = targetPitch - serverPitch;

        float snappedYaw   = snapDelta(dyaw);
        float snappedPitch = snapDelta(dpitch);

        // Если дельта оказалась меньше GCD — не двигаемся (0 = не отправлять
        // лишний rotation-пакет). Polar флагает rotation-packet с delta=0,
        // но мы это обрабатываем на уровне модуля (не шлём LookAndOnGround
        // без нужды).
        if (Math.abs(snappedYaw) < 1e-6f && Math.abs(dyaw) > 1e-6f) {
            // Округление дало 0, но была потребность повернуть — берём
            // минимальный 1 шаг в нужную сторону.
            snappedYaw = Math.signum(dyaw) * gcd();
        }
        if (Math.abs(snappedPitch) < 1e-6f && Math.abs(dpitch) > 1e-6f) {
            snappedPitch = Math.signum(dpitch) * gcd();
        }

        return new float[] {
                MathUtil.normalizeAngle(serverYaw + snappedYaw),
                MathUtil.clamp(serverPitch + snappedPitch, -90.0f, 90.0f)
        };
    }

    /** Сброс кеша (вызывается при смены чувствительности в настройках). */
    public static void invalidateCache() {
        cachedSensitivity = -1.0f;
        cachedGCD         = 0.0f;
    }
}
