package dev.cheat.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Расширенный дебаг-логгер для KillAura v3 — оптимизированный.
 *
 * <p><b>Оптимизации производительности v3:</b></p>
 * <ul>
 *   <li><b>Async writing:</b> логи складываются в lock-free очередь
 *       ({@link ConcurrentLinkedQueue}) и пишутся в файл фоновым потоком
 *       {@code KillAura-DebugLog}. Render thread НЕ блокируется на I/O.</li>
 *
 *   <li><b>Batch flush:</b> flush каждые {@value #FLUSH_INTERVAL_MS} мс
 *       (а не после каждой строки). Это в 50-100x быстрее при TRACE level.</li>
 *
 *   <li><b>Cached timestamp per tick:</b> {@link DateTimeFormatter} кеширует
 *       timestamp на тик — не парсит {@code new Date()} на каждую строку.</li>
 *
 *   <li><b>Conditional formatting:</b> если verbosity &lt; level — НЕ
 *       форматируем строку (раньше String.format вызывался всегда).</li>
 *
 *   <li><b>Ring buffer:</b> последние {@value #RING_BUFFER_SIZE} строк
 *       хранятся в памяти. При ошибке — dump всего ring buffer'а в лог
 *       для контекста.</li>
 *
 *   <li><b>Metrics counters:</b> считаем attacks/rubberbands/knockbacks/
 *       skips/ticks. При закрытии пишем summary.</li>
 *
 *   <li><b>Log rotation:</b> если файл &gt; {@value #MAX_LOG_SIZE_BYTES},
 *       он переименовывается в {@code killaura.log.old} и начинается новый.</li>
 *
 *   <li><b>No main-log spam:</b> при verbosity=3 (TRACE) дублирование в
 *       основной Minecraft лог отключается (иначе 1000+ строк/сек).</li>
 * </ul>
 *
 * <p><b>Уровни логирования:</b></p>
 * <ul>
 *   <li>{@code OFF} (0) — логирование отключено</li>
 *   <li>{@code BASIC} (1) — enable/disable, attack, knockback, rubberband</li>
 *   <li>{@code DETAIL} (2) — + цели, ротации, паузы, skips</li>
 *   <li>{@code TRACE} (3) — + каждый тик: position, velocity, rotation, sprint</li>
 * </ul>
 *
 * <p><b>CSV-режим:</b> при TRACE также пишется {@code killaura-tick.csv}
 * для анализа в Excel.</p>
 */
public final class KillAuraDebug {

    private KillAuraDebug() {}

    // ─── Константы ────────────────────────────────────────────

    public static final Path LOG_FILE = Paths.get("cheat", "logs", "killaura.log");
    public static final Path LOG_FILE_OLD = Paths.get("cheat", "logs", "killaura.log.old");
    public static final Path CSV_FILE = Paths.get("cheat", "logs", "killaura-tick.csv");
    public static final Path CSV_FILE_OLD = Paths.get("cheat", "logs", "killaura-tick.csv.old");

    /** Интервал flush в мс (async writer). */
    private static final long FLUSH_INTERVAL_MS = 250;

    /** Максимальный размер лог-файла (5 MB) до ротации. */
    private static final long MAX_LOG_SIZE_BYTES = 5L * 1024 * 1024;

    /** Размер ring buffer'а для контекста ошибок. */
    private static final int RING_BUFFER_SIZE = 200;

    // ─── Состояние ────────────────────────────────────────────

    private static final DateTimeFormatter TS_FORMATTER =
            DateTimeFormatter.ofPattern("HH:mm:ss.SSS").withZone(ZoneId.systemDefault());

    /** Writer'ы (доступ только из async-thread). */
    private static volatile PrintWriter writer;
    private static volatile PrintWriter csvWriter;

    /** Очередь логов для async writing (lock-free). */
    private static final ConcurrentLinkedQueue<String> logQueue = new ConcurrentLinkedQueue<>();
    private static final ConcurrentLinkedQueue<String> csvQueue = new ConcurrentLinkedQueue<>();

    /** Максимальный размер очереди (защита от OOM при медленном диске). */
    private static final int MAX_QUEUE_SIZE = 50_000;

    /** Счётчик дропнутых логов (когда очередь переполнена). */
    private static final AtomicLong droppedLogs = new AtomicLong(0);

    /** Async writer thread. */
    private static volatile Thread writerThread;
    private static final AtomicBoolean running = new AtomicBoolean(false);

    /** Кеш timestamp — обновляется по времени (каждые 50мс = 1 тик),
     *  НЕ по внутреннему счётчику тиков. Это исправляет баг, когда при
     *  verbosity < 3 (BASIC/DETAIL) метод logTickState() не вызывается,
     *  tickCount не инкрементируется, и cachedTimestamp обновлялся
     *  только один раз за сессию. */
    private static volatile String cachedTimestamp = "";
    private static volatile long cachedTimestampMs = 0;

    /** Ring buffer последних строк (для контекста ошибок).
     *  ConcurrentLinkedDeque — lock-free, без synchronized блокировок. */
    private static final Deque<String> ringBuffer = new ConcurrentLinkedDeque<>();

    /** Настройки. */
    private static volatile boolean enabled = true;
    private static volatile int verbosity = 2;
    private static volatile boolean csvEnabled = false;
    private static volatile boolean logToMainLog = true; // false при TRACE

    // ─── Metrics counters ─────────────────────────────────────

    private static final AtomicLong attackCount = new AtomicLong(0);
    private static final AtomicLong rubberbandCount = new AtomicLong(0);
    private static final AtomicLong knockbackCount = new AtomicLong(0);
    private static final AtomicLong skipCount = new AtomicLong(0);
    private static final AtomicLong tickCount = new AtomicLong(0);
    private static final AtomicLong totalLogLines = new AtomicLong(0);
    private static volatile long sessionStartTime = 0;

    // ─── Инициализация ────────────────────────────────────────

    public static synchronized void init() {
        if (writer != null) return;
        try {
            Files.createDirectories(LOG_FILE.getParent());

            // Log rotation: если файл слишком большой — переименовать
            rotateIfNeeded(LOG_FILE, LOG_FILE_OLD);
            rotateIfNeeded(CSV_FILE, CSV_FILE_OLD);

            writer = new PrintWriter(new FileWriter(LOG_FILE.toFile(), true), false);
            logRawInternal("====================================================");
            logRawInternal("KillAura Debug Log v3 (optimized) — session started at " + Instant.now());
            logRawInternal("Minecraft " + safeMcVersion() + " / verbosity=" + verbosityName(verbosity));
            logRawInternal("Async writer: ON, flush interval=" + FLUSH_INTERVAL_MS + "ms");
            logRawInternal("====================================================");

            sessionStartTime = System.currentTimeMillis();

            // Инициализируем CSV writer если verbosity уже = 3 (TRACE).
            // Раньше это делалось только в setVerbosity(), что вызывало баг:
            // если verbosity=3 при init(), CSV writer не создавался до
            // повторного вызова setVerbosity().
            initCsvIfNeeded();

            // Запускаем async writer thread
            running.set(true);
            writerThread = new Thread(KillAuraDebug::asyncWriterLoop,
                    "KillAura-DebugLog");
            writerThread.setDaemon(true);
            writerThread.setPriority(Thread.MIN_PRIORITY); // минимальный приоритет
            writerThread.start();

        } catch (IOException e) {
            Logger.error("KillAuraDebug init failed", e);
        }
    }

    /**
     * Инициализирует CSV writer если verbosity >= 3 и он ещё не создан.
     * Вызывается из init() и setVerbosity().
     */
    private static void initCsvIfNeeded() {
        if (csvEnabled && csvWriter == null) {
            try {
                rotateIfNeeded(CSV_FILE, CSV_FILE_OLD);
                csvWriter = new PrintWriter(new FileWriter(CSV_FILE.toFile(), true), false);
                csvQueue.offer("tick,timestamp,posX,posY,posZ,velX,velY,velZ," +
                        "serverYaw,serverPitch,desiredYaw,desiredPitch,rotDelta," +
                        "sprint,onGround,target,targetDist,targetHp,attackPlanned," +
                        "paused,pauseReason,pauseTicksLeft");
            } catch (IOException ignored) {}
        }
    }

    /** Цикл async writing — работает в отдельном потоке. */
    private static void asyncWriterLoop() {
        long lastFlush = System.currentTimeMillis();
        while (running.get()) {
            try {
                long now = System.currentTimeMillis();

                // Drain queue → file
                int written = 0;
                String line;
                while ((line = logQueue.poll()) != null) {
                    if (writer != null) {
                        writer.println(line);
                        written++;
                    }
                }
                String csvLine;
                while ((csvLine = csvQueue.poll()) != null) {
                    if (csvWriter != null) {
                        csvWriter.println(csvLine);
                        written++;
                    }
                }

                // Periodic flush
                if (written > 0 || (now - lastFlush) >= FLUSH_INTERVAL_MS) {
                    if (writer != null) writer.flush();
                    if (csvWriter != null) csvWriter.flush();
                    lastFlush = now;
                }

                // Sleep чтобы не жрать CPU (но быстро реагировать)
                Thread.sleep(Math.min(FLUSH_INTERVAL_MS, 50));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Throwable t) {
                // Не даём потоку умереть — продолжаем работать
                try { Thread.sleep(100); } catch (InterruptedException ie) { break; }
            }
        }
        // Final flush
        try {
            if (writer != null) {
                String line;
                while ((line = logQueue.poll()) != null) writer.println(line);
                writer.flush();
            }
            if (csvWriter != null) {
                String line;
                while ((line = csvQueue.poll()) != null) csvWriter.println(line);
                csvWriter.flush();
            }
        } catch (Throwable ignored) {}
    }

    /** Ротация лога: если файл > MAX_LOG_SIZE_BYTES, переименовать в .old. */
    private static void rotateIfNeeded(Path file, Path oldFile) {
        try {
            if (!Files.exists(file)) return;
            long size = Files.size(file);
            if (size > MAX_LOG_SIZE_BYTES) {
                Files.deleteIfExists(oldFile);
                Files.move(file, oldFile);
            }
        } catch (Throwable ignored) {}
    }

    /** Корректное закрытие логгера. */
    public static synchronized void close() {
        // Пишем summary перед закрытием
        writeSummary();

        running.set(false);
        if (writerThread != null) {
            try {
                writerThread.interrupt();
                writerThread.join(1000);
            } catch (Throwable ignored) {}
            writerThread = null;
        }
        if (writer != null) {
            try {
                logRawInternal("--- KillAura Debug Log closed ---");
                writer.flush();
                writer.close();
            } catch (Throwable ignored) {}
            writer = null;
        }
        if (csvWriter != null) {
            try { csvWriter.close(); } catch (Throwable ignored) {}
            csvWriter = null;
        }
    }

    /** Пишет summary сессии (metrics). */
    private static void writeSummary() {
        try {
            long sessionDuration = System.currentTimeMillis() - sessionStartTime;
            long seconds = sessionDuration / 1000;

            StringBuilder sb = new StringBuilder();
            sb.append("\n========== SESSION SUMMARY ==========\n");
            sb.append(String.format("Duration: %ds (%.1f min)%n", seconds, seconds / 60.0));
            sb.append(String.format("Total log lines: %d%n", totalLogLines.get()));
            sb.append(String.format("Dropped logs (OOM protection): %d%n", droppedLogs.get()));
            sb.append(String.format("Ticks logged: %d%n", tickCount.get()));
            sb.append(String.format("Attacks: %d%n", attackCount.get()));
            sb.append(String.format("Knockbacks: %d%n", knockbackCount.get()));
            sb.append(String.format("Rubberbands: %d%n", rubberbandCount.get()));
            sb.append(String.format("Attack skips: %d%n", skipCount.get()));
            if (attackCount.get() > 0) {
                double ratio = (double) rubberbandCount.get() / attackCount.get();
                sb.append(String.format("Rubberband/Attack ratio: %.2f%n", ratio));
            }
            sb.append("=====================================\n");

            logQueue.offer(sb.toString());
        } catch (Throwable ignored) {}
    }

    // ─── Управление логгером ──────────────────────────────────

    public static void setEnabled(boolean e) { enabled = e; }
    public static boolean isEnabled()        { return enabled; }

    public static void setVerbosity(int v) {
        int newVerbosity = Math.max(0, Math.min(3, v));
        boolean wantCsv = (newVerbosity >= 3);
        boolean wantMainLog = (newVerbosity < 3); // TRACE → не дублируем в main log

        if (newVerbosity != verbosity || wantCsv != csvEnabled || wantMainLog != logToMainLog) {
            verbosity = newVerbosity;
            csvEnabled = wantCsv;
            logToMainLog = wantMainLog;

            log("Verbosity set to " + verbosityName(verbosity)
                    + (csvEnabled ? " (CSV enabled)" : "")
                    + (logToMainLog ? "" : " (main log spam OFF)"));

            // Инициализируем CSV writer через общий метод
            initCsvIfNeeded();
        }
    }
    public static int getVerbosity() { return verbosity; }

    public static String verbosityName(int v) {
        return switch (v) {
            case 0 -> "OFF";
            case 1 -> "BASIC";
            case 2 -> "DETAIL";
            case 3 -> "TRACE";
            default -> "UNKNOWN";
        };
    }

    // ─── Основные методы логирования ──────────────────────────

    public static void log(String msg) {
        if (!enabled || verbosity < 1) return;
        enqueue(msg);
    }

    public static void detail(String msg) {
        if (!enabled || verbosity < 2) return;
        enqueue(msg);
    }

    public static void trace(String msg) {
        if (!enabled || verbosity < 3) return;
        enqueue(msg);
    }

    /** Внутренний метод — ставит строку в очередь.
     *  OOM protection: если очередь переполнена (> MAX_QUEUE_SIZE),
     *  дропаем лог и инкрементируем счётчик droppedLogs. */
    private static void enqueue(String msg) {
        // OOM protection — проверяем размер очереди
        if (logQueue.size() >= MAX_QUEUE_SIZE) {
            droppedLogs.incrementAndGet();
            return;  // дропаем лог, чтобы не забить память
        }

        String line = formatLine(msg);
        logQueue.offer(line);
        totalLogLines.incrementAndGet();

        // Ring buffer для контекста ошибок (lock-free ConcurrentLinkedDeque)
        ringBuffer.addLast(line);
        while (ringBuffer.size() > RING_BUFFER_SIZE) {
            ringBuffer.pollFirst();
        }

        // Дублируем в основной лог (если включено — не на TRACE)
        if (logToMainLog) {
            Logger.info("[KillAura] " + msg);
        }
    }

    /** Внутренний метод без ring buffer и metrics (для системных сообщений). */
    private static void logRawInternal(String msg) {
        if (logQueue.size() >= MAX_QUEUE_SIZE) {
            droppedLogs.incrementAndGet();
            return;
        }
        String line = formatLine(msg);
        logQueue.offer(line);
        totalLogLines.incrementAndGet();
    }

    /** Форматирует строку с timestamp. */
    private static String formatLine(String msg) {
        return "[" + getTimestamp() + "] " + msg;
    }

    /**
     * Получить timestamp (кеш по времени, не по тику).
     *
     * <p><b>Исправление критического бага:</b> Раньше кеш привязывался к
     * {@code tickCount}, который инкрементируется только в
     * {@link #logTickState(int, ClientPlayerEntity, float, float, float, float,
     * boolean, boolean, LivingEntity, double, boolean, boolean, String, int)}.
     * При verbosity &lt; 3 (BASIC/DETAIL) этот метод не вызывается,
     * tickCount остаётся 0, и cachedTimestamp обновлялся только один раз
     * за сессию — все логи писали одно и то же время.</p>
     *
     * <p>Теперь кеш обновляется по реальному времени: каждые 50мс
     * (≈ 1 игровой тик). Это работает на любом уровне verbosity.</p>
     */
    private static String getTimestamp() {
        long now = System.currentTimeMillis();
        // Обновляем кеш раз в 50мс (1 тик)
        if (now - cachedTimestampMs >= 50 || cachedTimestamp.isEmpty()) {
            cachedTimestamp = TS_FORMATTER.format(Instant.now());
            cachedTimestampMs = now;
        }
        return cachedTimestamp;
    }

    // ─── Специализированные логгеры ───────────────────────────

    public static void logStateChange(boolean enabled) {
        log("=== KillAura " + (enabled ? "ENABLED" : "DISABLED") + " ===");
    }

    public static void logTarget(LivingEntity target, String reason) {
        if (target == null) {
            detail("Target: none (" + reason + ")");
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        double dist = (mc.player != null) ? mc.player.distanceTo(target) : -1;
        detail(String.format("Target: %s [hp=%.1f, dist=%.2f, pos=(%.2f,%.2f,%.2f)] (%s)",
                target.getName().getString(),
                target.getHealth(),
                dist,
                target.getX(), target.getY(), target.getZ(),
                reason));
    }

    public static void logTargetSwitch(LivingEntity old, LivingEntity neu) {
        String oldName = (old != null) ? old.getName().getString() : "none";
        String newName = (neu != null) ? neu.getName().getString() : "none";
        log("Target switch: " + oldName + " -> " + newName);
    }

    public static void logRotationRequest(float yaw, float pitch, boolean silent) {
        trace(String.format("Rotation request: y=%.2f p=%.2f silent=%b",
                yaw, pitch, silent));
    }

    public static void logRotationApplied(float yaw, float pitch, float gcd) {
        trace(String.format("Rotation applied: y=%.2f p=%.2f (gcd=%.6f)",
                yaw, pitch, gcd));
    }

    public static void logAttack(LivingEntity target, float cooldown, float dist, boolean paused) {
        if (target == null) return;
        attackCount.incrementAndGet();
        log(String.format("ATTACK target=%s cooldown=%.2f dist=%.2f paused=%b",
                target.getName().getString(),
                cooldown,
                dist,
                paused));
    }

    public static void logAttackSkip(String reason) {
        skipCount.incrementAndGet();
        detail("Attack skipped: " + reason);
    }

    public static void logKnockback(double vx, double vy, double vz, int pauseTicks) {
        knockbackCount.incrementAndGet();
        log(String.format("KNOCKBACK detected: v=(%.3f, %.3f, %.3f) |v|=%.3f — pausing %d ticks",
                vx, vy, vz, Math.sqrt(vx*vx+vy*vy+vz*vz), pauseTicks));
    }

    public static void logRubberband(String reason) {
        rubberbandCount.incrementAndGet();
        log("RUBBERBAND: " + reason + " — pausing");
    }

    public static void logPause(int remainingTicks, String reason) {
        detail("Paused: " + remainingTicks + " ticks left (" + reason + ")");
    }

    public static void logResume() {
        log("Resumed after pause");
    }

    public static void logError(String msg, Throwable t) {
        log("ERROR: " + msg);
        // Dump ring buffer для контекста ошибки
        dumpRingBuffer();
        if (t != null) {
            log("  exception: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            for (StackTraceElement el : t.getStackTrace()) {
                logRawInternal("    at " + el);
            }
        }
    }

    /** Dump ring buffer'а в лог (для контекста ошибок).
     *  ConcurrentLinkedDeque — итерация без блокировок. */
    private static void dumpRingBuffer() {
        logRawInternal("--- RING BUFFER DUMP (last " + RING_BUFFER_SIZE + " lines) ---");
        for (String line : ringBuffer) {
            logQueue.offer(line);
        }
        logRawInternal("--- END RING BUFFER ---");
    }

    // ─── Per-tick state logging (TRACE) ───────────────────────

    /**
     * Логирует полное состояние боевого тика (TRACE level).
     * Оптимизировано: вся форматирование в одной операции.
     */
    public static void logTickState(int tick, ClientPlayerEntity player,
                                    float serverYaw, float serverPitch,
                                    float desiredYaw, float desiredPitch,
                                    boolean sprint, boolean onGround,
                                    LivingEntity target, double targetDist,
                                    boolean attackPlanned, boolean paused,
                                    String pauseReason, int pauseTicksLeft) {
        if (!enabled || verbosity < 3) return;
        if (player == null) return;
        tickCount.incrementAndGet();

        Vec3d pos = player.getPos();
        Vec3d vel = player.getVelocity();
        float rotDelta = (float) Math.sqrt(
                Math.pow(net.minecraft.util.math.MathHelper.wrapDegrees(serverYaw - desiredYaw), 2) +
                Math.pow(serverPitch - desiredPitch, 2));
        String targetName = (target != null) ? target.getName().getString() : "none";
        float targetHp = (target != null) ? target.getHealth() : -1;

        trace(String.format(
                "TICK %d | pos=(%.2f,%.2f,%.2f) vel=(%.3f,%.3f,%.3f) |v|=%.3f | " +
                "serverRot=(%.1f,%.1f) desiredRot=(%.1f,%.1f) rotDelta=%.1f° | " +
                "sprint=%b onGround=%b | target=%s dist=%.2f hp=%.1f | " +
                "attack=%b paused=%b (%s, %d left)",
                tick,
                pos.x, pos.y, pos.z,
                vel.x, vel.y, vel.z, vel.length(),
                serverYaw, serverPitch,
                desiredYaw, desiredPitch, rotDelta,
                sprint, onGround,
                targetName, targetDist, targetHp,
                attackPlanned, paused, pauseReason, pauseTicksLeft));

        // CSV dump (тоже через queue)
        if (csvEnabled) {
            csvQueue.offer(String.format(
                    "%d,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.2f,%.2f,%.2f,%.2f,%.2f,%b,%b,%s,%.4f,%.2f,%b,%b,%s,%d",
                    tick, System.currentTimeMillis(),
                    pos.x, pos.y, pos.z,
                    vel.x, vel.y, vel.z,
                    serverYaw, serverPitch,
                    desiredYaw, desiredPitch, rotDelta,
                    sprint, onGround,
                    targetName, targetDist, targetHp,
                    attackPlanned, paused, pauseReason, pauseTicksLeft));
        }
    }

    public static void logPacketSent(String packetType, String details) {
        detail(String.format("PACKET OUT: %s %s", packetType, details));
    }

    public static void logPacketReceived(String packetType, String details) {
        detail(String.format("PACKET IN: %s %s", packetType, details));
    }

    public static void logSprintChange(boolean wasSprinting, boolean nowSprinting, String context) {
        if (wasSprinting != nowSprinting) {
            detail(String.format("SPRINT: %b -> %b (%s)", wasSprinting, nowSprinting, context));
        }
    }

    public static void logRotationCheck(float serverYaw, float desiredYaw,
                                        float serverPitch, float desiredPitch,
                                        double angleDelta, double threshold,
                                        boolean passed) {
        trace(String.format("ROT CHECK: delta=%.1f° threshold=%.1f° %s",
                angleDelta, threshold, passed ? "PASS" : "FAIL"));
    }

    public static void logVelocityCheck(double velocityMag, double threshold, boolean stable) {
        trace(String.format("VEL CHECK: |v|=%.3f threshold=%.3f %s",
                velocityMag, threshold, stable ? "STABLE" : "UNSTABLE"));
    }

    public static void logGracePeriod(int graceTicksLeft) {
        detail("Post-pause grace: " + graceTicksLeft + " ticks left");
    }

    // ─── Metrics API ──────────────────────────────────────────

    public static long getAttackCount() { return attackCount.get(); }
    public static long getRubberbandCount() { return rubberbandCount.get(); }
    public static long getKnockbackCount() { return knockbackCount.get(); }
    public static long getSkipCount() { return skipCount.get(); }
    public static long getTickCount() { return tickCount.get(); }
    public static long getTotalLogLines() { return totalLogLines.get(); }
    public static long getDroppedLogs() { return droppedLogs.get(); }

    /** Сброс metrics (для новой сессии). */
    public static void resetMetrics() {
        attackCount.set(0);
        rubberbandCount.set(0);
        knockbackCount.set(0);
        skipCount.set(0);
        tickCount.set(0);
        totalLogLines.set(0);
        droppedLogs.set(0);
        sessionStartTime = System.currentTimeMillis();
    }

    /** Принудительный flush (для отладки). */
    public static void flush() {
        if (writer != null) writer.flush();
        if (csvWriter != null) csvWriter.flush();
    }

    // ─── Утилиты ──────────────────────────────────────────────

    private static String safeMcVersion() {
        try {
            return MinecraftClient.getInstance().getGameVersion();
        } catch (Throwable t) {
            return "1.21.4";
        }
    }
}
