package dev.cheat.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Утилита для отправки сообщений в чат игрока.
 *
 * <p>Каркас использует префикс {@code [Cheat]} синим цветом, тело — серым
 * или красным при ошибке.</p>
 */
public final class ChatUtil {

    private static final String PREFIX = "§9[Cheat]§r ";

    private ChatUtil() {}

    public static void send(String msg) {
        sendRaw(PREFIX + "§7" + msg);
    }

    public static void info(String msg)    { sendRaw(PREFIX + "§7" + msg); }
    public static void success(String msg) { sendRaw(PREFIX + "§a" + msg); }
    public static void warn(String msg)    { sendRaw(PREFIX + "§e" + msg); }
    public static void error(String msg)   { sendRaw(PREFIX + "§c" + msg); }

    public static void sendRaw(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.inGameHud == null) return;
        try {
            MutableText t = Text.literal(msg);
            mc.inGameHud.getChatHud().addMessage(t);
        } catch (Throwable ignored) {}
    }

    public static void send(Text text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.inGameHud == null) return;
        try {
            MutableText prefix = Text.literal("[Cheat] ").formatted(Formatting.BLUE);
            mc.inGameHud.getChatHud().addMessage(prefix.append(text));
        } catch (Throwable ignored) {}
    }
}
