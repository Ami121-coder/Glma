package dev.cheat.render.buffer;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;

/**
 * Утилита stencil-буфера для GUI-масок.
 *
 * <p>Типичный сценарий: {@code scissors} с закруглёнными углами, обрезка
 * скролл-контента, маска для glow-эффекта.</p>
 *
 * <p><b>Пример:</b></p>
 * <pre>
 *   StencilUtil.beginStencil();
 *   // рисуем форму-маску (закруглённый прямоугольник)
 *   Render2D.roundedRect(ctx, x, y, w, h, 8, 0xFFFFFFFF);
 *   StencilUtil.useStencil();
 *
 *   // рисуем контент — он обрежется по форме
 *   ctx.drawText(...);
 *
 *   StencilUtil.endStencil();
 * </pre>
 *
 * <p><b>Важно:</b> stencil-операции должны выполняться в одном {@code RenderSystem}
 * batch'е — без вызова {@code VertexConsumerProvider.draw()} между begin и use.</p>
 */
public final class StencilUtil {

    private StencilUtil() {}

    /**
     * Начинает запись в stencil-буфер.
     * После вызова — рисуйте форму-маску. Записанное заменит stencil.
     */
    public static void beginStencil() {
        RenderSystem.enableDepthTest();
        // 1) Очистить stencil-бит для текущего viewport (только stencil, без depth/color)
        GL11.glClearStencil(0);
        GL11.glClear(GL11.GL_STENCIL_BUFFER_BIT);
        // 2) Разрешить запись в stencil
        GL11.glEnable(GL11.GL_STENCIL_TEST);
        GL11.glStencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_REPLACE);
        GL11.glStencilFunc(GL11.GL_ALWAYS, 1, 0xFF);
        GL11.glStencilMask(0xFF);
        // 3) Запретить запись в color buffer — маску рисуем только в stencil
        GlStateManager._colorMask(false, false, false, false);
        GlStateManager._depthMask(false);
    }

    /**
     * Переключает stencil-буфер в режим «тестировать, не писать».
     * Теперь весь последующий рендер пройдёт только там, где stencil=1.
     */
    public static void useStencil() {
        GlStateManager._colorMask(true, true, true, true);
        GlStateManager._depthMask(true);
        GL11.glStencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
        GL11.glStencilFunc(GL11.GL_EQUAL, 1, 0xFF);
        GL11.glStencilMask(0x00);
    }

    /** Переключает в режим «рисовать только там, где stencil=0» — обратная маска. */
    public static void useInverseStencil() {
        GlStateManager._colorMask(true, true, true, true);
        GlStateManager._depthMask(true);
        GL11.glStencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
        GL11.glStencilFunc(GL11.GL_NOTEQUAL, 1, 0xFF);
        GL11.glStencilMask(0x00);
    }

    /** Завершает stencil-режим, отключает stencil test. */
    public static void endStencil() {
        GL11.glDisable(GL11.GL_STENCIL_TEST);
        GL11.glStencilMask(0xFF);
        GlStateManager._colorMask(true, true, true, true);
        GlStateManager._depthMask(true);
    }
}
