package dev.cheat.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.cheat.render.shader.CustomRenderLayers;
import dev.cheat.render.shader.ShaderManager;
import dev.cheat.util.Logger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.Uniform;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;
import org.joml.Matrix4f;

/**
 * Рендер размытия для красивых фонов ClickGUI.
 *
 * <p>Алгоритм (однопроходный, упрощённый):</p>
 * <ol>
 *   <li>Получаем текущий content framebuffer (то, что уже отрисовано в GUI)</li>
 *   <li>Привязываем его как {@code Sampler0}</li>
 *   <li>Рисуем quad с BLUR-шейдером — он сэмплирует текстуру и смазывает</li>
 * </ol>
 *
 * <p><b>Важно:</b> это упрощённая версия. Для качественного размытия нужен
 * ping-pong между двумя framebuffer'ами с разделением на H/V проходы.
 * Каркас оставляет точку расширения.</p>
 *
 * <p><b>Использование:</b></p>
 * <pre>
 *   BlurRenderer.beginRegion(ctx, x, y, w, h, 8, 0.7f);
 *   // ... рисуем контент поверх размытого фона
 *   BlurRenderer.endRegion();
 * </pre>
 */
public final class BlurRenderer {

    private BlurRenderer() {}

    private static boolean initialized = false;
    private static int    lastWidth  = 0;
    private static int    lastHeight = 0;

    /**
     * Рисует размытый квадрат. Должен вызываться ДО другого контента
     * в этой области (фактически — поверх уже отрисованного).
     *
     * @param radius радиус размытия в текселях (1-20 — разумный диапазон)
     */
    public static void drawBlurredQuad(DrawContext ctx, float x, float y, float w, float h,
                                       float radius) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer mainFb = mc.getFramebuffer();

        if (mainFb == null) return;

        ShaderProgram program = ShaderManager.get(ShaderManager.BLUR);
        if (program == null) {
            // Fallback: тёмный полупрозрачный прямоугольник
            ctx.fill((int) x, (int) y, (int) (x + w), (int) (y + h), 0x80000000);
            return;
        }

        // Привязать основной framebuffer как текстуру Sampler0
        // В 1.21.4 Framebuffer.getColorAttachment() возвращает GL texture id
        int texId = mainFb.getColorAttachment();
        int texWidth  = mainFb.textureWidth;
        int texHeight = mainFb.textureHeight;

        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(texId);

        // Задаём uniform'ы
        Uniform texel = program.getUniform("u_TexelSize");
        Uniform rad   = program.getUniform("u_BlurRadius");
        if (texel != null) texel.set(1f / texWidth, 1f / texHeight);
        if (rad   != null) rad.set(radius);

        // UV в текстуре — нужно перевести экранные координаты в [0,1]
        // В GUI используется scaled coordinates, в то время как framebuffer
        // в реальном разрешении. Привязка через RenderSystem.setShaderTexture(0, texId)
        // плюс задание UV вручную — стандартный приём.
        drawBlurQuad(ctx, x, y, w, h, texWidth, texHeight, mc.getWindow().getScaledWidth(),
                mc.getWindow().getScaledHeight());

        RenderSystem.bindTexture(0);
    }

    /**
     * Рисует quad с BLUR RenderLayer и правильно посчитанными UV.
     */
    private static void drawBlurQuad(DrawContext ctx, float x, float y, float w, float h,
                                     int texW, int texH, int screenW, int screenH) {
        // Прямой Tessellator-рендер — нужно контролировать UV точно.
        var tessellator = net.minecraft.client.render.Tessellator.getInstance();
        var buf = tessellator.begin(net.minecraft.client.render.VertexFormat.DrawMode.QUADS,
                net.minecraft.client.render.VertexFormats.POSITION_TEXTURE);

        Matrix4f matrix = ctx.getMatrices().peek().getPositionMatrix();

        // UV: переводим экранные координаты в [0,1] относительно framebuffer
        // (framebuffer обычно = window size, не scaled)
        double scaleX = (double) texW / (double) screenW;
        double scaleY = (double) texH / (double) screenH;
        // Но в GUI у нас scaled-координаты. Корректнее было бы использовать framebuffer viewport,
        // но упрощаем: просто используем pixelRatio из окна
        // TODO: для корректной поддержки GUI scale > 1 нужно использовать actual framebuffer size
        float u0 = x / (float) screenW;
        float u1 = (x + w) / (float) screenW;
        float v0 = y / (float) screenH;
        float v1 = (y + h) / (float) screenH;

        buf.vertex(matrix, x,     y,     0).texture(u0, v0);
        buf.vertex(matrix, x,     y + h, 0).texture(u0, v1);
        buf.vertex(matrix, x + w, y + h, 0).texture(u1, v1);
        buf.vertex(matrix, x + w, y,     0).texture(u1, v0);

        var baked = buf.endNullable();
        if (baked != null) {
            CustomRenderLayers.BLUR.startDrawing();
            net.minecraft.client.render.BufferRenderer.drawWithGlobalProgram(baked);
            CustomRenderLayers.BLUR.endDrawing();
        }
    }

    /**
     * Шаблон «blur + overlay»: рисует размытый фон, затем цветной overlay.
     * Идеально для панелей ClickGUI.
     */
    public static void beginRegion(DrawContext ctx, float x, float y, float w, float h,
                                   float radius, float blurRadius, int overlayColor) {
        // 1) Скопировать уже отрисованный контент в размытом виде
        drawBlurredQuad(ctx, x, y, w, h, blurRadius);
        // 2) Полупрозрачный overlay поверх — задаёт общий «тон» панели
        dev.cheat.render.Render2D.roundedRect(ctx, x, y, w, h, radius, overlayColor);
    }

    public static void endRegion() {
        // no-op в текущей реализации
    }

    // ─── Lifecycle hooks ─────────────────────────────────────

    public static void onResize(int newWidth, int newHeight) {
        if (newWidth != lastWidth || newHeight != lastHeight) {
            lastWidth  = newWidth;
            lastHeight = newHeight;
            // TODO: пересоздать ping-pong framebuffers когда они будут добавлены
        }
    }

    public static void init() {
        if (initialized) return;
        initialized = true;
        Logger.info("BlurRenderer initialized");
    }
}
