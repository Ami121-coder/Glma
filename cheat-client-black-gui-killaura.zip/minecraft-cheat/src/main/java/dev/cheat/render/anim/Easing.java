package dev.cheat.render.anim;

/**
 * Функции плавности (easing). Все принимают {@code t∈[0,1]} и возвращают
 * «изогнутый» прогресс. Используются в {@link Animation} для плавного
 * появления/исчезновения UI-элементов.
 */
@FunctionalInterface
public interface Easing {

    float apply(float t);

    // ─── Стандартные функции Роберта Пеннера ─────────────────

    Easing LINEAR = t -> t;

    Easing QUAD_IN  = t -> t * t;
    Easing QUAD_OUT = t -> t * (2 - t);
    Easing QUAD_IN_OUT = t -> t < 0.5f ? 2 * t * t : -1 + (4 - 2 * t) * t;

    Easing CUBIC_IN  = t -> t * t * t;
    Easing CUBIC_OUT = t -> 1 - (1 - t) * (1 - t) * (1 - t);
    Easing CUBIC_IN_OUT = t -> t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;

    Easing EXPO_IN  = t -> t == 0 ? 0 : (float) Math.pow(2, 10 * t - 10);
    Easing EXPO_OUT = t -> t == 1 ? 1 : 1 - (float) Math.pow(2, -10 * t);
    Easing EXPO_IN_OUT = t -> {
        if (t == 0) return 0;
        if (t == 1) return 1;
        return t < 0.5f
                ? (float) Math.pow(2, 20 * t - 10) / 2
                : (2 - (float) Math.pow(2, -20 * t + 10)) / 2;
    };

    /** Синус «out» — мягкое замедление, красиво для меню. */
    Easing SINE_OUT = t -> (float) Math.sin(t * Math.PI / 2);
    Easing SINE_IN  = t -> 1f - (float) Math.cos(t * Math.PI / 2);
    Easing SINE_IN_OUT = t -> -(float) (Math.cos(Math.PI * t) - 1) / 2;

    /** Back-out — лёгкий «откат» назад, отлично для кнопок/тостов. */
    Easing BACK_OUT = t -> {
        float c1 = 1.70158f;
        float c3 = c1 + 1;
        return 1 + c3 * (float) Math.pow(t - 1, 3) + c1 * (float) Math.pow(t - 1, 2);
    };

    /** Elastic-out — упругий, для пульсирующих элементов. */
    Easing ELASTIC_OUT = t -> {
        float c4 = (2 * (float) Math.PI) / 3;
        return t == 0 ? 0 : t == 1 ? 1
                : (float) Math.pow(2, -10 * t) * (float) Math.sin((t * 10 - 0.75f) * c4) + 1;
    };

    /** Bounce-out — «прыгающий» приземляющийся. */
    Easing BOUNCE_OUT = t -> {
        float n1 = 7.5625f, d1 = 2.75f;
        if (t < 1 / d1)        return n1 * t * t;
        else if (t < 2 / d1)   return n1 * (t -= 1.5f / d1) * t + 0.75f;
        else if (t < 2.5 / d1) return n1 * (t -= 2.25f / d1) * t + 0.9375f;
        else                   return n1 * (t -= 2.625f / d1) * t + 0.984375f;
    };
}
