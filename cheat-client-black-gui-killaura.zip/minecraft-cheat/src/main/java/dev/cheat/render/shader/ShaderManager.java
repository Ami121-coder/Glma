package dev.cheat.render.shader;

import dev.cheat.CheatClient;
import dev.cheat.util.Logger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderLoader;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * Менеджер шейдеров чита.
 *
 * <p>В 1.21.4 {@code ShaderProgramKeys.register()} приватный — поэтому
 * мы создаём {@link ShaderProgramKey} напрямую через конструктор record'а.</p>
 *
 * <p>{@link Identifier} для шейдера указывает на {@code assets/cheat/shaders/core/<name>.json}.
 * Minecraft ShaderLoader при загрузке сам найдёт этот JSON и подтянет
 * соответствующие {@code .vsh} и {@code .fsh}.</p>
 *
 * <p>Загрузка идёт через {@code mc.getShaderLoader().getOrCreateProgram(key)}
 * при первом обращении. Результат кэшируется.</p>
 */
public final class ShaderManager {

    /** Кастомные ShaderProgramKey мода. */
    public static final ShaderProgramKey ROUNDED_RECT = new ShaderProgramKey(
            Identifier.of(CheatClient.MOD_ID, "core/rounded"),
            VertexFormats.POSITION_COLOR,
            net.minecraft.client.gl.Defines.EMPTY);

    public static final ShaderProgramKey BLUR = new ShaderProgramKey(
            Identifier.of(CheatClient.MOD_ID, "core/blur"),
            VertexFormats.POSITION_TEXTURE,
            net.minecraft.client.gl.Defines.EMPTY);

    public static final ShaderProgramKey GRADIENT = new ShaderProgramKey(
            Identifier.of(CheatClient.MOD_ID, "core/gradient"),
            VertexFormats.POSITION_COLOR,
            net.minecraft.client.gl.Defines.EMPTY);

    public static final ShaderProgramKey GLOW = new ShaderProgramKey(
            Identifier.of(CheatClient.MOD_ID, "core/glow"),
            VertexFormats.POSITION_COLOR,
            net.minecraft.client.gl.Defines.EMPTY);

    private static final Map<ShaderProgramKey, ShaderProgram> CACHE = new HashMap<>();

    private ShaderManager() {}

    /**
     * Возвращает скомпилированный {@link ShaderProgram} для ключа.
     * Возвращает {@code null}, если шейдер недоступен (например, на старте
     * игры до первой перезагрузки ресурсов).
     */
    public static ShaderProgram get(ShaderProgramKey key) {
        if (key == null) return null;
        ShaderProgram cached = CACHE.get(key);
        if (cached != null) return cached;

        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            ShaderLoader loader = mc.getShaderLoader();
            if (loader == null) return null;

            ShaderProgram program = loader.getOrCreateProgram(key);
            if (program != null) {
                CACHE.put(key, program);
            }
            return program;
        } catch (Throwable t) {
            Logger.error("ShaderManager.get failed for " + key, t);
            return null;
        }
    }

    /** Очистить кэш (например, при reload ресурсов). */
    public static void invalidate() {
        CACHE.clear();
        Logger.info("ShaderManager: cache invalidated");
    }
}
