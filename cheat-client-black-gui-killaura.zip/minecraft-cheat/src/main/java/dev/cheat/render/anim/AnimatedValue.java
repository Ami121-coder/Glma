package dev.cheat.render.anim;

/**
 * Контракт для анимируемых значений, управляемых {@link AnimationManager}.
 *
 * <p>Реализации: {@link FloatValue}, {@link DoubleValue}, {@link ColorValue}
 * (последний — для анимации цвета). Каркас даёт {@link FloatValue} по умолчанию.</p>
 */
public interface AnimatedValue {

    /** Текущее значение. */
    float floatValue();

    /** Целевое значение, к которому анимация идёт. */
    float target();

    /** Установить новую цель. Анимация плавно пойдёт к ней. */
    void setTarget(float target);

    /** Шаг анимации. {@code dtSec} — секунды с прошлого кадра. */
    void update(float dtSec);

    /** Завершить анимацию мгновенно — приравнять value к target. */
    void complete();

    /** Анимация завершена (значение близко к target). */
    boolean isFinished();
}
