package dev.cheat.render.anim;

import dev.cheat.util.MathUtil;

/**
 * Float-анимируемое значение с заданной длительностью и easing-функцией.
 *
 * <p>Это «движковая» анимация: вместо ручных вычислений прогресса,
 * разработчик создаёт значение, задаёт цель, и {@link AnimationManager}
 * обновляет его каждый кадр с учётом delta-time.</p>
 *
 * <p>Пример:</p>
 * <pre>
 *   AnimatedValue hover = new AnimatedValue(0f, 0.18f, Easing.SINE_OUT);
 *   hover.setTarget(1f);   // начнёт плавно расти к 1
 *   float v = hover.floatValue(); // текущее значение
 * </pre>
 */
public final class FloatValue implements AnimatedValue {

    private float value;
    private float from;
    private float target;
    private float duration;     // секунды
    private float elapsed;      // секунды с момента старта
    private final Easing easing;
    private boolean finished;

    public FloatValue(float initial, float durationSec, Easing easing) {
        this.value    = initial;
        this.from     = initial;
        this.target   = initial;
        this.duration = Math.max(0.0001f, durationSec);
        this.elapsed  = duration;     // начинаем «завершённой»
        this.easing   = easing == null ? Easing.LINEAR : easing;
        this.finished = true;
    }

    @Override
    public float floatValue() {
        return value;
    }

    /** Alias for {@link #floatValue()} — удобство для чтения кода UI. */
    public float value() {
        return value;
    }

    @Override
    public float target() {
        return target;
    }

    @Override
    public void setTarget(float newTarget) {
        if (MathUtil.equalsApprox(newTarget, target, 1e-5f) && !finished) {
            return; // уже идём к этой цели
        }
        // Стартуем с текущего значения
        this.from    = this.value;
        this.target  = newTarget;
        this.elapsed = 0f;
        this.finished = false;
    }

    /** Сменить easing на лету. */
    public void setEasing(Easing e) {
        // нельзя менять final, но можно через внутренний state —
        // для простоты здесь не реализуем
    }

    /** Сменить длительность анимации (для следующего setTarget). */
    public void setDuration(float sec) {
        this.duration = Math.max(0.0001f, sec);
    }

    @Override
    public void update(float dtSec) {
        if (finished) return;
        elapsed += dtSec;
        float t = MathUtil.clamp(elapsed / duration, 0f, 1f);
        float eased = easing.apply(t);
        value = from + (target - from) * eased;
        if (t >= 1f) {
            value = target;
            finished = true;
        }
    }

    @Override
    public void complete() {
        value = target;
        elapsed = duration;
        finished = true;
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    /** Прогресс 0..1 (без easing). */
    public float progress() {
        return MathUtil.clamp(elapsed / duration, 0f, 1f);
    }

    public float duration() { return duration; }
    public Easing easing()  { return easing;  }
}
