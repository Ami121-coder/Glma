package dev.cheat.render.anim;

import dev.cheat.util.MathUtil;

/**
 * Анимация с заданной длительностью и easing-функцией.
 *
 * <p>Создаётся один раз, вызывается {@link #update(float)} каждый кадр
 * с дельта-временем (секунды). {@link #value()} возвращает текущий прогресс
 * в диапазоне {@code [0,1]} после применения easing.</p>
 *
 * <p>Двунаправленная: {@link #playForward()}, {@link #playBackward()},
 * {@link #toggle()}. {@link #isFinished()} укажет, что анимация дошла до конца.</p>
 */
public final class Animation {

    private final float  duration;
    private final Easing easing;

    private float   progress   = 0f;     // 0..1 по прямой шкале
    private float   direction  = 0f;     // +1=вперёд, -1=назад, 0=стоит
    private boolean finished   = true;

    public Animation(float durationSec, Easing easing) {
        this.duration = durationSec <= 0 ? 0.0001f : durationSec;
        this.easing   = easing == null ? Easing.LINEAR : easing;
    }

    /** Шаг анимации. {@code dtSec} — секунды с прошлого кадра. */
    public void update(float dtSec) {
        if (direction == 0f || finished) return;
        progress += direction * (dtSec / duration);
        if (progress >= 1f) { progress = 1f; finished = true; direction = 0f; }
        else if (progress <= 0f) { progress = 0f; finished = true; direction = 0f; }
    }

    public void playForward()  { direction = +1f; finished = false; }
    public void playBackward() { direction = -1f; finished = false; }

    public void toggle() {
        if (direction > 0)      playBackward();
        else if (direction < 0) playForward();
        else if (progress < 0.5f) playForward();
        else                     playBackward();
    }

    public void reset()      { progress = 0f; finished = true; direction = 0f; }
    public void completeTo(boolean forward) {
        progress  = forward ? 1f : 0f;
        finished  = true;
        direction = 0f;
    }

    /** Текущий прогресс с применением easing. */
    public float value() {
        return easing.apply(MathUtil.clamp(progress, 0f, 1f));
    }

    /** Прямой прогресс без easing (для отладки). */
    public float raw() { return progress; }

    public boolean isFinished()      { return finished; }
    public boolean isPlaying()       { return direction != 0f; }
    public boolean isForward()       { return direction > 0f; }
    public float  getDuration()      { return duration; }
    public Easing getEasing()        { return easing;   }
}
