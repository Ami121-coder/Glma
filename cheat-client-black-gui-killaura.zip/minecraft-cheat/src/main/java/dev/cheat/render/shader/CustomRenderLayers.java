package dev.cheat.render.shader;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.cheat.CheatClient;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.OptionalDouble;
import java.util.function.Function;

/**
 * Кастомные {@link RenderLayer} для красивого UI-рендера.
 *
 * <p>Каждый слой — это {@code MultiPhase} со своим шейдером и blend-режимом.
 * Слои композируются в {@link dev.cheat.render.Render2D} для рисования
 * прямоугольников с закруглением, градиентов, размытия и свечения.</p>
 *
 * <p><b>Cache:</b> слои — лёгкие (memoized через {@link Util#memoize}),
 * но буферы под ними — свои. Поэтому DrawContext.draw() нужно звать
 * аккуратно, без смешивания RenderLayer в одном буфере.</p>
 */
public final class CustomRenderLayers {

    private CustomRenderLayers() {}

    // ─── POSITION_COLOR-based слои (закругление, градиент, glow) ─────

    /** Закруглённый прямоугольник. {@code uniform vec2 u_Size; uniform float u_Radius;} */
    public static final RenderLayer ROUNDED_RECT = RenderLayer.of(
            "cheat_rounded_rect",
            VertexFormats.POSITION_COLOR,
            VertexFormat.DrawMode.QUADS,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(new RenderPhase.ShaderProgram(ShaderManager.ROUNDED_RECT))
                    .transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY)
                    .writeMaskState(RenderPhase.ALL_MASK)
                    .cull(RenderPhase.DISABLE_CULLING)
                    .build(false));

    /** Градиентный прямоугольник (4 цвета по углам). */
    public static final RenderLayer GRADIENT = RenderLayer.of(
            "cheat_gradient",
            VertexFormats.POSITION_COLOR,
            VertexFormat.DrawMode.QUADS,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(new RenderPhase.ShaderProgram(ShaderManager.GRADIENT))
                    .transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY)
                    .writeMaskState(RenderPhase.ALL_MASK)
                    .cull(RenderPhase.DISABLE_CULLING)
                    .build(false));

    /** Свечение (blur вокруг формы). */
    public static final RenderLayer GLOW = RenderLayer.of(
            "cheat_glow",
            VertexFormats.POSITION_COLOR,
            VertexFormat.DrawMode.QUADS,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(new RenderPhase.ShaderProgram(ShaderManager.GLOW))
                    .transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY)
                    .writeMaskState(RenderPhase.ALL_MASK)
                    .cull(RenderPhase.DISABLE_CULLING)
                    .build(false));

    // ─── POSITION_TEXTURE — размытие ─────────────────────────────

    /**
     * Слой для размытия: рисует fullscreen-квад с сэмплером
     * {@code Sampler0} = source framebuffer.
     */
    public static final RenderLayer BLUR = RenderLayer.of(
            "cheat_blur",
            VertexFormats.POSITION_TEXTURE,
            VertexFormat.DrawMode.QUADS,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(new RenderPhase.ShaderProgram(ShaderManager.BLUR))
                    .texture(new RenderPhase.Texture(
                            Identifier.of(CheatClient.MOD_ID, "textures/dummy.png"),
                            net.minecraft.util.TriState.FALSE,
                            false))
                    .transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY)
                    .writeMaskState(RenderPhase.ALL_MASK)
                    .cull(RenderPhase.DISABLE_CULLING)
                    .build(false));

    /** Текстурный слой для рисования кастомных иконок с alpha-блендингом. */
    public static Function<Identifier, RenderLayer> TEXTURED_ALPHA = Util.memoize(texture -> RenderLayer.of(
            "cheat_textured_alpha",
            VertexFormats.POSITION_TEXTURE_COLOR,
            VertexFormat.DrawMode.QUADS,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(new RenderPhase.ShaderProgram(ShaderProgramKeys.POSITION_TEX_COLOR))
                    .texture(new RenderPhase.Texture(texture, net.minecraft.util.TriState.FALSE, false))
                    .transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY)
                    .writeMaskState(RenderPhase.ALL_MASK)
                    .cull(RenderPhase.DISABLE_CULLING)
                    .build(false)));
}
