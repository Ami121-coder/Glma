package dev.cheat.render.anim;

import dev.cheat.Client;
import dev.cheat.event.impl.ClientTickEvent;
import dev.cheat.event.impl.Render2DEvent;
import dev.cheat.event.listener.EventHandler;
import dev.cheat.event.listener.EventListener;
import dev.cheat.util.Logger;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Менеджер delta-time анимаций.
 *
 * <p>Централизованно обновляет все {@link AnimatedValue} каждый кадр
 * (через {@link Render2DEvent}) и каждый тик (через {@link ClientTickEvent}).</p>
 *
 * <p><b>Delta-time:</b> прошедшее время между кадрами рассчитывается из
 * {@link Render2DEvent#tickDelta()} и {@link ClientTickEvent}. Анимации
 * остаются плавными независимо от FPS.</p>
 *
 * <p>Каждая анимация принадлежит какому-то компоненту/модулю. Чтобы
 * анимация не утекала, владелец вызывает {@link #remove(AnimatedValue)}
 * при уничтожении компонента.</p>
 *
 * <p>API:</p>
 * <ul>
 *   <li>{@link #add(AnimatedValue)} — зарегистрировать</li>
 *   <li>{@link #remove(AnimatedValue)} — снять</li>
 *   <li>{@link #create(float, float, Easing)} — shortcut для {@link FloatValue}</li>
 *   <li>{@link #dt()} — последнее delta-time (для других систем)</li>
 * </ul>
 */
public final class AnimationManager implements EventListener {

    private final CopyOnWriteArrayList<AnimatedValue> values = new CopyOnWriteArrayList<>();

    /** Последнее рассчитанное delta-time в секундах. */
    private volatile float lastDt = 0.016f;

    /** Последнее время (мс) — для расчёта dt через System.nanoTime(). */
    private volatile long lastNanos = 0L;

    public AnimationManager() {
        // ВНИМАНИЕ: НЕ вызываем Client.get() здесь! Client ещё не создан
        // (мы внутри Client.<init>). Подписка выполняется явно из Core.bootstrap()
        // после завершения Client.create().
        lastNanos = System.nanoTime();
    }

    /**
     * Подписать менеджер на события. Вызывается из {@code Core.bootstrap()}
     * после того, как {@link Client} создан.
     */
    public void subscribeSelf() {
        try {
            Client.get().eventManager().subscribe(this);
        } catch (Throwable t) {
            Logger.error("AnimationManager.subscribeSelf failed", t);
        }
    }

    // ─── Регистрация ──────────────────────────────────────────

    public <T extends AnimatedValue> T add(T value) {
        if (value == null) return null;
        if (!values.contains(value)) values.add(value);
        return value;
    }

    public void remove(AnimatedValue value) {
        values.remove(value);
    }

    /** Создать и зарегистрировать FloatValue. */
    public FloatValue create(float initial, float durationSec, Easing easing) {
        return add(new FloatValue(initial, durationSec, easing));
    }

    public int size() { return values.size(); }

    public float dt() { return lastDt; }

    // ─── Update hooks ─────────────────────────────────────────

    /**
     * Главный update — на каждый кадр рендера (частота = FPS).
     * Идеально для визуальных анимаций (hover, slide, fade).
     */
    @EventHandler(priority = 20)
    public void onRender2D(Render2DEvent e) {
        // Считаем delta-time из наносекунд
        long now = System.nanoTime();
        float dt = (now - lastNanos) / 1_000_000_000f;
        lastNanos = now;
        // Защита от больших скачков (пауза окна и т.п.)
        if (dt > 0.1f) dt = 0.1f;
        if (dt < 0.0001f) dt = 0.0001f;
        lastDt = dt;

        for (AnimatedValue v : values) {
            try {
                v.update(dt);
            } catch (Throwable t) {
                Logger.error("AnimationManager.update error", t);
            }
        }
    }

    /**
     * Тиковый update — 20 раз/сек. Используется для игровой логики
     * (например, alpha-pulse для ESP-целей, sync с TPS).
     */
    @EventHandler(priority = 20)
    public void onTick(ClientTickEvent e) {
        if (!e.isPre()) return;
        // tick-based анимации можно добавить здесь, но каркас оставляет
        // только frame-based. Tick только для расчёта dt-фолла.
    }
}
