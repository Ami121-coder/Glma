#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec2 u_Size;          // ширина/высота прямоугольника в пикселях
uniform float u_Radius;       // радиус закругления в пикселях

out vec4 v_Color;
out vec2 v_UV;                // UV в пространстве прямоугольника [0..1]
out vec2 v_PixelCoord;        // координаты в пикселях относительно центра

void main() {
    vec4 pos = ProjMat * ModelViewMat * vec4(Position, 1.0);
    gl_Position = pos;

    v_Color = Color;

    // UV — для передачи во fragment. Position — это экранные пиксели
    // (DrawContext использует MatrixStack с GUI-матрицей).
    // Мы не знаем точную позицию — её передаёт vertex как абсолютные координаты.
    // UV вычисляем через gl_VertexID — четыре вершины квад'а.
    // vertex 0: (0,0)  1: (1,0)  2: (1,1)  3: (0,1)
    int idx = gl_VertexID % 4;
    vec2 uv = vec2(float(idx == 1 || idx == 2), float(idx == 2 || idx == 3));
    v_UV = uv;
    v_PixelCoord = uv * u_Size;
}
