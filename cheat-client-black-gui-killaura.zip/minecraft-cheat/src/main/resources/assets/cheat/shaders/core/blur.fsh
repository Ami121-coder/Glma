#version 150

in vec2 v_TexCoord;

uniform sampler2D Sampler0;
uniform vec2  u_TexelSize;     // 1.0 / screen_size
uniform float u_BlurRadius;

out vec4 fragColor;

/**
 * Двупроходный гауссов блюр в один pass (упрощённый):
 * сэмплирует 9 точек вдоль двух диагоналей для имитации 2D-размытия.
 *
 * Для качественного размытия рекомендуется использовать ping-pong
 * между framebuffer'ами (см. BlurRenderer).
 */
const float weights[5] = float[](
    0.227027, 0.1945946, 0.1216216, 0.054054, 0.016216
);

void main() {
    vec2 texel = u_TexelSize * u_BlurRadius;

    vec4 sum = texture(Sampler0, v_TexCoord) * weights[0];
    // По X
    sum += texture(Sampler0, v_TexCoord + vec2( 1.0,  0.0) * texel) * weights[1];
    sum += texture(Sampler0, v_TexCoord + vec2(-1.0,  0.0) * texel) * weights[1];
    sum += texture(Sampler0, v_TexCoord + vec2( 2.0,  0.0) * texel) * weights[2];
    sum += texture(Sampler0, v_TexCoord + vec2(-2.0,  0.0) * texel) * weights[2];
    sum += texture(Sampler0, v_TexCoord + vec2( 3.0,  0.0) * texel) * weights[3];
    sum += texture(Sampler0, v_TexCoord + vec2(-3.0,  0.0) * texel) * weights[3];
    sum += texture(Sampler0, v_TexCoord + vec2( 4.0,  0.0) * texel) * weights[4];
    sum += texture(Sampler0, v_TexCoord + vec2(-4.0,  0.0) * texel) * weights[4];
    // По Y
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0,  1.0) * texel) * weights[1];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0, -1.0) * texel) * weights[1];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0,  2.0) * texel) * weights[2];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0, -2.0) * texel) * weights[2];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0,  3.0) * texel) * weights[3];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0, -3.0) * texel) * weights[3];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0,  4.0) * texel) * weights[4];
    sum += texture(Sampler0, v_TexCoord + vec2( 0.0, -4.0) * texel) * weights[4];

    fragColor = sum;
}
