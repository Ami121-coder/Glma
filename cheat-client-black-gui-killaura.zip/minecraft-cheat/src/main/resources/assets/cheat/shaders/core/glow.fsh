#version 150

in vec4 v_Color;
in vec2 v_PixelCoord;

uniform vec2  u_Size;
uniform float u_Radius;
uniform float u_Spread;

out vec4 fragColor;

float roundedBoxSDF(vec2 p, vec2 halfSize, float r) {
    vec2 q = abs(p) - halfSize + vec2(r);
    return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

void main() {
    vec2 center = u_Size * 0.5;
    float dist  = roundedBoxSDF(v_PixelCoord - center, u_Size * 0.5, u_Radius);

    // Внутри формы — полный цвет. Снаружи — экспоненциальный falloff (glow).
    // -dist для sdfs — «внутри», так что берём max(dist, 0).
    float outer = max(dist, 0.0);
    float falloff = 1.0 / (1.0 + outer * outer / (u_Spread * u_Spread));

    // Внутри формы alpha = 1, плавно затухает наружу
    float inner = 1.0 - smoothstep(-1.0, 1.0, dist);
    float alpha = max(inner, falloff);

    fragColor = vec4(v_Color.rgb, v_Color.a * alpha);
}
