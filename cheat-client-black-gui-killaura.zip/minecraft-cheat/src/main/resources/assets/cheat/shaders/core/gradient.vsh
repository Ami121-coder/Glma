#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 v_Color;
out vec2 v_UV;

void main() {
    vec4 pos = ProjMat * ModelViewMat * vec4(Position, 1.0);
    gl_Position = pos;
    v_Color = Color;

    int idx = gl_VertexID % 4;
    v_UV = vec2(float(idx == 1 || idx == 2), float(idx == 2 || idx == 3));
}
