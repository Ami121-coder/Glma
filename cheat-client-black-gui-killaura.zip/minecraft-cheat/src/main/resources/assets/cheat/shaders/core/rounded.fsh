#version 150

in vec4 v_Color;
in vec2 v_UV;
in vec2 v_PixelCoord;

uniform vec2  u_Size;
uniform float u_Radius;
uniform float u_EdgeSoftness;

out vec4 fragColor;

/**
 * Signed-distance-field для закруглённого прямоугольника.
 * Возвращает отрицательное значение внутри, положительное снаружи.
 *
 * Формула: длина макс(0, |p - half_size + r|) - r, где half_size = size/2.
 */
float roundedBoxSDF(vec2 p, vec2 halfSize, float r) {
    vec2 q = abs(p) - halfSize + vec2(r);
    return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

void main() {
    // Центр прямоугольника
    vec2 center = u_Size * 0.5;
    float dist  = roundedBoxSDF(v_PixelCoord - center, u_Size * 0.5, u_Radius);

    // Anti-aliasing через smoothstep по краю
    float alpha = 1.0 - smoothstep(-u_EdgeSoftness, u_EdgeSoftness, dist);

    if (alpha <= 0.001) discard;

    fragColor = vec4(v_Color.rgb, v_Color.a * alpha);
}
