#version 150

in vec4 v_Color;
in vec2 v_UV;

uniform vec4 u_TopLeft;
uniform vec4 u_TopRight;
uniform vec4 u_BotLeft;
uniform vec4 u_BotRight;
uniform float u_Time;

out vec4 fragColor;

void main() {
    // Билинейная интерполяция 4 цветов по углам прямоугольника
    vec4 top    = mix(u_TopLeft,  u_TopRight,  v_UV.x);
    vec4 bottom = mix(u_BotLeft,  u_BotRight,  v_UV.x);
    vec4 col    = mix(top,        bottom,      v_UV.y);

    // v_Color — общий множитель яркости/alpha, полезно для fade-in
    fragColor = col * v_Color;
}
