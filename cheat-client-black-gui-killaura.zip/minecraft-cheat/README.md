# Cheat Client — Fabric 1.21.4 (Improved)

Каркас Minecraft чита на Fabric Loader для **Minecraft 1.21.4**.
Полностью спроектированная архитектура с **системой настроек**, **автообнаружением
модулей**, **полноценным ClickGUI**, **3D-рендером** и **6 готовыми примерами модулей**.

Это улучшенная версия базового каркаса — добавлена инфраструктура для
быстрого расширения: новый модуль = один класс с `@ModuleInfo`, настройки
декларируются в конструкторе, UI-компоненты для каждого типа настроек
подхватываются автоматически.

---

## Стек

| Компонент          | Версия                              |
| ------------------ | ----------------------------------- |
| Minecraft          | 1.21.4                              |
| Yarn mappings      | 1.21.4+build.8                      |
| Fabric Loader      | 0.16.9                              |
| Fabric API         | 0.110.5+1.21.4                      |
| Fabric Loom        | 1.9-SNAPSHOT                        |
| Java               | 21 (требование 1.21.x)              |

---

## Что нового по сравнению с базовым каркасом

### 1. Система настроек (`dev.cheat.setting`)
Полноценная типизированная иерархия настроек с UI-компонентами:

| Класс                  | UI-компонент           | Описание                              |
| ---------------------- | ---------------------- | ------------------------------------- |
| `BooleanSetting`       | `BooleanToggle`        | Чекбокс (on/off)                      |
| `IntSetting`           | `SliderComponent.ForInt` | Слайдер целых чисел                 |
| `DoubleSetting`        | `SliderComponent.Double` | Слайдер вещественных               |
| `FloatSetting`         | `SliderComponent.Float`  | Слайдер (float)                    |
| `EnumSetting<T>`       | `ModeButton.FromEnum`  | Кнопка цикла по enum                  |
| `ModeSetting`          | `ModeButton.FromMode`  | Кнопка цикла по списку строк          |
| `ColorSetting`         | `ColorButton`          | Превью + hex-текст                    |
| `StringSetting`        | `StringComponent`      | Текстовое поле                        |
| `KeyBindSetting`       | `KeyBindButton`        | Listening-mode + имя GLFW-клавиши    |

Все настройки автоматически сериализуются в `cheat/config.json`.

### 2. Автообнаружение модулей
Положите класс модуля в пакет `dev.cheat.module.impl` с аннотацией `@ModuleInfo`
— `ModuleManager.autoDiscover()` найдёт его через classpath-сканирование и
зарегистрирует автоматически. Ручная регистрация тоже поддерживается.

### 3. Расширенные хуки модуля
Каждый модуль теперь получает типизированные хуки на все события —
без необходимости писать `@EventHandler`:

```java
public class MyModule extends Module {
    public MyModule() {
        settings.add(new IntSetting("Range", "Дальность", 4, 1, 8));
        settings.add(new BooleanSetting("ThroughWalls", "Сквозь стены", false));
    }

    @Override public void onTick()                          { /* логика тика */ }
    @Override public void onRender2D(Render2DEvent e)       { /* HUD-рендер */ }
    @Override public void onRender3D(Render3DEvent e)       { /* World-рендер */ }
    @Override public void onMotion(MotionEvent e)           { /* rotation spoof */ }
    @Override public void onPacketSend(PacketSendEvent<?> e){ /* перехват пакетов */ }
    @Override public void onKey(KeyEvent e)                 { /* клавиатура */ }
    @Override public void onMouse(MouseEvent e)             { /* мышь */ }
    // ... ещё 6 хуков
}
```

### 4. MouseEvent + MouseMixin
Новое событие мыши с кнопкой/действием/координатами, публикуется из `MouseMixin`.
Если отменено — Minecraft не получает клик.

### 5. Render3DEvent + WorldRendererMixin
Новый mixin публикует `Render3DEvent` после отрисовки мира. Это даёт модулям
доступ к `MatrixStack` и камере для ESP/Tracers/BlockOutline.

### 6. Render2DEvent с DrawContext
`Render2DEvent` теперь несёт `DrawContext` — модули могут рисовать в HUD без
обращения к глобальному mc.

### 7. ClickGUI с настройками
`ClickGUIScreen` автоматически заполняет фреймы кнопками модулей из
`ModuleManager.byCategory()`. Правый клик по кнопке модуля раскрывает его
настройки, для каждой — соответствующий UI-компонент.

### 8. Темы оформления
Поле `Client.theme()` хранит текущую тему (DEFAULT/DARK/LIGHT/MIDNIGHT).
Команда `.theme <name>` переключает на лету, тема сохраняется в конфиг.

### 9. ModulePriority теперь работает
`ModuleManager.all()` и `tickAll()` сортируют модули по `priority().weight()`.
Модули с `HIGHEST` выполняются раньше `LOWEST`.

### 10. Новые команды
- `.set <module> <setting> <value>` — изменить настройку из чата.
- `.set <module> list`              — список настроек модуля.
- `.set reset <module>`             — сброс настроек.
- `.modules [category]`             — сводный список модулей по категориям.
- `.theme [name]`                   — сменить тему оформления.

### 11. Type-safe парсеры аргументов
`dev.cheat.command.arg.Arguments` с готовыми парсерами:
`integer()`, `decimal()`, `bool()`, `module()`, `player()`.

### 12. EventListener без принудительного `noop()`
Маркерный интерфейс теперь имеет default-метод `noop()` — обычным слушателям
больше не нужно его переопределять. `PacketRule` остаётся `@FunctionalInterface`.

---

## Структура проекта

```
minecraft-cheat/
├── build.gradle                  # Fabric Loom, зависимости
├── settings.gradle
├── gradle.properties             # Версии и метаданные
└── src/main/
    ├── java/dev/cheat/
    │   ├── CheatClient.java      # Точка входа
    │   ├── Client.java           # Singleton + theme
    │   ├── core/                 # Core.java, ServiceLocator.java
    │   ├── manager/              # 11 менеджеров
    │   │   ├── ModuleManager          # автообнаружение, приоритеты
    │   │   ├── EventManager           # getMethods() (с унаследованными)
    │   │   ├── CommandManager         # +SettingCommand +ModulesCommand +ThemeCommand
    │   │   ├── CommandDispatcher      # без рефлексии
    │   │   ├── ConfigManager          # сохранение настроек + темы
    │   │   ├── ConfigPayload          # +settings map
    │   │   ├── PacketManager, RotationManager, FriendManager
    │   │   ├── NetworkBuffer, PacketRule, RotationTarget
    │   ├── module/                # Module + Category + ModuleInfo + ModulePriority
    │   ├── module/impl/           # примеры модулей (автообнаружение)
    │   │   ├── SprintModule           # MOVEMENT — авто-спринт
    │   │   ├── FullBrightModule       # RENDER   — максимальная яркость
    │   │   ├── NoFallModule           # PLAYER   — анти-fall damage
    │   │   ├── WatermarkModule        # HUD      — надпись в углу
    │   │   ├── ArrayListModule        # HUD      — список активных модулей
    │   │   ├── PlayerESPModule        # RENDER   — обводка игроков
    │   │   ├── ClickGUIModule         # CLIENT   — открыватель ClickGUI
    │   │   └── PanicModule            # CLIENT   — экстренное выключение
    │   ├── setting/               # НОВАЯ система настроек (9 типов + SettingGroup)
    │   ├── event/                 # Event, Cancellable, listener/, impl/
    │   │   └── impl/MouseEvent.java    # НОВОЕ событие
    │   ├── command/               # Command + CommandContext + impl/ + arg/
    │   │   ├── arg/                    # 5 парсеров аргументов
    │   │   └── impl/SettingCommand, ModulesCommand, ThemeCommand  # НОВЫЕ
    │   ├── mixin/                 # 9 миксинов (включая НОВЫЙ WorldRendererMixin)
    │   ├── ui/                    # ClickGUIScreen + theme/ + component/
    │   │   ├── component/ModuleButton       # кнопка с раскрытием настроек
    │   │   ├── component/Frame              # категория (drag&drop)
    │   │   ├── component/setting/           # 6 UI-компонентов настроек
    │   │   └── theme/Theme                  # 4 пресета
    │   ├── render/                # Render2D/3D, shaders, fonts, animations
    │   ├── config/                # Config, JsonConfig
    │   └── util/                  # ColorUtil, RenderUtil, MathUtil, Logger, ChatUtil
    └── resources/
        ├── fabric.mod.json
        ├── cheat.mixins.json      # +WorldRendererMixin
        └── assets/cheat/shaders/  # rounded/gradient/glow/blur
```

---

## Пример: добавление нового модуля

Минимальный модуль с настройкой — **1 класс, ~30 строк**:

```java
package dev.cheat.module.impl;

import dev.cheat.event.impl.MotionEvent;
import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.module.ModuleInfo;
import dev.cheat.setting.BooleanSetting;
import dev.cheat.setting.IntSetting;

@ModuleInfo(
    name        = "AutoJump",
    description = "Прыгать автоматически у препятствий",
    category    = Category.MOVEMENT,
    bind        = 0,
    enabledByDefault = false
)
public final class AutoJumpModule extends Module {

    private final IntSetting delay =
        new IntSetting("Delay", "Тиков между прыжками", 5, 0, 40);
    private final BooleanSetting sprintOnly =
        new BooleanSetting("SprintOnly", "Только в спринте", true);

    public AutoJumpModule() {
        settings.add(delay);
        settings.add(sprintOnly);
    }

    @Override
    public void onMotion(MotionEvent event) {
        if (!event.isPre() || mc.player == null) return;
        if (sprintOnly.value() && !mc.player.isSprinting()) return;
        // логика прыжка...
    }
}
```

**Всё.** Модуль будет автоматически:
1. Найден при старте через classpath-сканирование.
2. Зарегистрирован в `ModuleManager`.
3. Виден в ClickGUI в категории MOVEMENT.
4. Имел рабочий бинд через `.bind AutoJump R`.
5. Настройки `Delay` и `SprintOnly` появятся в ClickGUI как слайдер и чекбокс.
6. Настройки сохранятся в `cheat/config.json`.
7. Доступны через `.set AutoJump Delay 10`.

---

## Сборка

```bash
cd minecraft-cheat
./gradlew build
# jar появится в build/libs/cheat-client-<version>.jar
```

> **Примечание:** gradle-wrapper.jar включён в архив, но если он
> недоступен, используйте локальный `gradle 8.x`.

Для запуска в dev-режиме:
```bash
./gradlew runClient
```

---

## Команды чата

| Команда                              | Описание                              |
| ------------------------------------ | ------------------------------------- |
| `.help [cmd]`                        | Список команд или подсказка по одной  |
| `.toggle <module|list>` (`t`)        | Включить/выключить модуль             |
| `.bind <module> <key|clear|list>`    | Назначить клавишу модулю              |
| `.set <m> <s> <v|list>` (`s`)        | Изменить настройку модуля             |
| `.set reset <module>`                | Сбросить все настройки модуля         |
| `.modules [category]` (`mods`)       | Список модулей                        |
| `.theme [name]` (`th`)               | Тема оформления                       |
| `.friend add/remove/list/clear` (`f`)| Управление списком друзей             |
| `.config save|load|reload` (`cfg`)   | Сохранение/загрузка конфигурации      |

---

## Расширение каркаса

### Добавить новый тип настройки
1. Создать `MySetting extends Setting<T>` с реализацией `serialize/deserialize/type`.
2. Добавить значение `MY_TYPE` в `Setting.Type` enum.
3. Создать `MySettingComponent extends SettingComponent<MySetting>`.
4. Добавить case в `ModuleButton.componentFor()`.

### Добавить новый mixin
1. Создать класс в `dev.cheat.mixin`.
2. Зарегистрировать в `cheat.mixins.json` → `"client": [...]`.
3. Публиковать события через `Client.get().eventManager().post(event)`.
4. Подписаться в `Module` через новый типизированный хук.

### Добавить новую команду
1. Создать класс в `dev.cheat.command.impl` extends `Command`.
2. Зарегистрировать в `CommandManager.registerDefaults()`.
3. Парсеры аргументов — `Arguments.integer()`, `Arguments.module()` и т.д.

---

## Архитектурные принципы

1. **Миксины только публикуют события.** Вся логика — в менеджерах и модулях.
2. **Аннотация-driven ивент-шина.** `@EventHandler` + тип параметра = подписка.
3. **Модуль автоматически подписывается/отписывается** в `enable()/disable()`.
4. **Точные типы событий.** Шина не использует иерархию классов (только `getMethods()` для наследования).
5. **PacketRule как `@FunctionalInterface`.** Декларативный перехват пакетов.
6. **Одноразовые rotation targets.** Модули пере-запрашивают каждый тик.
7. **Atomic config writes.** Запись через `*.tmp + ATOMIC_MOVE`.
8. **ModulePriority сортирует.** Меньше weight = раньше в `tickAll()`.

---

## Известные ограничения

- `MotionEvent.modifyPosition` — TODO (небезопасно менять позицию игрока напрямую).
- `ColorButton` — упрощён: циклический сдвиг Hue, нет полноценного color picker.
- `PlayerESPModule` — без frustum-culling, без interpolation внутри бокса.
- Classpath-сканирование в jar-режиме обходит только JAR-файлы classpath, не nested-jars.
- Нет unit-тестов — каркас предполагает ручное тестирование в dev-сборке MC.

---

## Лицензия

MIT — см. `LICENSE`.
