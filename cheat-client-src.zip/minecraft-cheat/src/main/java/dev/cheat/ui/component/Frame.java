package dev.cheat.ui.component;

import dev.cheat.module.Category;
import dev.cheat.render.Render2D;
import dev.cheat.render.anim.Animation;
import dev.cheat.render.anim.Easing;
import dev.cheat.ui.theme.Theme;
import dev.cheat.util.ColorUtil;
import dev.cheat.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Фрейм — вертикальный аккордеон для одной категории модулей.
 *
 * <p>Использует новый {@link Render2D#roundedRect} для сглаженных углов,
 * анимацию collapse/expand и градиентный заголовок.</p>
 */
public class Frame extends Component {

    private final Category category;
    private final List<Component> children = new ArrayList<>();

    private final Animation collapseAnim = new Animation(0.32f, Easing.CUBIC_IN_OUT);
    private boolean collapsed = false;
    private boolean dragging   = false;
    private double dragOffsetX, dragOffsetY;

    private int expandedHeight = 0;

    public Frame(Category category, int x, int y, int width) {
        super(x, y, width, 18);
        this.category = category;
    }

    public void populate(List<Component> components) {
        children.clear();
        children.addAll(components);
        layoutChildren();
    }

    private void layoutChildren() {
        int cy = y + 18; // под заголовком
        for (Component c : children) {
            c.setX(x);
            c.setY(cy);
            c.setWidth(width);
            cy += c.getHeight();
        }
        expandedHeight = 18 + children.stream().mapToInt(Component::getHeight).sum();
        // Текущая высота = лерп между collapsed (18) и expanded
        float t = collapseAnim.value();
        this.height = (int) (18 + (expandedHeight - 18) * t);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateHover(mouseX, mouseY);
        Theme t = Theme.DEFAULT;

        // Обновляем анимацию
        collapseAnim.update(0.016f);
        if (collapsed && collapseAnim.isForward()) collapseAnim.playBackward();
        else if (!collapsed && !collapseAnim.isForward() && !collapseAnim.isFinished()) {
            // Продолжаем expansion
        } else if (!collapsed && collapseAnim.isFinished() && collapseAnim.raw() < 0.5f) {
            collapseAnim.playForward();
        }
        layoutChildren();

        // ─── Контейнер фрейма ───────────────────────────────
        float currH = this.height;
        // Glow под фреймом для эффекта парения
        Render2D.glowRect(ctx, x - 2, y - 2, width + 4, currH + 4,
                t.radius(), 2f, ColorUtil.alpha(t.shadow(), 0.4f));

        // Основной фон фрейма
        Render2D.roundedRect(ctx, x, y, width, currH, t.radius(), t.panel());

        // ─── Заголовок ──────────────────────────────────────
        // Градиентный заголовок: accent → accent2 по горизонтали
        Render2D.horizontalGradient(ctx, x, y, width, 18,
                t.accent(), t.accent2());

        // Иконка категории (пока — просто цветной квадрат)
        // TODO: заменить на реальною иконку через GlyphRenderer
        int iconColor = ColorUtil.alpha(0xFFFFFFFF, 0.85f);
        Render2D.roundedRect(ctx, x + 4, y + 4, 10, 10, 2f, iconColor);

        // Текст заголовка
        String title = category.displayName();
        RenderUtil.textSoftShadow(ctx, title,
                x + 18, y + (18 - RenderUtil.fontHeight()) / 2 + 1, 0xFFFFFFFF);

        // Индикатор свёрнутости (плавная стрелка)
        String ind = collapsed ? "▶" : "▼";
        float indAlpha = collapseAnim.value();
        int indColor = ColorUtil.alpha(0xFFFFFFFF, 0.7f);
        RenderUtil.textSoftShadow(ctx, ind,
                x + width - 12, y + (18 - RenderUtil.fontHeight()) / 2 + 1, indColor);

        // ─── Контент ────────────────────────────────────────
        if (collapseAnim.value() > 0.05f) {
            // Прозрачность children зависит от прогресса анимации
            // TODO: добавить fade через ShaderColor при отрисовке детей

            // Обрезка контента через scissors — чтобы не вылезал за пределы
            Render2D.scissors(x, y + 18, width, currH - 18);
            for (Component c : children) {
                c.render(ctx, mouseX, mouseY, delta);
            }
            Render2D.disableScissors();
        }

        // Тонкая нижняя граница
        if (collapseAnim.value() > 0.05f) {
            int borderColor = ColorUtil.alpha(t.borderGlow(), 0.2f);
            Render2D.hLine(ctx, x + 4, y + 18, width - 8, borderColor);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && isHovered(mx, my)) {
            // Клик по заголовку (верхние 18px)
            if (my < y + 18) {
                if (mx > x + width - 18) {
                    collapsed = !collapsed;
                    if (collapsed) collapseAnim.playBackward();
                    else           collapseAnim.playForward();
                } else {
                    dragging = true;
                    dragOffsetX = mx - x;
                    dragOffsetY = my - y;
                }
                return true;
            }
        }
        // Проброс детям только если раскрыт
        if (!collapsed) {
            for (Component c : children) {
                if (c.mouseClicked(mx, my, button)) return true;
            }
        }
        return false;
    }

    @Override
    public void mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            x = (int) (mx - dragOffsetX);
            y = (int) (my - dragOffsetY);
            layoutChildren();
        }
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) dragging = false;
        for (Component c : children) c.mouseReleased(mx, my, button);
        return false;
    }
}
