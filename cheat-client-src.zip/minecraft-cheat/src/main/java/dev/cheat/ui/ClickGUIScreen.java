package dev.cheat.ui;

import dev.cheat.Client;
import dev.cheat.module.Category;
import dev.cheat.ui.component.Frame;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI экран. Наследует ванильный {@link Screen}, что позволяет
 * использовать его как {@code mc.setScreen(new ClickGUIScreen())}.
 *
 * <p>Каркас инициализирует пустые фреймы по категориям. Когда разработчик
 * добавит модули, фреймы заполнятся кнопками автоматически через
 * {@link #rebuildFrames()}.</p>
 */
public final class ClickGUIScreen extends Screen {

    private static ClickGUIScreen instance;

    private final List<Frame> frames = new ArrayList<>();

    private ClickGUIScreen() {
        super(Text.literal("ClickGUI"));
    }

    public static ClickGUIScreen get() {
        if (instance == null) instance = new ClickGUIScreen();
        return instance;
    }

    @Override
    protected void init() {
        rebuildFrames();
    }

    /** Перестраивает фреймы из текущих модулей ModuleManager. */
    public void rebuildFrames() {
        frames.clear();
        if (Client.get() == null) return;

        int x = 20;
        for (Category cat : Category.values()) {
            Frame frame = new Frame(cat, x, 40, 100);
            // Реальные кнопки модулей разработчик добавит через:
            //   frame.populate(modulesByCategory(cat));
            // Каркас оставляет список пустым.
            frames.add(frame);
            x += 110;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Полупрозрачный фон
        ctx.fill(0, 0, width, height, 0x80000000);

        for (Frame f : frames) {
            f.render(ctx, mouseX, mouseY, delta);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (Frame f : frames) {
            if (f.mouseClicked(mouseX, mouseY, button)) return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        for (Frame f : frames) f.mouseDragged(mouseX, mouseY, button, dx, dy);
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (Frame f : frames) f.mouseReleased(mouseX, mouseY, button);
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
