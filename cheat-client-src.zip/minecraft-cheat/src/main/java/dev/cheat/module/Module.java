package dev.cheat.module;

import dev.cheat.Client;
import dev.cheat.event.listener.EventListener;
import dev.cheat.util.Logger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Базовый класс любого модуля.
 *
 * <p>Каркас НЕ добавляет конкретных модулей — это просто контракт:
 * каждый будущий модуль наследуется от {@code Module} и помечается
 * аннотацией {@link ModuleInfo}.</p>
 *
 * <p>Жизненный цикл:</p>
 * <ol>
 *   <li>Конструктор — инстанцируется менеджером (через рефлексию).</li>
 *   <li>{@link #onEnable()} — вызывается при включении.</li>
 *   <li>{@link #onDisable()} — вызывается при выключении.</li>
 *   <li>{@link #onTick()} — каждый клиентский тик, если включён.</li>
 *   <li>{@link #onRender2D(MatrixStack, float)} — каждый кадр HUD.</li>
 * </ol>
 *
 * <p>Модуль автоматически регистрируется как {@link EventListener}
 * при создании в {@code ModuleManager}.</p>
 */
public abstract class Module implements EventListener {

    protected final MinecraftClient mc;

    // ─── Метаданные (заполняются из @ModuleInfo) ─────────────
    private final String   name;
    private final String   description;
    private final Category category;
    private       int      bind;
    private final boolean  visibleDefault;

    // ─── Состояние ───────────────────────────────────────────
    private boolean enabled = false;
    private final long createdAt = System.currentTimeMillis();
    private long    enabledAt    = 0L;

    protected Module() {
        this.mc = MinecraftClient.getInstance();

        ModuleInfo info = getClass().getAnnotation(ModuleInfo.class);
        if (info == null) {
            throw new IllegalStateException("Module " + getClass().getName()
                    + " missing @ModuleInfo");
        }
        this.name          = info.name();
        this.description   = info.description();
        this.category      = info.category();
        this.bind          = info.bind();
        this.visibleDefault= info.visible();
        this.enabled       = info.enabledByDefault();
    }

    // ─── Управление состоянием ───────────────────────────────

    public final void enable() {
        if (enabled) return;
        enabled = true;
        enabledAt = System.currentTimeMillis();
        try {
            onEnable();
            Client.get().eventManager().subscribe(this);
        } catch (Throwable t) {
            Logger.error("onEnable failed in " + name, t);
        }
        Logger.info("Module + " + name);
        announce("+", Formatting.GREEN);
    }

    public final void disable() {
        if (!enabled) return;
        enabled = false;
        try {
            Client.get().eventManager().unsubscribe(this);
            onDisable();
        } catch (Throwable t) {
            Logger.error("onDisable failed in " + name, t);
        }
        Logger.info("Module - " + name);
        announce("-", Formatting.RED);
    }

    public final void toggle() {
        if (enabled) disable();
        else         enable();
    }

    public final boolean isEnabled()   { return enabled; }
    public final boolean isDisabled()  { return !enabled; }

    // ─── Хуки для наследников ────────────────────────────────

    /** Вызывается при включении модуля. По умолчанию пусто. */
    protected void onEnable()  {}

    /** Вызывается при выключении модуля. По умолчанию пусто. */
    protected void onDisable() {}

    /** Вызывается каждый клиентский тик ТОЛЬКО если модуль включён. */
    public void onTick() {}

    // ─── Биндинг клавиш ──────────────────────────────────────

    public int    getBind()        { return bind; }
    public void   setBind(int key) { this.bind = key; }
    public boolean hasBind()       { return bind != 0; }

    // ─── Геттеры метаданных ──────────────────────────────────

    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isVisible()      { return visibleDefault; }
    public long     getCreatedAt()   { return createdAt; }
    public long     getEnabledAt()   { return enabledAt; }

    public ModulePriority priority() { return ModulePriority.NORMAL; }

    /** {@inheritDoc} — обязательно для @FunctionalInterface EventListener. */
    @Override public final void noop() {}

    // ─── Вспомогательные методы ──────────────────────────────

    /** Выводит в чат строку-индикатор состояния модуля. */
    private void announce(String sign, Formatting color) {
        if (mc.player == null) return;
        String msg = String.format("%s%s §7%s", color, sign, name);
        try {
            mc.inGameHud.getChatHud().addMessage(Text.literal(msg));
        } catch (Throwable ignored) {
            // чат может быть недоступен в early-init
        }
    }
}
