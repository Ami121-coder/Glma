package dev.cheat.util;

import dev.cheat.render.Render2D;
import dev.cheat.render.font.CustomFontRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Утилиты 2D/3D рендера.
 *
 * <p><b>2D-API</b> — делегирует в {@link Render2D} и {@link CustomFontRenderer}.
 * Эти методы — тонкая обёртка для обратной совместимости со старым кодом
 * и удобства в простых случаях.</p>
 *
 * <p><b>3D-API</b> — для World-рендера (ESP, Tracers, BlockOutline).</p>
 *
 * <p><b>1.21.4 note:</b> {@link VertexConsumer} в 1.21+ НЕ имеет метода
 * {@code .next()} — вершина завершается автоматически при следующем вызове
 * {@code .vertex(...)} или при flush буфера.</p>
 */
public final class RenderUtil {

    private RenderUtil() {}

    private static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    // ─── 2D: текст (через CustomFontRenderer) ─────────────────

    private static CustomFontRenderer fontCache;

    public static CustomFontRenderer font() {
        if (fontCache == null) fontCache = CustomFontRenderer.from(mc());
        return fontCache;
    }

    public static void text(DrawContext ctx, String text, int x, int y, int color) {
        font().draw(ctx.getMatrices(), text, x, y, color, false);
    }

    public static void textShadow(DrawContext ctx, String text, int x, int y, int color) {
        font().drawWithShadow(ctx.getMatrices(), text, x, y, color);
    }

    public static void textSoftShadow(DrawContext ctx, String text, int x, int y, int color) {
        font().drawSoftShadow(ctx.getMatrices(), text, x, y, color);
    }

    public static void textGlow(DrawContext ctx, String text, int x, int y, int color) {
        font().drawGlow(ctx.getMatrices(), text, x, y, color);
    }

    public static void textGradient(DrawContext ctx, String text, int x, int y,
                                    int left, int right) {
        font().drawGradient(ctx.getMatrices(), text, x, y, left, right, false);
    }

    public static void textRainbow(DrawContext ctx, String text, int x, int y,
                                   float speedMs, float spread, boolean shadow) {
        font().drawRainbow(ctx.getMatrices(), text, x, y, 1f, 0.5f, 1f, (long) speedMs, spread, shadow);
    }

    // ─── 2D: прямоугольники (через Render2D) ──────────────────

    public static void rect(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + h, color);
    }

    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h,
                                   float radius, int color) {
        Render2D.roundedRect(ctx, x, y, w, h, radius, color);
    }

    public static void verticalGradient(DrawContext ctx, int x, int y, int w, int h,
                                        int top, int bottom) {
        Render2D.verticalGradient(ctx, x, y, w, h, top, bottom);
    }

    public static void horizontalGradient(DrawContext ctx, int x, int y, int w, int h,
                                          int left, int right) {
        Render2D.horizontalGradient(ctx, x, y, w, h, left, right);
    }

    public static void rectBorder(DrawContext ctx, int x, int y, int w, int h, int color, int thickness) {
        ctx.fill(x,             y,             x + w,             y + thickness,     color); // top
        ctx.fill(x,             y + h - thickness, x + w,         y + h,             color); // bottom
        ctx.fill(x,             y,             x + thickness,     y + h,             color); // left
        ctx.fill(x + w - thickness, y,         x + w,             y + h,             color); // right
    }

    public static int textWidth(String text) {
        return mc().textRenderer.getWidth(text);
    }

    public static int fontHeight() {
        return mc().textRenderer.fontHeight;
    }

    // ─── 3D: линии и боксы в мировых координатах ──────────────

    /**
     * Рисует линию в мировых координатах через {@link VertexConsumer}.
     * {@code matrices} уже должен быть сдвинут на {@code -cameraX/Y/Z}.
     */
    public static void line3D(MatrixStack matrices, VertexConsumerProvider provider,
                              Vec3d from, Vec3d to, int color) {
        VertexConsumer vc = provider.getBuffer(RenderLayer.getLines());
        var entry = matrices.peek();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ( color        & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        vc.vertex(entry, (float) from.x, (float) from.y, (float) from.z)
          .color(r, g, b, a)
          .normal(entry, 0f, 1f, 0f);
        vc.vertex(entry, (float) to.x,   (float) to.y,   (float) to.z)
          .color(r, g, b, a)
          .normal(entry, 0f, 1f, 0f);
    }

    /**
     * Рисует бокс (ABB) в мировых координатах. {@code min}/{@code max} —
     * локальные координаты (после смещения камеры).
     */
    public static void box3D(MatrixStack matrices, VertexConsumerProvider provider,
                             Vec3d min, Vec3d max, int color) {
        VertexConsumer vc = provider.getBuffer(RenderLayer.getLines());
        var entry = matrices.peek();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ( color        & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        float x0 = (float) min.x, y0 = (float) min.y, z0 = (float) min.z;
        float x1 = (float) max.x, y1 = (float) max.y, z1 = (float) max.z;

        edge(vc, entry, x0,y0,z0, x1,y0,z0, r,g,b,a);
        edge(vc, entry, x1,y0,z0, x1,y0,z1, r,g,b,a);
        edge(vc, entry, x1,y0,z1, x0,y0,z1, r,g,b,a);
        edge(vc, entry, x0,y0,z1, x0,y0,z0, r,g,b,a);

        edge(vc, entry, x0,y1,z0, x1,y1,z0, r,g,b,a);
        edge(vc, entry, x1,y1,z0, x1,y1,z1, r,g,b,a);
        edge(vc, entry, x1,y1,z1, x0,y1,z1, r,g,b,a);
        edge(vc, entry, x0,y1,z1, x0,y1,z0, r,g,b,a);

        edge(vc, entry, x0,y0,z0, x0,y1,z0, r,g,b,a);
        edge(vc, entry, x1,y0,z0, x1,y1,z0, r,g,b,a);
        edge(vc, entry, x1,y0,z1, x1,y1,z1, r,g,b,a);
        edge(vc, entry, x0,y0,z1, x0,y1,z1, r,g,b,a);
    }

    /**
     * Рисует заполненный бокс (filled) через {@link RenderLayer#getDebugQuads()}.
     * Полезно для ESP-fills с низкой alpha.
     */
    public static void filledBox3D(MatrixStack matrices, VertexConsumerProvider provider,
                                   Vec3d min, Vec3d max, int color) {
        VertexConsumer vc = provider.getBuffer(RenderLayer.getDebugQuads());
        Matrix4f m = matrices.peek().getPositionMatrix();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ( color        & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        float x0 = (float) min.x, y0 = (float) min.y, z0 = (float) min.z;
        float x1 = (float) max.x, y1 = (float) max.y, z1 = (float) max.z;

        // 6 граней по 4 вершины (QUADS draw mode)
        // Front (z = z1)
        quad(vc, m, x0,y0,z1, x1,y0,z1, x1,y1,z1, x0,y1,z1, r,g,b,a);
        // Back  (z = z0)
        quad(vc, m, x1,y0,z0, x0,y0,z0, x0,y1,z0, x1,y1,z0, r,g,b,a);
        // Left  (x = x0)
        quad(vc, m, x0,y0,z0, x0,y0,z1, x0,y1,z1, x0,y1,z0, r,g,b,a);
        // Right (x = x1)
        quad(vc, m, x1,y0,z1, x1,y0,z0, x1,y1,z0, x1,y1,z1, r,g,b,a);
        // Top   (y = y1)
        quad(vc, m, x0,y1,z1, x1,y1,z1, x1,y1,z0, x0,y1,z0, r,g,b,a);
        // Bottom(y = y0)
        quad(vc, m, x0,y0,z0, x1,y0,z0, x1,y0,z1, x0,y0,z1, r,g,b,a);
    }

    private static void edge(VertexConsumer vc, MatrixStack.Entry entry,
                             float x0,float y0,float z0,
                             float x1,float y1,float z1,
                             float r,float g,float b,float a) {
        vc.vertex(entry, x0, y0, z0).color(r, g, b, a).normal(entry, 1f, 0f, 0f);
        vc.vertex(entry, x1, y1, z1).color(r, g, b, a).normal(entry, 1f, 0f, 0f);
    }

    private static void quad(VertexConsumer vc, Matrix4f m,
                             float x0,float y0,float z0,
                             float x1,float y1,float z1,
                             float x2,float y2,float z2,
                             float x3,float y3,float z3,
                             float r,float g,float b,float a) {
        vc.vertex(m, x0, y0, z0).color(r, g, b, a);
        vc.vertex(m, x1, y1, z1).color(r, g, b, a);
        vc.vertex(m, x2, y2, z2).color(r, g, b, a);
        vc.vertex(m, x3, y3, z3).color(r, g, b, a);
    }
}
