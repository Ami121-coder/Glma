package dev.cheat.render.font;

import dev.cheat.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Matrix4f;

/**
 * Кастомный рендерер шрифта поверх ванильного {@link TextRenderer}.
 *
 * <p>Добавляет поверх vanilla-API:</p>
 * <ul>
 *   <li>{@link #drawShadow} — двойная тень (тёмная + цветная) для soft-glow</li>
 *   <li>{@link #drawOutline} — обводка в 8 направлениях</li>
 *   <li>{@link #drawRainbow} — переливающийся текст</li>
 *   <li>{@link #drawGradient} — градиент по символам (left→right)</li>
 *   <li>{@link #drawCentered} — автоцентровка по X</li>
 * </ul>
 *
 * <p><b>Все координаты — float</b>, поскольку шрифт в 1.21+ работает с
 * субпиксельной точностью. {@code Matrix4f} берётся напрямую из
 * {@code ctx.getMatrices().peek().getPositionMatrix()}.</p>
 *
 * <p>Используется {@link VertexConsumerProvider.Immediate} от Minecraft
 * — тот же, что и {@code DrawContext}. Буфер рисуется автоматически
 * в конце {@code InGameHud.render()}.</p>
 */
public final class CustomFontRenderer {

    private final TextRenderer vanilla;
    private final VertexConsumerProvider.Immediate immediate;

    public CustomFontRenderer(TextRenderer vanilla, VertexConsumerProvider.Immediate immediate) {
        this.vanilla  = vanilla;
        this.immediate = immediate;
    }

    public static CustomFontRenderer from(MinecraftClient mc) {
        return new CustomFontRenderer(mc.textRenderer,
                mc.getBufferBuilders().getEntityVertexConsumers());
    }

    // ─── Базовые методы ───────────────────────────────────────

    public int draw(MatrixStack matrices, String text, float x, float y, int color) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        return vanilla.draw(text, x, y, color, false, m, immediate, TextLayerType.NORMAL, 0, 0xF000F0);
    }

    public int drawWithShadow(MatrixStack matrices, String text, float x, float y, int color) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        return vanilla.draw(text, x, y, color, true, m, immediate, TextLayerType.NORMAL, 0, 0xF000F0);
    }

    public int drawCentered(MatrixStack matrices, String text, float x, float y, int color, boolean shadow) {
        float w = vanilla.getWidth(text);
        return draw(matrices, text, x - w / 2f, y, color, shadow);
    }

    public int draw(MatrixStack matrices, String text, float x, float y, int color, boolean shadow) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        return vanilla.draw(text, x, y, color, shadow, m, immediate, TextLayerType.NORMAL, 0, 0xF000F0);
    }

    // ─── Расширенные эффекты ──────────────────────────────────

    /**
     * Soft shadow: рисует текст сначала со смещением (1,1) тёмным цветом,
     * потом основной — поверх. Получается мягкая тень вместо резкой.
     */
    public int drawSoftShadow(MatrixStack matrices, String text, float x, float y, int color) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        int shadow = ColorUtil.alpha(ColorUtil.darken(color, 0.7f),
                ColorUtil.alpha(color) * 0.6f);
        // Двойная тень (1,1) и (2,2) для мягкости
        vanilla.draw(text, x + 1, y + 1, shadow, false, m, immediate, TextLayerType.NORMAL, 0, 0xF000F0);
        vanilla.draw(text, x + 2, y + 2, ColorUtil.alpha(shadow, ColorUtil.alpha(shadow) * 0.4f),
                false, m, immediate, TextLayerType.NORMAL, 0, 0xF000F0);
        return vanilla.draw(text, x, y, color, false, m, immediate, TextLayerType.NORMAL, 0, 0xF000F0);
    }

    /**
     * Outline: рисует 8 смещений цветом обводки, затем основной текст по центру.
     */
    public int drawOutline(MatrixStack matrices, String text, float x, float y, int fillColor, int outlineColor) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        // 8 направлений
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                vanilla.draw(text, x + dx, y + dy, outlineColor, false, m, immediate,
                        TextLayerType.NORMAL, 0, 0xF000F0);
            }
        }
        return vanilla.draw(text, x, y, fillColor, false, m, immediate,
                TextLayerType.NORMAL, 0, 0xF000F0);
    }

    /**
     * Rainbow-текст: цвет циклически меняется с течением времени.
     *
     * @param speedMs период одного цикла в миллисекундах
     */
    public int drawRainbow(MatrixStack matrices, String text, float x, float y,
                           float saturation, float lightness, float alpha,
                           long speedMs, float spread, boolean shadow) {
        long now = System.currentTimeMillis();
        Matrix4f m = matrices.peek().getPositionMatrix();
        float offset = 0;
        int totalWidth = 0;

        // Считаем общую ширину
        for (int i = 0; i < text.length(); i++) {
            totalWidth += vanilla.getWidth(String.valueOf(text.charAt(i)));
        }

        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            int w = vanilla.getWidth(ch);
            // hue сдвигается по позиции символа и по времени
            float hue = (((now % speedMs) / (float) speedMs) + (offset / Math.max(1, totalWidth)) * spread) * 360f;
            int color = ColorUtil.hslToRgb(hue, saturation, lightness);
            color = ColorUtil.alpha(color, Math.round(alpha * 255f));

            vanilla.draw(ch, x + offset, y, color, shadow, m, immediate,
                    TextLayerType.NORMAL, 0, 0xF000F0);
            offset += w;
        }
        return (int) (x + offset);
    }

    /**
     * Линейный градиент: каждый символ interpolируется между {@code colorLeft}
     * и {@code colorRight} по позиции символа в строке.
     */
    public int drawGradient(MatrixStack matrices, String text, float x, float y,
                            int colorLeft, int colorRight, boolean shadow) {
        if (text.isEmpty()) return (int) x;

        Matrix4f m = matrices.peek().getPositionMatrix();
        float offset = 0;
        int totalWidth = vanilla.getWidth(text);
        if (totalWidth == 0) return (int) x;

        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            int w = vanilla.getWidth(ch);
            float t = offset / totalWidth;
            int color = ColorUtil.lerp(colorLeft, colorRight, t);
            vanilla.draw(ch, x + offset, y, color, shadow, m, immediate,
                    TextLayerType.NORMAL, 0, 0xF000F0);
            offset += w;
        }
        return (int) (x + offset);
    }

    /** Обводка с эффектом свечения: тёмная обводка + мягкий shadow под ней. */
    public int drawGlow(MatrixStack matrices, String text, float x, float y, int color) {
        // Сначала soft shadow того же цвета, но с пониженной alpha
        Matrix4f m = matrices.peek().getPositionMatrix();
        int glow = ColorUtil.alpha(color, ColorUtil.alpha(color) * 0.35f);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                vanilla.draw(text, x + dx, y + dy, glow, false, m, immediate,
                        TextLayerType.NORMAL, 0, 0xF000F0);
            }
        }
        return vanilla.draw(text, x, y, color, false, m, immediate,
                TextLayerType.NORMAL, 0, 0xF000F0);
    }

    /**
     * Декоративный заголовок: gradient текст + soft glow под ним.
     * Идеально для заголовков ClickGUI.
     */
    public int drawTitle(MatrixStack matrices, String text, float x, float y,
                         int colorLeft, int colorRight) {
        // Glow под gradient
        Matrix4f m = matrices.peek().getPositionMatrix();
        int glowColor = ColorUtil.alpha(colorLeft, ColorUtil.alpha(colorLeft) * 0.3f);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                drawGradient(matrices, text, x + dx, y + dy, glowColor, ColorUtil.alpha(colorRight, 0.3f), false);
            }
        }
        return drawGradient(matrices, text, x, y, colorLeft, colorRight, false);
    }

    // ─── Метрики ──────────────────────────────────────────────

    public int width(String text) { return vanilla.getWidth(text); }
    public int height() { return vanilla.fontHeight; }
    public int width(Text text) { return vanilla.getWidth(text); }
    public TextRenderer vanilla() { return vanilla; }

    /** Удаляет все §-коды из строки. */
    public static String stripFormatting(String text) {
        if (text == null) return "";
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '§' && i + 1 < text.length()) {
                i++; // пропустить код
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    /** Достаёт §-коды и возвращает «сырой» цвет Formatting (или WHITE). */
    public static Formatting lastFormatting(String text) {
        if (text == null) return Formatting.WHITE;
        Formatting last = Formatting.WHITE;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '§' && i + 1 < text.length()) {
                Formatting f = Formatting.byCode(text.charAt(i + 1));
                if (f != null) last = f;
                i++;
            }
        }
        return last;
    }
}
