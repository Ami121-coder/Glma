package dev.cheat.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.cheat.render.shader.CustomRenderLayers;
import dev.cheat.render.shader.ShaderManager;
import dev.cheat.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.Uniform;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

/**
 * Главный 2D-рендер для красивого GUI.
 *
 * <p>API:</p>
 * <ul>
 *   <li>{@link #roundedRect} — прямоугольник со скруглением через SDF-шейдер</li>
 *   <li>{@link #gradientRect} — 4-цветный градиент через шейдер</li>
 *   <li>{@link #glowRect} — прямоугольник с пульсирующим ореолом</li>
 *   <li>{@link #vLine}/{@link #hLine} — цветные линии</li>
 *   <li>{@link #scissors} — обрезка прямоугольником (для скролла)</li>
 * </ul>
 *
 * <p><b>Архитектура:</b> Каждый метод — это «draw immediate»: строим quad
 * в {@link Tessellator}, задаём uniform'ы шейдера, рендерим. Для высокой
 * производительности (например, ArrayList из 20+ модулей) рекомендуется
 * батчить — но каркас оставляет это на откуп разработчику через batch API.</p>
 */
public final class Render2D {

    private Render2D() {}

    private static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    // ─── Закруглённый прямоугольник (SDF шейдер) ──────────────

    /**
     * Закруглённый прямоугольник. {@code radius} ≤ min(w,h)/2.
     * Falls back к обычному {@code ctx.fill} если шейдер недоступен.
     */
    public static void roundedRect(DrawContext ctx, float x, float y, float w, float h,
                                   float radius, int color) {
        ShaderProgram program = ShaderManager.get(ShaderManager.ROUNDED_RECT);
        if (program == null) {
            // Fallback: обычный fill без скругления
            ctx.fill((int) x, (int) y, (int) (x + w), (int) (y + h), color);
            return;
        }

        // Задаём uniform'ы
        Uniform size = program.getUniform("u_Size");
        Uniform rad = program.getUniform("u_Radius");
        Uniform edge = program.getUniform("u_EdgeSoftness");
        if (size != null)  size.set(w, h);
        if (rad  != null)  rad.set(radius);
        if (edge != null)  edge.set(1.0f);

        drawQuad(ctx, CustomRenderLayers.ROUNDED_RECT, x, y, w, h, color);
    }

    /**
     * Закруглённый прямоугольник с градиентной заливкой.
     * Использует GRADIENT-шейдер (4 угловых цвета).
     */
    public static void gradientRoundedRect(DrawContext ctx, float x, float y, float w, float h,
                                            float radius,
                                            int tl, int tr, int bl, int br) {
        ShaderProgram gProgram = ShaderManager.get(ShaderManager.GRADIENT);
        ShaderProgram rProgram = ShaderManager.get(ShaderManager.ROUNDED_RECT);

        // Если есть оба шейдера — можно бы сделать复合, но каркас упрощает:
        // используем градиент-шейдер, без скругления (fallback к прямоугольнику).
        // Для скругления + градиента разработчик может использовать stencil.
        if (gProgram == null) {
            roundedRect(ctx, x, y, w, h, radius, tl);
            return;
        }

        Uniform tlU = gProgram.getUniform("u_TopLeft");
        Uniform trU = gProgram.getUniform("u_TopRight");
        Uniform blU = gProgram.getUniform("u_BotLeft");
        Uniform brU = gProgram.getUniform("u_BotRight");
        if (tlU != null) tlU.set(ColorUtil.rf(tl), ColorUtil.gf(tl), ColorUtil.bf(tl), ColorUtil.af(tl));
        if (trU != null) trU.set(ColorUtil.rf(tr), ColorUtil.gf(tr), ColorUtil.bf(tr), ColorUtil.af(tr));
        if (blU != null) blU.set(ColorUtil.rf(bl), ColorUtil.gf(bl), ColorUtil.bf(bl), ColorUtil.af(bl));
        if (brU != null) brU.set(ColorUtil.rf(br), ColorUtil.gf(br), ColorUtil.bf(br), ColorUtil.af(br));

        drawQuad(ctx, CustomRenderLayers.GRADIENT, x, y, w, h, 0xFFFFFFFF);
    }

    /**
     * Свечение вокруг прямоугольника. {@code spread} — насколько далеко
     * тянется glow в пикселях.
     */
    public static void glowRect(DrawContext ctx, float x, float y, float w, float h,
                                float radius, float spread, int color) {
        ShaderProgram program = ShaderManager.get(ShaderManager.GLOW);
        if (program == null) {
            // Fallback: 3 прямоугольника с уменьшающейся alpha
            for (int i = 3; i >= 1; i--) {
                int c = ColorUtil.alpha(color, ColorUtil.alpha(color) * 0.15f * i);
                ctx.fill((int) (x - i), (int) (y - i), (int) (x + w + i), (int) (y + h + i), c);
            }
            return;
        }

        Uniform size   = program.getUniform("u_Size");
        Uniform rad    = program.getUniform("u_Radius");
        Uniform spreadU= program.getUniform("u_Spread");
        if (size   != null) size.set(w, h);
        if (rad    != null) rad.set(radius);
        if (spreadU!= null) spreadU.set(spread);

        drawQuad(ctx, CustomRenderLayers.GLOW, x, y, w, h, color);
    }

    /**
     * Прямоугольник с линейным 2-цветным градиентом (по вертикали).
     */
    public static void verticalGradient(DrawContext ctx, float x, float y, float w, float h,
                                        int top, int bottom) {
        gradientRoundedRect(ctx, x, y, w, h, 0,
                top, top, bottom, bottom);
    }

    /**
     * Прямоугольник с линейным 2-цветным градиентом (по горизонтали).
     */
    public static void horizontalGradient(DrawContext ctx, float x, float y, float w, float h,
                                          int left, int right) {
        gradientRoundedRect(ctx, x, y, w, h, 0,
                left, right, left, right);
    }

    // ─── Линии ────────────────────────────────────────────────

    /** Вертикальная линия 1px. */
    public static void vLine(DrawContext ctx, float x, float y, float h, int color) {
        ctx.fill((int) x, (int) y, (int) (x + 1), (int) (y + h), color);
    }

    /** Горизонтальная линия 1px. */
    public static void hLine(DrawContext ctx, float x, float y, float w, int color) {
        ctx.fill((int) x, (int) y, (int) (x + w), (int) (y + 1), color);
    }

    /** Жирная горизонтальная линия с вертикальным градиентом (например, прогресс-бар). */
    public static void hLineGradient(DrawContext ctx, float x, float y, float w, float thickness,
                                     int left, int right) {
        gradientRoundedRect(ctx, x, y, w, thickness, 0,
                left, right, left, right);
    }

    // ─── Scissors ─────────────────────────────────────────────

    /**
     * Включает прямоугольную обрезку. Вызывайте после отрисовки
     * {@code ctx.getVertexConsumers().draw()} чтобы сбросить предыдущий буфер.
     */
    public static void scissors(float x, float y, float w, float h) {
        MinecraftClient mc = MinecraftClient.getInstance();
        double sx = mc.getWindow().getScaleFactor();
        int sw = mc.getWindow().getWidth();
        int sh = mc.getWindow().getHeight();

        // GL scissor координаты: bottom-left origin
        int gx = (int) (x * sx);
        int gy = (int) (sh - (y + h) * sx);
        int gw = (int) (w * sx);
        int gh = (int) (h * sx);

        RenderSystem.enableScissor(gx, gy, gw, gh);
    }

    public static void disableScissors() {
        RenderSystem.disableScissor();
    }

    // ─── Внутренние helpers ───────────────────────────────────

    /**
     * Рисует один quad с заданным {@link net.minecraft.client.render.RenderLayer}
     * и цветом (передаётся как vertex color). Использует {@link Tessellator}
     * для immediate-режима.
     */
    private static void drawQuad(DrawContext ctx, net.minecraft.client.render.RenderLayer layer,
                                 float x, float y, float w, float h, int color) {
        // Используем DrawContext.fill с RenderLayer — это самый чистый путь
        // в 1.21.4: метод сам создаст VertexConsumer и положит 4 вершины.
        ctx.fill(layer,
                (int) x, (int) y,
                (int) (x + w), (int) (y + h),
                color);

        // ВАЖНО: DrawContext.fill НЕ задаёт uniforms шейдера. Uniform'ы мы
        // задаём ВЫШЕ (до вызова drawQuad), а внутри DrawContext.fill они
        // применяются при buffer.flush(). Это работает потому что RenderSystem
        // хранит активный шейдер глобально — но!
        //
        // Для надёжного применения uniform'ов нужно явно flush-нуть буфер
        // до того, как другой код переключит шейдер. Поэтому вызываем draw():
        ctx.draw();
    }

    // ─── Безопасный helper для прямого Tessellator-рендера ───

    /**
     * Альтернативный рендер quad через {@link Tessellator} напрямую.
     * Используйте когда нужно гарантированно задать uniform'ы до draw call.
     */
    public static void drawQuadTessellator(net.minecraft.client.render.RenderLayer layer,
                                           Matrix4f matrix,
                                           float x, float y, float w, float h, int color) {
        // Этот вариант оставлен как «продвинутый» API для будущего расширения.
        // Использует Tessellator+BufferBuilder напрямую (как делает DrawContext.fill).
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        float r = ColorUtil.rf(color), g = ColorUtil.gf(color), b = ColorUtil.bf(color), a = ColorUtil.af(color);

        buf.vertex(matrix, x,     y,     0).color(r, g, b, a);
        buf.vertex(matrix, x,     y + h, 0).color(r, g, b, a);
        buf.vertex(matrix, x + w, y + h, 0).color(r, g, b, a);
        buf.vertex(matrix, x + w, y,     0).color(r, g, b, a);

        // BufferRenderer.drawWithGlobalProgram(buf.end()) — но мы хотим свой RenderLayer.
        // RenderLayer.draw() доступен через BufferRenderer:
        var baked = buf.endNullable();
        if (baked != null) {
            layer.startDrawing();
            // В 1.21.4 BufferRenderer.draw(baked) использует текущий RenderSystem shader.
            // Для нашего RenderLayer — shader задаётся в MultiPhase.startDrawing().
            net.minecraft.client.render.BufferRenderer.drawWithGlobalProgram(baked);
            layer.endDrawing();
        }
    }
}
