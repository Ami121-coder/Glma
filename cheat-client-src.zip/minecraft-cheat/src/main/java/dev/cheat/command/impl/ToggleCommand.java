package dev.cheat.command.impl;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.module.Module;
import dev.cheat.util.ChatUtil;

/**
 * {@code .toggle <module>} — переключить модуль.
 * {@code .toggle list} — список всех модулей.
 */
public final class ToggleCommand extends Command {

    public ToggleCommand() {
        super("toggle", "Включить/выключить модуль", "t");
    }

    @Override
    public int getMinArgs() { return 1; }

    @Override
    protected void execute(CommandContext ctx) throws CommandException {
        String name = ctx.string(0);

        if (name.equalsIgnoreCase("list")) {
            ChatUtil.info("Модули (" + Client.get().moduleManager().size() + "):");
            for (Module m : Client.get().moduleManager().all()) {
                ChatUtil.sendRaw(" §7- " + (m.isEnabled() ? "§a" : "§c") + m.getName()
                        + " §8[" + m.getCategory().displayName() + "]");
            }
            return;
        }

        Module m = Client.get().moduleManager().get(name);
        if (m == null) throw new CommandException("Модуль не найден: " + name);
        m.toggle();
    }

    @Override
    protected String usageArgs() { return "<module|list>"; }
}
