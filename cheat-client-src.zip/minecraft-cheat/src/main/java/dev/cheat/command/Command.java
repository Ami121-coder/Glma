package dev.cheat.command;

import java.util.Collections;
import java.util.List;

/**
 * Базовый класс команды.
 *
 * <p>Пример реализации:</p>
 * <pre>
 *   public final class ToggleCommand extends Command {
 *       public ToggleCommand() {
 *           super("toggle", "Включить/выключить модуль", "t");
 *       }
 *       &#64;Override protected void execute(CommandContext ctx) throws CommandException {
 *           String name = ctx.string(0);
 *           ...
 *       }
 *   }
 * </pre>
 */
public abstract class Command {

    private final String   name;
    private final String   description;
    private final String[] aliases;

    protected Command(String name, String description, String... aliases) {
        this.name        = name;
        this.description = description;
        this.aliases     = aliases == null ? new String[0] : aliases;
    }

    /** Имя команды (без префикса). */
    public String getName()        { return name; }
    public String getDescription() { return description; }
    public List<String> getAliases() {
        return Collections.unmodifiableList(java.util.Arrays.asList(aliases));
    }

    /** Сколько минимум аргументов нужно для выполнения. */
    public int getMinArgs() { return 0; }

    /** Подсказка использования для {@code .help &lt;cmd&gt;}. */
    public String getUsage() {
        return "." + name + " " + usageArgs();
    }

    /** Аргументы для подсказки (без префикса и имени). */
    protected String usageArgs() { return ""; }

    /** Точка входа. Бросает {@link CommandException} при ошибке. */
    protected abstract void execute(CommandContext ctx) throws CommandException;
}
