package dev.cheat.command.arg;

/**
 * Маркерный интерфейс для типизированного аргумента команды.
 *
 * <p>Например: {@code PlayerArgument}, {@code ModuleArgument},
 * {@code BlockArgument}. Каркас оставляет контракт, конкретные
 * аргументы разработчик добавляет по мере надобности.</p>
 */
@FunctionalInterface
public interface Argument<T> {

    /** Парсит строку в значение T. Бросает {@code IllegalArgumentException}. */
    T parse(String raw);
}
