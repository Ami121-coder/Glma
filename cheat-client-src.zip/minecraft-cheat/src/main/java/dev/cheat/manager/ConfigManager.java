package dev.cheat.manager;

import dev.cheat.Client;
import dev.cheat.config.JsonConfig;
import dev.cheat.module.Module;
import dev.cheat.util.Logger;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Менеджер конфигурации.
 *
 * <p>Хранит общую JSON-конфигурацию в {@code .minecraft/cheat/config.json}.</p>
 *
 * <ul>
 *   <li>Состояние модулей (enabled/disabled)</li>
 *   <li>Бинды клавиш</li>
 *   <li>Список друзей (ссылается на FriendManager)</li>
 *   <li>Настройки UI (тема, позиция фреймов)</li>
 * </ul>
 *
 * <p>Конкретные настройки модулей (sliders/toggles) сохраняются через
 * {@code Configurable}-интерфейс, который разработчик добавит позже.</p>
 */
public final class ConfigManager {

    public static final Path CONFIG_DIR = Paths.get("cheat");
    public static final Path MAIN_FILE  = CONFIG_DIR.resolve("config.json");

    private final JsonConfig<ConfigPayload> store =
            new JsonConfig<>(MAIN_FILE, ConfigPayload.class);

    private ConfigPayload data = new ConfigPayload();

    public ConfigPayload data() { return data; }

    public void load() {
        Logger.info("Loading config from " + MAIN_FILE);
        ConfigPayload loaded = store.load();
        if (loaded != null) {
            this.data = loaded;
            Logger.info("Config loaded");
        } else {
            Logger.info("No config found — using defaults");
        }
    }

    public void save() {
        Logger.info("Saving config to " + MAIN_FILE);
        // обновляем снапшот модулей
        data.modules.clear();
        for (Module m : Client.get().moduleManager().all()) {
            ConfigPayload.ModuleEntry e = new ConfigPayload.ModuleEntry();
            e.name    = m.getName();
            e.enabled = m.isEnabled();
            e.bind    = m.getBind();
            data.modules.put(m.getName().toLowerCase(), e);
        }
        store.save(data);
        Logger.info("Config saved");
    }

    public void applyTo(Client client) {
        for (ConfigPayload.ModuleEntry e : data.modules.values()) {
            Module m = client.moduleManager().get(e.name);
            if (m == null) continue;
            if (e.bind != 0) m.setBind(e.bind);
            if (e.enabled && !m.isEnabled()) m.enable();
            else if (!e.enabled && m.isEnabled()) m.disable();
        }
    }
}
