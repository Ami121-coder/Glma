package dev.cheat.manager;

import dev.cheat.Client;
import dev.cheat.command.Command;
import dev.cheat.command.CommandContext;
import dev.cheat.command.CommandException;
import dev.cheat.util.ChatUtil;
import dev.cheat.util.Logger;

import java.util.Arrays;
import java.util.List;

/**
 * Диспетчер чат-команд.
 *
 * <p>Перехватывает строки чата, начинающиеся с {@link CommandManager#PREFIX},
 * разбирает на имя + аргументы и вызывает зарегистрированную команду.</p>
 *
 * <p>Вызывается из {@code ClientPlayerEntityMixin.sendMessage} или
 * из специального обработчика в {@code ChatScreenMixin}.</p>
 */
public final class CommandDispatcher {

    private final CommandManager manager;

    public CommandDispatcher(CommandManager manager) {
        this.manager = manager;
    }

    /**
     * Пытается обработать строку как команду.
     * @return {@code true} если строка была командой (обработана или отклонена),
     *         {@code false} — строка не команда, пусть идёт в чат как обычно.
     */
    public boolean tryHandle(String message) {
        if (message == null || message.isEmpty()) return false;
        if (message.charAt(0) != CommandManager.PREFIX) return false;

        String body = message.substring(1).trim();
        if (body.isEmpty()) {
            ChatUtil.error("Введите команду. ." + "help для списка.");
            return true;
        }

        List<String> parts = splitArgs(body);
        String       name  = parts.remove(0);

        Command cmd = manager.get(name);
        if (cmd == null) {
            ChatUtil.error("Неизвестная команда: " + name);
            return true;
        }

        CommandContext ctx = new CommandContext(body, parts);
        try {
            // рефлексивный вызов execute, т.к. метод protected
            var m = Command.class.getDeclaredMethod("execute", CommandContext.class);
            m.setAccessible(true);
            m.invoke(cmd, ctx);
        } catch (java.lang.reflect.InvocationTargetException ite) {
            Throwable cause = ite.getCause();
            if (cause instanceof CommandException ce) {
                ChatUtil.error(ce.getMessage());
            } else {
                Logger.error("Command error: " + name, cause);
                ChatUtil.error("Внутренняя ошибка команды");
            }
        } catch (Throwable t) {
            Logger.error("Dispatch error for " + name, t);
            ChatUtil.error("Не удалось выполнить команду");
        }
        return true;
    }

    /** Простейший сплиттер с поддержкой кавычек. */
    private static List<String> splitArgs(String s) {
        // Учитываем кавычки для аргументов с пробелами.
        return Arrays.stream(s.split("\\s+(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)"))
                .map(p -> p.startsWith("\"") && p.endsWith("\"")
                        ? p.substring(1, p.length() - 1) : p)
                .filter(p -> !p.isEmpty())
                .collect(java.util.stream.Collectors.toList());
    }

    public static CommandDispatcher current() {
        return Client.get() == null ? null
                : new CommandDispatcher(Client.get().commandManager());
    }
}
