package dev.cheat.manager;

import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.util.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Менеджер модулей.
 *
 * <p>Хранит все зарегистрированные модули, предоставляет доступ по имени
 * и по классу. Каркас НЕ регистрирует модули — метод {@link #registerDefaults()}
 * оставлен пустым; реальные модули добавляются разработчиком через
 * {@link #register(Class)} или {@link #register(Module)} в подклассе.</p>
 */
public final class ModuleManager {

    private final Map<String,  Module> byName = new LinkedHashMap<>();
    private final Map<Class<?>, Module> byType = new LinkedHashMap<>();

    /** Регистрирует модуль по классу — инстанцирует через рефлексию. */
    public <T extends Module> T register(Class<T> type) {
        T module;
        try {
            module = type.getDeclaredConstructor().newInstance();
        } catch (Throwable t) {
            throw new RuntimeException("Cannot instantiate module " + type.getName(), t);
        }
        return register(module);
    }

    /** Регистрирует уже созданный экземпляр модуля. */
    public <T extends Module> T register(T module) {
        String name = module.getName().toLowerCase();
        if (byName.containsKey(name)) {
            Logger.warn("Duplicate module name: " + name);
            return module;
        }
        byName.put(name, module);
        byType.put(module.getClass(), module);

        // Если @ModuleInfo(enabledByDefault = true) — включаем.
        if (module.isEnabled()) {
            try { module.enable(); } catch (Throwable ignored) {}
        }
        Logger.info("Registered module: " + module.getName()
                + " [" + module.getCategory().displayName() + "]");
        return module;
    }

    /** Вызывается ядром — тут разработчик регистрирует свои модули. */
    public void registerDefaults() {
        // intentionally empty — каркас без модулей
        Logger.info("ModuleManager: no built-in modules (skeleton mode)");
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        return (T) byType.get(type);
    }

    public Module get(String name) {
        return byName.get(name.toLowerCase());
    }

    public Optional<Module> tryGet(String name) {
        return Optional.ofNullable(byName.get(name.toLowerCase()));
    }

    public Collection<Module> all() {
        return Collections.unmodifiableCollection(byName.values());
    }

    public List<Module> enabled() {
        List<Module> r = new ArrayList<>();
        for (Module m : byName.values()) if (m.isEnabled()) r.add(m);
        return r;
    }

    public List<Module> byCategory(Category cat) {
        List<Module> r = new ArrayList<>();
        for (Module m : byName.values()) if (m.getCategory() == cat) r.add(m);
        r.sort(Comparator.comparing(Module::getName));
        return r;
    }

    public int size() {
        return byName.size();
    }

    /** Тик всех включённых модулей. */
    public void tickAll() {
        for (Module m : byName.values()) {
            if (m.isEnabled()) {
                try { m.onTick(); }
                catch (Throwable t) { Logger.error("onTick " + m.getName(), t); }
            }
        }
    }

    /** Отключает все включённые модули. */
    public void disableAll() {
        for (Module m : new ArrayList<>(byName.values())) {
            if (m.isEnabled()) m.disable();
        }
    }
}
