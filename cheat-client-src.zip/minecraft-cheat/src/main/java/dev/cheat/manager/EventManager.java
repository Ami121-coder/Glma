package dev.cheat.manager;

import dev.cheat.event.Event;
import dev.cheat.event.listener.EventHandler;
import dev.cheat.event.listener.EventListener;
import dev.cheat.util.Logger;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Шина событий.
 *
 * <p>Подписчики регистрируются через {@link #subscribe(EventListener)}.
 * Методы-обработчики помечаются {@link EventHandler} и принимают ровно
 * один аргумент — тип события.</p>
 *
 * <p>Потокобезопасно. Подписка на конкретный тип события — регистрозависимая
 * и точная (без иерархии классов: событие подаётся только подписчикам,
 * явно подписанным на его класс).</p>
 */
public final class EventManager {

    /** Один зарегистрированный метод-обработчик. */
    private record Handler(Object instance, Method method, int priority)
            implements Comparable<Handler> {

        @Override public int compareTo(Handler o) {
            return Integer.compare(this.priority, o.priority);
        }

        void invoke(Event event) {
            try {
                method.setAccessible(true);
                method.invoke(instance, event);
            } catch (Throwable t) {
                Logger.error("Event handler error in "
                        + method.getDeclaringClass().getSimpleName()
                        + "#" + method.getName(), t);
            }
        }
    }

    private final Map<Class<? extends Event>, List<Handler>> handlers = new ConcurrentHashMap<>();

    /**
     * Регистрирует все {@link EventHandler}-методы объекта.
     * Повторная регистрация того же объекта игнорируется.
     */
    public void subscribe(EventListener listener) {
        if (listener == null) return;
        synchronized (handlers) {
            for (Method m : listener.getClass().getDeclaredMethods()) {
                EventHandler ann = m.getAnnotation(EventHandler.class);
                if (ann == null) continue;
                Class<?>[] params = m.getParameterTypes();
                if (params.length != 1) {
                    Logger.warn("@" + EventHandler.class.getSimpleName()
                            + " on " + m + " must have exactly 1 param");
                    continue;
                }
                if (!Event.class.isAssignableFrom(params[0])) {
                    Logger.warn("Handler " + m + " param is not an Event");
                    continue;
                }
                @SuppressWarnings("unchecked")
                Class<? extends Event> type = (Class<? extends Event>) params[0];
                Handler h = new Handler(listener, m, ann.priority());
                List<Handler> list = handlers.computeIfAbsent(type,
                        k -> new CopyOnWriteArrayList<>());

                if (list.stream().anyMatch(x -> x.instance == listener
                        && x.method.getName().equals(m.getName()))) {
                    continue; // уже зарегистрирован
                }
                list.add(h);
                list.sort(Comparator.naturalOrder());
            }
        }
    }

    /** Снимает все обработчики объекта. */
    public void unsubscribe(EventListener listener) {
        if (listener == null) return;
        synchronized (handlers) {
            for (List<Handler> list : handlers.values()) {
                list.removeIf(h -> h.instance == listener);
            }
        }
    }

    /** Публикует событие всем подписчикам. */
    public <T extends Event> T post(T event) {
        List<Handler> list = handlers.get(event.getClass());
        if (list == null || list.isEmpty()) return event;
        // копия для устойчивости к модификации во время итерации
        for (Handler h : new ArrayList<>(list)) {
            h.invoke(event);
        }
        return event;
    }

    public int handlerCount(Class<? extends Event> type) {
        List<Handler> l = handlers.get(type);
        return l == null ? 0 : l.size();
    }

    public void clear() {
        handlers.clear();
    }
}
