package dev.cheat.manager;

import dev.cheat.Client;
import dev.cheat.event.impl.MotionEvent;
import dev.cheat.event.impl.MotionUpdateEvent;
import dev.cheat.event.listener.EventHandler;
import dev.cheat.event.listener.EventListener;
import dev.cheat.util.Logger;
import dev.cheat.util.MathUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.Optional;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Менеджер ротаций.
 *
 * <p>Позволяет модулям запросить целевые ротации (yaw/pitch), а каркас
 * применит их синхронно с motion-пакетом, чтобы сервер не увидел
 * аномалий. Поддерживает приоритеты — побеждает цель с наименьшим
 * значением {@code priority}.</p>
 *
 * <p><b>Жизненный цикл за тик:</b></p>
 * <ol>
 *   <li>Модули регистрируют цели через {@link #request} (любой момент).</li>
 *   <li>{@link MotionUpdateEvent}(PRE) — менеджер фиксирует «лучшую» цель.</li>
 *   <li>{@link MotionEvent}(PRE) — менеджер подменяет yaw/pitch в событии
 *       (silent) или на самом игроке (full).</li>
 *   <li>{@link MotionEvent}(POST) — если был silent, возвращает визуальные
 *       ротации обратно (для клиента).</li>
 *   <li>{@link MotionUpdateEvent}(POST) — все цели помечаются как устаревшие,
 *       модули должны снова запросить их, иначе они истекут.</li>
 * </ol>
 *
 * <p><b>Soft/Hard:</b> мягкий режим интерполирует текущие ротации к цели
 * (для имитации человека); жёсткий — снапает мгновенно.</p>
 */
public final class RotationManager implements EventListener {

    /** Цель с её владельцем и временем жизни. */
    private static final class Entry {
        final RotationTarget target;
        volatile long        tickstamp;

        Entry(RotationTarget t) {
            this.target = t;
            this.tickstamp = System.currentTimeMillis();
        }
    }

    /** Все активные цели, отсортированы по priority. */
    private final ConcurrentSkipListSet<Entry> targets =
            new ConcurrentSkipListSet<>(Comparator.comparingInt(e -> e.target.priority));

    /** Текущая применяемая цель (snapshot). */
    private final AtomicReference<RotationTarget> current = new AtomicReference<>();

    /** Сохранённые визуальные ротации (для restore в silent-режиме). */
    private float savedVisualYaw, savedVisualPitch;
    private boolean hasSavedVisual = false;

    /** Текущие «отправленные» ротации. */
    private float serverYaw, serverPitch;

    public RotationManager() {
        // Подписываемся на Motion события
        if (Client.get() != null) {
            Client.get().eventManager().subscribe(this);
        }
    }

    // ─── Публичный API ────────────────────────────────────────

    /**
     * Зарегистрировать цель ротации. Менеджер выберет цель с наименьшим priority.
     */
    public void request(RotationTarget target) {
        if (target == null) return;
        // Удаляем старую цель того же владельца — заменяем
        targets.removeIf(e -> e.target.owner.equals(target.owner));
        targets.add(new Entry(target));
    }

    /** Снять цель конкретного модуля. */
    public void revoke(String owner) {
        targets.removeIf(e -> e.target.owner.equals(owner));
    }

    /** Текущая применяемая цель (или null). */
    public RotationTarget current() {
        return current.get();
    }

    /** Целевые yaw/pitch, которые будут отправлены в этом тике. */
    public Optional<float[]> currentRotation() {
        RotationTarget t = current.get();
        return t == null ? Optional.empty() : Optional.of(new float[]{ t.yaw, t.pitch });
    }

    public float serverYaw()   { return serverYaw;   }
    public float serverPitch() { return serverPitch; }

    public int pendingCount() { return targets.size(); }

    // ─── Event handlers ───────────────────────────────────────

    @EventHandler(priority = 50) // раньше большинства модулей
    public void onMotionUpdate(MotionUpdateEvent e) {
        if (e.isPre()) {
            // Фиксируем лучшую цель до вызова MotionEvent
            pickBestTarget();
        } else if (e.isPost()) {
            // POST: сбросить одноразовые цели
            postMotionCleanup();
        }
    }

    @EventHandler(priority = 30) // очень рано — модули потом могут переопределить
    public void onMotion(MotionEvent e) {
        if (e.isPre()) {
            applyToMotionEvent(e);
        } else if (e.isPost()) {
            restoreVisualRotation(e.player());
        }
    }

    // ─── Внутренняя логика ────────────────────────────────────

    private void pickBestTarget() {
        if (targets.isEmpty()) {
            current.set(null);
            return;
        }
        // Первый элемент — с минимальным priority
        Entry best = targets.first();
        current.set(best.target);
    }

    private void applyToMotionEvent(MotionEvent e) {
        RotationTarget t = current.get();
        if (t == null) return;

        // Сохраним визуальные ротации для restore
        if (!hasSavedVisual) {
            savedVisualYaw   = e.player().getYaw();
            savedVisualPitch = e.player().getPitch();
            hasSavedVisual   = true;
        }

        // Применяем к MotionEvent (в Pre)
        e.setRotation(t.yaw, t.pitch);

        // Запоминаем, что отправим на сервер
        serverYaw   = t.yaw;
        serverPitch = t.pitch;

        // Если цель не silent — двигаем камеру клиента тоже
        if (t.affectLooking) {
            e.player().setYaw(t.yaw);
            e.player().setPitch(t.pitch);
        }

        // Если влияют на movement — player.yaw/pitch уже изменены выше
        // (Movement-вектор считается из player.yaw, не из серверных ротаций)
    }

    private void restoreVisualRotation(ClientPlayerEntity player) {
        RotationTarget t = current.get();
        if (t == null || !t.silent) {
            hasSavedVisual = false;
            return;
        }
        // Silent: вернуть визуальные ротации
        if (hasSavedVisual) {
            player.setYaw(savedVisualYaw);
            player.setPitch(savedVisualPitch);
            hasSavedVisual = false;
        }
    }

    private void postMotionCleanup() {
        // Все цели одноразовые — снимаем их
        // Модули должны снова запросить, если хотят продолжать.
        targets.clear();
        current.set(null);
    }

    // ─── Утилитарные вычисления ротаций ──────────────────────

    /**
     * Вычислить yaw/pitch, необходимые для того, чтобы смотреть из {@code from}
     * на {@code to}. Возвращает {@code float[2] = {yaw, pitch}}.
     */
    public static float[] lookAt(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, distXZ));
        return new float[]{ yaw, pitch };
    }

    /**
     * Плавный поворот от {@code current} к {@code target} с максимальным шагом
     * {@code maxStep} градусов. Используется для имитации человеческого движения.
     */
    public static float[] smooth(float[] current, float[] target, float maxStep) {
        float cy = current[0], cp = current[1];
        float ty = target[0],   tp = target[1];

        float dyaw = MathUtil.angleDelta(cy, ty);
        float dpit = MathUtil.clamp(tp - cp, -maxStep, maxStep);

        // ограничиваем шаг по модулю
        if (Math.abs(dyaw) > maxStep) {
            dyaw = Math.signum(dyaw) * maxStep;
        }

        return new float[]{
                MathUtil.normalizeAngle(cy + dyaw),
                MathUtil.clamp(cp + dpit, -90f, 90f)
        };
    }

    /** {@inheritDoc} — обязательно для @FunctionalInterface EventListener. */
    @Override public final void noop() {}
}
