package dev.cheat.manager;

import dev.cheat.command.Command;
import dev.cheat.util.Logger;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Менеджер команд.
 *
 * <p>Команды вызываются из чата префиксом {@code .} (точка).
 * Каркас регистрирует минимальный набор: {@code .help}, {@code .toggle},
 * {@code .bind}, {@code .config}, {@code .friend}.</p>
 */
public final class CommandManager {

    public static final char PREFIX = '.';

    private final Map<String, Command> commands = new LinkedHashMap<>();

    public <T extends Command> T register(T cmd) {
        String key = cmd.getName().toLowerCase();
        if (commands.containsKey(key)) {
            Logger.warn("Duplicate command: " + key);
            return cmd;
        }
        commands.put(key, cmd);
        for (String alias : cmd.getAliases()) {
            commands.putIfAbsent(alias.toLowerCase(), cmd);
        }
        return cmd;
    }

    public void registerDefaults() {
        register(new dev.cheat.command.impl.HelpCommand());
        register(new dev.cheat.command.impl.ToggleCommand());
        register(new dev.cheat.command.impl.BindCommand());
        register(new dev.cheat.command.impl.ConfigCommand());
        register(new dev.cheat.command.impl.FriendCommand());
        Logger.info("CommandManager: built-in commands registered ("
                + size() + " commands, "
                + "prefix='" + PREFIX + "')");
    }

    public Command get(String name) {
        return commands.get(name.toLowerCase());
    }

    public Optional<Command> tryGet(String name) {
        return Optional.ofNullable(commands.get(name.toLowerCase()));
    }

    public Collection<Command> all() {
        return commands.values();
    }

    public int size() {
        return commands.size();
    }
}
