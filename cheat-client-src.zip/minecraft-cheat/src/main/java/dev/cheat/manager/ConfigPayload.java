package dev.cheat.manager;

import java.util.HashMap;
import java.util.Map;

/**
 * POJO-контейнер сериализуемой конфигурации.
 *
 * <p>Расширяется по мере роста проекта. Каркас хранит минимум:
 * состояние и бинды модулей + общие настройки.</p>
 */
public final class ConfigPayload {

    /** Общая версия схемы конфига. */
    public int version = 1;

    public String currentTheme = "default";

    public Map<String, ModuleEntry> modules = new HashMap<>();

    public static final class ModuleEntry {
        public String  name;
        public boolean enabled;
        public int     bind;
    }
}
