package dev.cheat.event.impl;

import dev.cheat.event.Event;

/**
 * 2D-рендер на HUD. Вызывается из {@code InGameHudMixin.render()}.
 * Используется для watermark, ArrayList, ClickGUI.
 */
public record Render2DEvent(float tickDelta, int screenWidth, int screenHeight) implements Event {
}
