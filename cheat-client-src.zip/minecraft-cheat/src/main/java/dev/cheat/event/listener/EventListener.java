package dev.cheat.event.listener;

/**
 * Маркерный интерфейс для подписчиков событий.
 *
 * <p>Любой класс, желающий получать события, реализует этот интерфейс
 * и регистрируется через {@code Client.get().eventManager().subscribe(this)}.</p>
 *
 * <p>Методы-обработчики помечаются аннотацией {@link EventHandler}
 * и принимают ровно один аргумент — тип события.</p>
 */
@FunctionalInterface
public interface EventListener {
    // Маркерный интерфейс; метод не нужен, но FunctionalInterface требует один метод.
    // Используем пустой — фактическая работа идёт через @EventHandler.
    void noop();
}
