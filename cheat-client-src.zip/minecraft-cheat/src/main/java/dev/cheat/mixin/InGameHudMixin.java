package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.Render2DEvent;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link InGameHud}.
 *
 * <p>После отрисовки ванильного HUD триггерит {@link Render2DEvent} с
 * {@link DrawContext} — точкой входа для watermark, ArrayList, ClickGUI.</p>
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    @Inject(method = "render",
            at = @At("RETURN"))
    private void cheat$onHudRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (Client.get() == null) return;
        try {
            float delta = tickCounter.getLastFrameDuration();
            int w = context.getScaledWindowWidth();
            int h = context.getScaledWindowHeight();
            Client.get().eventManager().post(new Render2DEvent(delta, w, h));
        } catch (Throwable ignored) {}
    }
}
