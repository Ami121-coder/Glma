package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.Event;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link Mouse}.
 *
 * <p>Каркас оставляет хук для будущих событий мыши (MouseClickEvent и т.п.).
 * Сейчас логика минимальна: вызов {@link Event#timestamp()} для целей отладки.</p>
 */
@Mixin(Mouse.class)
public abstract class MouseMixin {

    @Inject(method = "onMouseButton",
            at = @At("HEAD"),
            cancellable = true)
    private void cheat$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (Client.get() == null) return;
        // Заглушка: разработчик добавит MouseEvent и publish здесь.
        // Сохранена для целостности архитектуры.
    }
}
