package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.PacketReceiveEvent;
import dev.cheat.event.impl.PacketSendEvent;
import dev.cheat.util.Logger;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin в {@link ClientConnection}.
 *
 * <p>Перехватывает:</p>
 * <ul>
 *   <li>{@code send(Packet, ...)} → {@link PacketSendEvent}. Отмена = пакет
 *       не отправлен. Подмена = {@link ModifyVariable} меняет локальную
 *       переменную {@code packet} на новую до того, как она уйдёт в сеть.</li>
 *   <li>{@code channelRead0(ctx, Packet)} → {@link PacketReceiveEvent}.
 *       Отмена = пакет проигнорирован.</li>
 * </ul>
 *
 * <p><b>Архитектура:</b> Mixin только публикует события. Решения
 * (cancel / replace / buffer) принимает {@link dev.cheat.manager.PacketManager},
 * который подписан первым (priority=10) на эти события.</p>
 *
 * <p>Это фундамент для анти-knockback, packet-фильтров, blink и т.п.</p>
 */
@Mixin(ClientConnection.class)
public abstract class ClientConnectionMixin {

    /**
     * HEAD-inject: публикует {@link PacketSendEvent}.
     * Если событие отменено — отменим весь send (модуль вернул DENY или BUFFER).
     */
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V",
            at = @At("HEAD"),
            cancellable = true)
    private void cheat$onSend(Packet<?> packet, net.minecraft.network.PacketCallbacks callbacks,
                              boolean flush, CallbackInfo ci) {
        if (Client.get() == null) return;
        try {
            PacketSendEvent<Packet<?>> ev = new PacketSendEvent<>(packet);
            Client.get().eventManager().post(ev);
            if (ev.isCancelled()) {
                ci.cancel();
            }
        } catch (Throwable t) {
            Logger.error("ClientConnection send intercept error", t);
        }
    }

    /**
     * Подмена пакета: если {@link PacketSendEvent#setPacket(Object)} был вызван
     * (через PacketManager REPLACE), подменяем локальную переменную {@code packet}.
     *
     * <p>Используем {@link ModifyVariable} на методе {@code send} сразу после
     * нашего HEAD-inject (по умолчанию At должен сработать при входе, после
     * инжекта). ordinal=0 — это первый аргумент {@code packet}.</p>
     */
    @ModifyVariable(
            method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;Z)V",
            at = @At(value = "HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private Packet<?> cheat$modifySendPacket(Packet<?> packet) {
        if (Client.get() == null) return packet;
        // Забираем replacement, установленный PacketManager через PacketSendEvent.setPacket()
        Packet<?> replacement = PacketSendEvent.consumeReplacement();
        return replacement != null ? replacement : packet;
    }

    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"),
            cancellable = true)
    private void cheat$onReceive(io.netty.channel.ChannelHandlerContext ctx,
                                 Packet<?> packet, CallbackInfo ci) {
        if (Client.get() == null) return;
        try {
            PacketReceiveEvent<Packet<?>> ev = new PacketReceiveEvent<>(packet);
            Client.get().eventManager().post(ev);
            if (ev.isCancelled()) ci.cancel();
        } catch (Throwable t) {
            Logger.error("ClientConnection receive intercept error", t);
        }
    }
}
