package dev.cheat.mixin;

import dev.cheat.Client;
import dev.cheat.event.impl.ClientTickEvent;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Главный mixin в {@link MinecraftClient}.
 *
 * <p>Точки перехвата:</p>
 * <ul>
 *   <li>{@code tick()} HEAD   → {@link ClientTickEvent}(PRE)  + ModuleManager.tickAll()</li>
 *   <li>{@code tick()} RETURN → {@link ClientTickEvent}(POST)</li>
 * </ul>
 *
 * <p>2D-рендер перенесён в {@link InGameHudMixin} (там доступен {@code DrawContext}).</p>
 */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void cheat$onTickStart(CallbackInfo ci) {
        if (Client.get() == null) return;
        try {
            Client.get().eventManager().post(new ClientTickEvent(ClientTickEvent.Phase.PRE));
            Client.get().moduleManager().tickAll();
        } catch (Throwable ignored) {
            // защитное: ошибка в одном тике не должна крашить игру
        }
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void cheat$onTickEnd(CallbackInfo ci) {
        if (Client.get() == null) return;
        try {
            Client.get().eventManager().post(new ClientTickEvent(ClientTickEvent.Phase.POST));
        } catch (Throwable ignored) {}
    }
}
