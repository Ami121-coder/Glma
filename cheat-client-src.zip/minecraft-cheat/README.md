# Cheat Client — Fabric 1.21.4

Каркас Minecraft чита на Fabric Loader для **Minecraft 1.21.4**.
Полностью спроектированная архитектура: менеджеры, ивент-шина, mixin-хуки,
команды, конфиг, UI-фреймворк ClickGUI. **Без модулей** — это база для
дальнейшего расширения.

---

## Стек

| Компонент          | Версия                              |
| ------------------ | ----------------------------------- |
| Minecraft          | 1.21.4                              |
| Yarn mappings      | 1.21.4+build.8                      |
| Fabric Loader      | 0.16.9                              |
| Fabric API         | 0.110.5+1.21.4                      |
| Fabric Loom        | 1.9-SNAPSHOT                        |
| Java               | 21 (требование 1.21.x)              |

---

## Структура проекта

```
minecraft-cheat/
├── build.gradle                 # Fabric Loom, зависимости
├── settings.gradle
├── gradle.properties            # Версии и метаданные
└── src/main/
    ├── java/dev/cheat/
    │   ├── CheatClient.java     # Точка входа (ClientModInitializer)
    │   ├── Client.java          # Singleton — топ-менеджеры
    │   ├── core/
    │   │   ├── Core.java            # Оркестратор bootstrap
    │   │   └── ServiceLocator.java  # Лёгкий DI
    │   ├── manager/
    │   │   ├── ModuleManager.java
    │   │   ├── CommandManager.java
    │   │   ├── CommandDispatcher.java
    │   │   ├── ConfigManager.java
    │   │   ├── ConfigPayload.java
    │   │   ├── FriendManager.java
    │   │   └── EventManager.java       # Шина событий
    │   ├── module/
    │   │   ├── Module.java             # Базовый класс модуля
    │   │   ├── Category.java           # COMBAT/MOVEMENT/...
    │   │   ├── ModuleInfo.java         # @Annotation метаданные
    │   │   └── ModulePriority.java
    │   ├── event/
    │   │   ├── Event.java              # Marker
    │   │   ├── Cancellable.java
    │   │   ├── listener/
    │   │   │   ├── EventListener.java
    │   │   │   └── EventHandler.java   # @interface
    │   │   └── impl/
    │   │       ├── ClientTickEvent.java
    │   │       ├── PlayerTickEvent.java
    │   │       ├── PlayerMoveEvent.java
    │   │       ├── KeyEvent.java
    │   │       ├── PacketSendEvent.java
    │   │       ├── PacketReceiveEvent.java
    │   │       ├── Render2DEvent.java
    │   │       └── Render3DEvent.java
    │   ├── command/
    │   │   ├── Command.java
    │   │   ├── CommandContext.java
    │   │   ├── CommandException.java
    │   │   └── arg/Argument.java
    │   ├── config/
    │   │   ├── Config.java             # Interface
    │   │   └── JsonConfig.java         # GSON с атомарной записью
    │   ├── mixin/
    │   │   ├── MinecraftClientMixin.java       # tick → ClientTickEvent
    │   │   ├── ClientPlayerEntityMixin.java    # tick → PlayerTickEvent
    │   │   ├── ClientPlayNetworkHandlerMixin.java # chat → commands
    │   │   ├── ClientConnectionMixin.java      # send/recv → packet events
    │   │   ├── KeyboardMixin.java              # onKey → KeyEvent + bind
    │   │   ├── MouseMixin.java                 # future MouseEvent
    │   │   ├── InGameHudMixin.java             # render → Render2DEvent
    │   │   └── KeyBindingMixin.java            # isPressed override
    │   ├── ui/
    │   │   ├── ClickGUIScreen.java
    │   │   ├── component/{Component, Button, Frame}.java
    │   │   └── theme/Theme.java
    │   ├── render/                     # ── Кастомный рендер-движок ──
    │   │   ├── Render2D.java           # Главный 2D-API (roundedRect, gradient, glow, scissors)
    │   │   ├── BlurRenderer.java       # Framebuffer blur для фонов
    │   │   ├── font/
    │   │   │   └── CustomFontRenderer.java  # shadow/outline/rainbow/gradient/glow
    │   │   ├── shader/
    │   │   │   ├── ShaderManager.java        # Кэш ShaderProgram
    │   │   │   └── CustomRenderLayers.java   # ROUNDED_RECT, GRADIENT, GLOW, BLUR слои
    │   │   ├── buffer/
    │   │   │   └── StencilUtil.java          # Маски через stencil buffer
    │   │   └── anim/
    │   │       ├── Easing.java               # 16 функций плавности
    │   │       └── Animation.java            # Двунаправленная анимация
    │   ├── util/
    │   │   ├── Logger.java
    │   │   ├── ChatUtil.java
    │   │   ├── MathUtil.java
    │   │   ├── ColorUtil.java         # ARGB/HSL/HSB + gradient/rainbow/blend
    │   │   └── RenderUtil.java        # 2D (через Render2D) + 3D (line/box/filledBox)
    │   └── feature/                    # пустой (зарезервирован)
    └── resources/
        ├── fabric.mod.json
        ├── cheat.mixins.json
        └── assets/cheat/
            └── shaders/core/
                ├── rounded.{json,vsh,fsh}    # SDF rounded rect
                ├── gradient.{json,vsh,fsh}   # 4-color gradient
                ├── glow.{json,vsh,fsh}       # Пульсирующее свечение
                └── blur.{json,vsh,fsh}       # Гауссов блюр
```

---

## Сборка

> **Важно**: в среде разработки Gradle-wrapper не приложен (он весит
> ~60 КБ и отдельно скачивается). Если у вас установлен Gradle 8.8+,
> используйте `gradle ...`. Иначе сгенерируйте wrapper:
>
> ```bash
> gradle wrapper --gradle-version 8.10
> ```

### Команды

```bash
# Сборка JAR-файла в build/libs/cheat-client-0.1.0-beta.jar
./gradlew build

# Запуск дев-клиента Minecraft с модом
./gradlew runClient

# Запуск дев-сервера (для тестирования серверной части — N/A в каркасе)
./gradlew runServer

# Генерация источников (IDE-источники для Minecraft)
./gradlew genSources
```

### Установка в реальный Minecraft

1. Установить **Fabric Loader 0.16+** через [fabricmc.net](https://fabricmc.net/use/).
2. Установить **Fabric API** (`fabric-api-0.110.5+1.21.4.jar`) в `.minecraft/mods/`.
3. Скопировать `build/libs/cheat-client-*.jar` в `.minecraft/mods/`.
4. Запустить Minecraft 1.21.4 — в логе появится
   `Cheat Client v0.1.0-beta / Bootstrap complete — client running`.

---

## Архитектурные принципы

### 1. Singleton + централизованный доступ

`Client.get()` — единая точка доступа ко всем менеджерам. Это намеренно:
чит-коду нужен быстрый глобальный доступ. Порядок инициализации
фиксирован в `Core.bootstrap()`.

### 2. Ивент-шина на аннотациях

```java
public final class MyModule extends Module {
    @EventHandler(priority = 50)
    public void onTick(ClientTickEvent e) {
        if (e.isPre()) {
            // ...
        }
    }
}
```

Подписка/отписка происходит автоматически при `module.enable()` /
`module.disable()`.

### 3. Mixin-слой = мост между ванилью и событиями

Каждый mixin-класс **только** перехватывает ванильный вызов и
публикует событие через `EventManager.post(...)`. Логики в миксинах
почти нет — это сохраняет их читаемость и устойчивость к обновлениям.

### 4. Модули — пустые классы с метаданными

Модуль помечается `@ModuleInfo`, наследуется от `Module`, регистрируется
через `moduleManager().register(MyModule.class)`. Каркас НЕ добавляет
ни одного модуля — только контракт.

### 5. Команды — префикс `.`

Чат перехватывается в `ClientPlayNetworkHandlerMixin.sendChatMessage`.
Если строка начинается с `.`, диспетчер ищет команду по имени/алиасу и
вызывает. Системные команды (`.help`, `.toggle`, `.bind`, `.config`,
`.friend`) каркас описывает как точку расширения — реальная реализация
остаётся за разработчиком (можно заполнить сразу через `registerDefaults()`).

### 6. Конфигурация — JSON, атомарная запись

`JsonConfig<T>` использует GSON и пишет через `*.tmp` + atomic move.
Расположение: `.minecraft/cheat/config.json`, `.minecraft/cheat/friends.txt`.

### 7. Кастомный рендер-движок (Fonts + Shaders)

Каркас включает полноценный рендер-движок для красивого UI:

**Шрифты** (`dev.cheat.render.font.CustomFontRenderer`):
- `drawSoftShadow` — двойная мягкая тень
- `drawOutline` — обводка в 8 направлениях
- `drawRainbow` — переливающийся текст (per-symbol hue shift)
- `drawGradient` — линейный градиент между двумя цветами
- `drawGlow` — свечение под текстом
- `drawTitle` — gradient + glow для заголовков ClickGUI

**Шейдеры** (`dev.cheat.render.shader`):
- `rounded.json/.vsh/.fsh` — SDF-закруглённые прямоугольники с anti-aliasing
- `gradient.json/.vsh/.fsh` — 4-цветный билинейный градиент
- `glow.json/.vsh/.fsh` — пульсирующее свечение вокруг формы
- `blur.json/.vsh/.fsh` — гауссов блюр для красивых фонов

**Главный 2D-API** (`dev.cheat.render.Render2D`):
```java
Render2D.roundedRect(ctx, x, y, w, h, 8, 0xFF1A1A1A);            // закруглённый
Render2D.verticalGradient(ctx, x, y, w, h, top, bottom);          // градиент
Render2D.glowRect(ctx, x, y, w, h, radius, spread, color);        // свечение
Render2D.scissors(x, y, w, h); ... Render2D.disableScissors();    // обрезка
```

**Размытие** (`dev.cheat.render.BlurRenderer`):
```java
BlurRenderer.beginRegion(ctx, x, y, w, h, radius, blurRadius, overlayColor);
// рисуем контент поверх размытого фона
BlurRenderer.endRegion();
```

**Анимации** (`dev.cheat.render.anim`):
- `Easing` — 16 функций (LINEAR, QUAD, CUBIC, EXPO, SINE, BACK, ELASTIC, BOUNCE)
- `Animation` — двунаправленная анимация с длительностью и easing

**Темы** (`dev.cheat.ui.theme.Theme`):
- 4 пресета: DEFAULT, DARK, LIGHT, MIDNIGHT
- Расширенная палитра: background, panel, component, accent+accent2 (для градиентов), text, shadow, borderGlow
- Параметры радиусов: radius (компактный), radiusLarge (панели)

**Stencil-маски** (`dev.cheat.render.buffer.StencilUtil`):
```java
StencilUtil.beginStencil();
Render2D.roundedRect(ctx, x, y, w, h, 8, 0xFFFFFFFF);  // форма-маска
StencilUtil.useStencil();
// ... контент обрезается по форме
StencilUtil.endStencil();
```

---

## Расширение каркаса

### Добавить модуль

```java
package dev.cheat.module.impl;

import dev.cheat.event.impl.ClientTickEvent;
import dev.cheat.event.listener.EventHandler;
import dev.cheat.module.Category;
import dev.cheat.module.Module;
import dev.cheat.module.ModuleInfo;
import org.lwjgl.glfw.GLFW;

@ModuleInfo(
    name = "Sprint",
    description = "Авто-спринт",
    category = Category.MOVEMENT,
    bind = GLFW.GLFW_KEY_V
)
public final class SprintModule extends Module {

    @EventHandler
    public void onTick(ClientTickEvent e) {
        if (!e.isPre() || mc.player == null) return;
        if (mc.player.horizontalCollision) return;
        if (mc.player.input.movementForward > 0
                && !mc.player.isSprinting()
                && !mc.player.isUsingItem()) {
            mc.player.setSprinting(true);
        }
    }
}
```

Зарегистрировать в `ModuleManager.registerDefaults()`:

```java
public void registerDefaults() {
    register(SprintModule.class);
    // ... другие модули
}
```

### Добавить команду

```java
public final class ToggleCommand extends Command {
    public ToggleCommand() {
        super("toggle", "Включить/выключить модуль", "t");
    }
    @Override protected void execute(CommandContext ctx) throws CommandException {
        String name = ctx.string(0);
        Module m = Client.get().moduleManager().get(name);
        if (m == null) throw new CommandException("Модуль не найден: " + name);
        m.toggle();
    }
    @Override public int getMinArgs() { return 1; }
    @Override protected String usageArgs() { return "<module>"; }
}
```

Зарегистрировать в `CommandManager.registerDefaults()`.

---

## Известные ограничения каркаса

- **Модулей нет.** Только базовый класс и менеджер.
- **Команды зарегистрированы как инфраструктура**, но конкретные `help`,
  `toggle`, `bind`, `config`, `friend` оставлены разработчику.
- **MouseMixin** оставлен заглушкой (нет `MouseEvent` класса).
- **ClickGUI** рисует фреймы категорий без кнопок — кнопки появятся после
  регистрации модулей.
- **Gradle wrapper не приложен** — см. раздел «Сборка».

---

## Лицензия

MIT. Используйте на свой риск; нарушение EULA Minecraft и правил
серверов — на ответственности пользователя.
